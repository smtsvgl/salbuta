<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8 Türkçe Dil Dosyası Paketi
 * Türkçe Çeviri: Machine (Hüseyin KÖRBALTA)
 * Website: http://mybb.com.tr - http://mybbdepo.com
 * Kişisel blog: https://huseyinkorbalta.com
 * Son Güncelleme: 14.06.2019 - Saat: 18:05
 */

$l['redirect_width'] = "50%";
$l['lastvisit_never'] = "Asla";
$l['lastvisit_hidden'] = "(Gizli)";

$l['search_button'] = 'Ara';
$l['toplinks_memberlist'] = "Üye Listesi";
$l['toplinks_search'] = "Arama";
$l['toplinks_calendar'] = "Takvim";
$l['toplinks_help'] = "Yardım";
$l['toplinks_portal'] = "Portal";
$l['bottomlinks_forumteam'] = "Forum Yönetimi"; // Yeni eklenen dil satırı [Machine]
$l['bottomlinks_contactus'] = "İletişim";
$l['bottomlinks_returntop'] = "Yukarı Git";
$l['bottomlinks_syndication'] = "RSS";
$l['bottomlinks_litemode'] = "Arşiv";
$l['bottomlinks_markread'] = "Forumları Okundu Kabul Et";

$l['welcome_usercp'] = "Kullanıcı KP";
$l['welcome_modcp'] = "Mod KP";
$l['welcome_admin'] = "Admin KP";
$l['welcome_logout'] = "Çıkış Yap";
$l['welcome_login'] = "Giriş Yap";
$l['welcome_register'] = "Kayıt Ol";
$l['welcome_open_buddy_list'] = "Arkadaşlarım";
$l['welcome_newposts'] = "Son Mesajlar";
$l['welcome_todaysposts'] = "Bugünkü Mesajlar";
$l['welcome_pms'] = "Özel Mesajlar:";
$l['welcome_pms_usage'] = "(Toplam {2}, Okunmamış {1})";
$l['welcome_back'] = "<strong>Hoşgeldiniz, {1}</strong>. Son Ziyaretiniz: {2}";
$l['welcome_guest'] = "Hoşgeldin, Ziyaretçi:";
$l['welcome_current_time'] = "<strong>Tarih:</strong> {1}";

$l['moved_prefix'] = "Taşındı:";
$l['poll_prefix'] = "Anket:";
//Fixed: XpSerkan
//Sabit ve Duyuru ibareleri, manuel modifikasyon işlemlerinde lazım olabileceği düşünüldüğünden MCTR 1.8 dil dosyasından kaldırılmamıştır.
$l['sticky_prefix'] = "Sabit:";
$l['announcement_prefix'] = "Duyuru:";
//Fixed: XpSerkan

$l['forumbit_announcements'] = "Duyurular";
$l['forumbit_stickies'] = "Öne Çıkan Konular";
$l['forumbit_forum'] = "Forumlar";
$l['forumbit_threads'] = "Konular";
$l['forumbit_posts'] = "Yorumlar";
$l['forumbit_lastpost'] = "Son Yorumlar";
$l['forumbit_moderated_by'] = "Yönetici:";
$l['new_posts'] = "Yeni Yorum Var";
$l['no_new_posts'] = "Yeni Yorum Yok";
$l['click_mark_read'] = "Forumları Okundu Kabul Et";
$l['forum_closed'] = "Forum Kapalı";
$l['forum_redirect'] = "Yönlendirilen Forum";
$l['lastpost_never'] = "Henüz Yok";
$l['viewing_one'] = " (1 Kullanıcı içerde)";
$l['viewing_multiple'] = " ({1} Kullanıcı içerde)";
$l['by'] = "Yazar:";
$l['more_subforums'] = "{1}, Alt forum daha var.";

$l['password_required'] = "Giriş yapabilmeniz için şifre gerekli.";
$l['forum_password_note'] = "<p><img src=\"images/icons/uyari.gif\" alt=\"\" style=\"vertical-align: middle;\" height=\"14\" width=\"14\" /> <strong>Uyarı:</strong> Site Yönetimi Tarafından Şifrelenmiş Bir Foruma Girmeye Çalışıyorsunuz.</p> Bu foruma erişebilmek ve işlem yapabilmeniz için site yöneticisinden şifre almanız gerekiyor.<br />Eğer bir Şifreniz varsa Lütfen, aşağıdaki metin kutusuna yazarak giriş yapınız.";
$l['enter_password_below'] = "<center>(Lütfen şifrenizi aşağıdaki metin kutusuna yazınız)</center>";
$l['verify_forum_password'] = "Giriş Yap";
$l['wrong_forum_password'] = "Girilen şifre yanlış. Lütfen şifrenizin doğruluğunu kontrol ederek tekrar deneyiniz.";

$l['reset_button'] = "Sıfırla";
$l['username'] = "Kullanıcı Adı:";
$l['username1'] = "E-Posta Adresiniz:";
$l['username2'] = "Kullanıcı Adı/E-Posta:";
$l['password'] = "Şifreniz:";
$l['login_username'] = "Kullanıcı Adı:";
$l['login_username1'] = "E-Posta:";
$l['login_username2'] = "Kullanıcı Adı/E-Posta";
$l['login_password'] = "Şifreniz:";
$l['lost_password'] = "Şifremi Unuttum?";
$l['remember_me'] = "Beni Hatırla";
$l['remember_me_desc'] = "Bu seçenek, forumdan çıkış yapmadığınız sürece, her ziyaretinizde giriş bilgilerinizin otomatik olarak hatırlanmasını sağlar.";

$l['month_1'] = "Ocak";
$l['month_2'] = "Şubat";
$l['month_3'] = "Mart";
$l['month_4'] = "Nisan";
$l['month_5'] = "Mayıs";
$l['month_6'] = "Haziran";
$l['month_7'] = "Temmuz";
$l['month_8'] = "Ağustos";
$l['month_9'] = "Eylül";
$l['month_10'] = "Ekim";
$l['month_11'] = "Kasım";
$l['month_12'] = "Aralık";

$l['sunday'] = "Pazar";
$l['monday'] = "Pazartesi";
$l['tuesday'] = "Salı";
$l['wednesday'] = "Çarşamba";
$l['thursday'] = "Perşembe";
$l['friday'] = "Cuma";
$l['saturday'] = "Cumartesi";
$l['short_monday'] = "Pt";
$l['short_tuesday'] = "Sa";
$l['short_wednesday'] = "Ça";
$l['short_thursday'] = "Pe";
$l['short_friday'] = "Cu";
$l['short_saturday'] = "Ct";
$l['short_sunday'] = "Pz";

$l['yes'] = "Evet";
$l['no'] = "Hayır";

$l['and'] = "ve";
$l['date'] = "Tarih";

$l['nobody'] = "Hiç Kimse";

$l['attachments'] = "Ekler";
$l['attachments_desc'] = "İsteğe bağlı olarak bu gönderiye bir veya birden fazla ek dosya ekleyebilirsiniz. Lütfen, sağ taraftan dosyayı seçin ve 'Ek Dosya Yükle' butonuna tıklayın.";
$l['remove_attachment'] = "Kaldır";
$l['approve_attachment'] = "Onayla";
$l['unapprove_attachment'] = "Onaylama";
$l['insert_attachment_post'] = "Gönderiye Ekle";
$l['new_attachment'] = "Yeni Ek Dosya:";
$l['add_attachment'] = "Ek Dosya Yükle";
$l['update_attachment'] = "Güncelle";
$l['attachment_too_many_files'] = "Bir kerede en fazla {1} dosya yükleyebilirsiniz.";
$l['attachment_too_big_upload'] = "Bir kerede en fazla {1} boyutunda dosya yükleyebilirsiniz.";
$l['post_preview'] = "Ön İzle";
$l['change_user'] = "kullanıcı değiştir";
$l['post_icon'] = "Mesaj Simgesi:";
$l['no_post_icon'] = "Simge Yok";
$l['thread_subscription_method'] = "Konu Aboneliği:";
$l['thread_subscription_method_desc'] = "Bu konuda ki önemli gelişmelerden haberdar olmak istiyorsanız konuya abone olabilir ve bildirim türünü belirtebilirsiniz (Bu özellik sadece kayıtlı kullanılar için kullanılabilir).";
$l['no_subscribe'] = "Bu konuya abone olma";
$l['no_subscribe_notification'] = "Konuya gelen yeni yorumların bildirimini almadan abone ol.";
$l['instant_email_subscribe'] = "Konuya abone ol ve yeni gelen yorumlardan beni e-posta ile haberdar et.";
$l['instant_pm_subscribe'] = "Konuya abone ol ve yeni gelen yorumlardan beni ÖM ile haberdar et.";

$l['today_rel'] = "<span title=\"{1}\">Bugün</span>";
$l['yesterday_rel'] = "<span title=\"{1}\">Dün</span>";
$l['today'] = "Bugün";
$l['yesterday'] = "Dün";
$l['error'] = "Forum Mesajı";

$l['multipage_pages'] = "Toplam ({1}) Sayfa:";
$l['multipage_last'] = "Son";
$l['multipage_first'] = "İlk";
$l['multipage_next'] = "Sonraki";
$l['multipage_previous'] = "Önceki";
$l['multipage_link_start'] = " &hellip;";
$l['multipage_link_end'] = "&hellip; ";
$l['multipage_jump'] = "Sayfaya Git";

$l['editor_bold'] = "Kalın yazı";
$l['editor_italic'] = "Eğik yazı";
$l['editor_underline'] = "Altı çizik yazı";
$l['editor_strikethrough'] = "Üstü çizik yazı";
$l['editor_subscript'] = "Alt simge";
$l['editor_superscript'] = "Üst simge";
$l['editor_alignleft'] = "Yazıyı sola yasla";
$l['editor_center'] = "Yazıyı ortala";
$l['editor_alignright'] = "Yazıyı sağa yasla";
$l['editor_justify'] = "Yazıyı her iki tarafa hizala";
$l['editor_fontname'] = "Yazı tipi";
$l['editor_fontsize'] = "Yazı boyutu";
$l['editor_fontcolor'] = "Yazı rengi";
$l['editor_removeformatting'] = "Metin biçimini sil";
$l['editor_cut'] = "Kes";
$l['editor_copy'] = "Kopyala";
$l['editor_paste'] = "Yapıştır";
$l['editor_cutnosupport'] = "Tarayıcınız kesme komutuna izin vermiyor. Lütfen, Ctrl/Cmd-X klavye kısayolunu kullanın.";
$l['editor_copynosupport'] = "Tarayıcınız kopyalama komutuna izin vermiyor. Lütfen, Ctrl/Cmd-C klavye kısayolunu kullanın.";
$l['editor_pastenosupport'] = "Tarayıcınız yapıştırma komutuna izin vermiyor. Lütfen, Ctrl/Cmd-V klavye kısayolunu kullanın.";
$l['editor_pasteentertext'] = "Aşağıdaki kutu içine metni yapıştırın:";
$l['editor_pastetext'] = "Metni Yapıştır";
$l['editor_numlist'] = "Numaralı liste";
$l['editor_bullist'] = "Noktalı liste";
$l['editor_undo'] = "1 adım Geri git";
$l['editor_redo'] = "1 adım ileri git";
$l['editor_rows'] = "Satır:";
$l['editor_cols'] = "Sütun:";
$l['editor_inserttable'] = "Tablo ekle";
$l['editor_inserthr'] = "Yatay ayraç çizgisi ekle";
$l['editor_code'] = "Kod ekle (Code)";
$l['editor_php'] = "PHP kod ekle (PHP Code)";
$l['editor_width'] = "Genişlik (opsiyonel):";
$l['editor_height'] = "Yükseklik (opsiyonel):";
$l['editor_insertimg'] = "Resim ekle";
$l['editor_email'] = "E-Posta Adresi:";
$l['editor_insertemail'] = "E-Posta adresi ekle";
$l['editor_url'] = "URL Adresi:";
$l['editor_insertlink'] = "Link ekle";
$l['editor_unlink'] = "Linki sil";
$l['editor_more'] = "Daha fazla göster";
$l['editor_insertemoticon'] = "İfade ekle";
$l['editor_videourl'] = "Video URL:";
$l['editor_videotype'] = "Video Türü:";
$l['editor_insert'] = "Ekle";
$l['editor_insertyoutubevideo'] = "YouTube videosu ekle";
$l['editor_currentdate'] = "Şu anki tarihi ekle";
$l['editor_currenttime'] = "Şu anki saati ekle";
$l['editor_print'] = "Yazdır";
$l['editor_viewsource'] = "Kaynağı görüntüle";
$l['editor_description'] = "Açıklama (opsiyonel):";
$l['editor_enterimgurl'] = "Resim URL'si girin:";
$l['editor_enteremail'] = "E-Posta adresi girin:";
$l['editor_enterdisplayedtext'] = "Görüntülenecek metni girin:";
$l['editor_enterurl'] = "URL adresi girin:";
$l['editor_enteryoutubeurl'] = "YouTube video URL'si yada ID'si girin:";
$l['editor_insertquote'] = "Alıntı yazı ekle (Quote)";
$l['editor_invalidyoutube'] = "Geçersiz YouTube videosu";
$l['editor_dailymotion'] = "Dailymotion";
$l['editor_metacafe'] = "MetaCafe";
$l['editor_mixer'] = "Mixer";
$l['editor_vimeo'] = "Vimeo";
$l['editor_youtube'] = "Youtube";
$l['editor_twitch'] = "Twitch";
$l['editor_facebook'] = "Facebook";
$l['editor_liveleak'] = "LiveLeak";
$l['editor_insertvideo'] = "Video Ekle";
$l['editor_maximize'] = "Tam Ekran";

$l['quote'] = "Alıntı:";
$l['wrote'] = "Adlı Kullanıcıdan Alıntı:";
$l['code'] = "Kod:";
$l['php_code'] = "PHP Kod:";
$l['posted_image'] = "[Resim: {1}]";
$l['posted_video'] = "[Video: {1}]";
$l['linkback'] = "Orjinal Konu";

$l['at'] = "";
$l['na'] = "N/A";
$l['guest'] = "Ziyaretçi";
$l['unknown'] = "Bilinmeyen";
$l['never'] = "Hiçbir Zaman";
$l['postbit_posts'] = "Yorumları:";
$l['postbit_threads'] = "Konuları:";
$l['postbit_group'] = "Üye Grubu:";
$l['postbit_joined'] = "Kayıt Tarihi:";
$l['postbit_status'] = "Durum:";
//Fixed: XpSerkan
$l['postbit_location'] = "Konum:";
$l['postbit_referances'] = "Referansları:";
//Fixed: XpSerkan
$l['postbit_attachments'] = "Ek Dosyalar";
$l['postbit_attachment_filename'] = "Dosya Adı:";
$l['postbit_attachment_size'] = "Dosya Boyutu:";
$l['postbit_attachment_downloads'] = "İndirme Sayısı:";
$l['postbit_attachments_images'] = "Resimler";
$l['postbit_attachments_thumbnails'] = "Ekran Görüntüleri";
$l['postbit_unapproved_attachments'] = "{1} Onaylanmamış Eklenti.";
$l['postbit_unapproved_attachment'] = "1 Onaylanmamış Eklenti.";
$l['postbit_status_online'] = "Çevrimiçi";
$l['postbit_status_offline'] = "Çevrimdışı";
$l['postbit_status_away'] = "İzinli";
$l['postbit_edited'] = "Son Düzenleme: {1}, Düzenleyen: ";
$l['postbit_editreason'] = "Sebep";
$l['postbit_ipaddress'] = "IP No:";
$l['postbit_ipaddress_logged'] = "Göster";
$l['postbit_post'] = "Yorum:";
$l['postbit_reputation'] = "Rep Puanı:";
$l['postbit_reputation_add'] = "Bu Mesaj için Rep Ver";
$l['postbit_website'] = "Web Sitesini Ziyaret Et";
$l['postbit_email'] = "E-Posta Gönder";
$l['postbit_find'] = "Tüm Mesajlarına Bak";
$l['postbit_report'] = "Bu Mesajı Rapor Et";
$l['postbit_quote'] = "Alıntı ile Cevapla";
$l['postbit_qdelete_post'] = "Bu Yorumu Sil";
$l['postbit_qdelete_thread'] = "Bu Konuyu Sil";
$l['postbit_qrestore_post'] = "Bu Yorumu Geri Getir/Onayla";
$l['postbit_qrestore_thread'] = "Bu Konuyu Geri Getir/Onayla";
$l['postbit_profile'] = "Profil Bilgilerine Bak";
$l['postbit_pm'] = "Özel Mesaj Gönder";
$l['postbit_edit'] = "Bu Mesajı Düzenle/Sil";
$l['postbit_multiquote'] = "Çoklu Alıntı olarak Seç";
$l['postbit_quick_edit'] = "Hızlı Düzenle";
$l['postbit_full_edit'] = "Gelişmiş Düzenle";
$l['postbit_show_ignored_post'] = "Gizli İçeriği Göster";
$l['postbit_currently_ignoring_user'] = "Bu Konu veya Yorumun içeriği gizlidir. Çünkü, <strong>{1}</strong> adlı kullanıcı sizin tarafınızdan engelli listenizde kayıtlıdır.<br />Bu engeli kaldırmak istiyorsanız eğer <a rel=\"nofollow\" href=\"usercp.php?action=editlists\"><strong>Buradan</strong></a> engelliler Listesine Giderek, <strong>{1}</strong> adlı kullanıcıya ait engeli kaldırabilirsiniz.<br />Veya engeli kaldırmadan, sağ taraftaki <strong>(Gizli içeriği Göster)</strong>, butonuna tıklayıp konu/yorum içeriğini görebilirsiniz.";
$l['postbit_post_under_moderation'] = "Şuan mesajınız yönetici onayını beklemektedir. Bir yönetici tarafından gönderiniz onaylandıktan sonra herkese görünür hale gelecektir.";
$l['postbit_warning_level'] = "Uyarı Puanı:";
$l['postbit_warn'] = "Bu Mesaj için Uyarı Ver";
$l['postbit_purgespammer'] = "Spam İşlemi Uygula";
$l['postbit_post_deleted'] = "Bu mesaj silindi.";
$l['postbit_post_unapproved'] = "Bu mesaj onay bekliyor.";
$l['postbit_thread_deleted'] = "Bu konu silindi.";
$l['postbit_thread_unapproved'] = "Bu konu onay bekliyor.";
$l['postbit_deleted_post_user'] = "{1} tarafından yazılan bu mesaj silindi.";

$l['postbit_button_reputation_add'] = 'Rep Ver';
$l['postbit_button_website'] = 'WWW';
$l['postbit_button_email'] = 'Email';
$l['postbit_button_find'] = 'Bul';
$l['postbit_button_report'] = 'Rapor Et';
$l['postbit_button_quote'] = 'Cevapla';
$l['postbit_button_qdelete'] = 'Sil';
$l['postbit_button_qrestore'] = 'Onar';
$l['postbit_button_profile'] = 'Profil';
$l['postbit_button_pm'] = 'ÖM';
$l['postbit_button_warn'] = 'Uyar';
$l['postbit_button_edit'] = 'Düzenle';
$l['postbit_button_multiquote'] = 'Alıntı';
$l['postbit_button_reply_pm'] = 'Cevapla';
$l['postbit_button_reply_all'] = 'Tümünü Cevapla';
$l['postbit_button_forward'] = 'İlet';
$l['postbit_button_delete_pm'] = 'Sil';
$l['postbit_button_purgespammer'] = "Spamı Temizle";

$l['forumjump'] = "Hızlı Menü:";
$l['forumjump_pms'] = "Özel Mesajlar";
$l['forumjump_usercp'] = "Kullanıcı Kontrol Paneli";
$l['forumjump_wol'] = "Kimler Çevrimiçi";
$l['forumjump_search'] = "Gelişmiş Arama";
$l['forumjump_home'] = "Forum Ana Sayfası";

$l['redirect'] = "Yönlendiriliyorsunuz, Lütfen bekleyin...";
$l['unknown_error'] = "Sebebi bilinmeyen bir hata oluştu.";
$l['post_fetch_error'] = 'Mesajlar geri getirilirken bir hata oluştu.';

$l['smilieinsert'] = "İfadeler";
$l['smilieinsert_getmore'] = "Daha Fazlası";
$l['on'] = "Açık";
$l['off'] = "Kapalı";
$l['remote_avatar_disabled_default_avatar'] = "Şu anda devre dışı bırakılmış bir uzaktan bağlantıya sahip avatar kullanıyorsunuz. Bu avatar yerine varsayılan avatar kullanılacaktır.";
$l['mod_notice'] = "Yönetici onayı bekleniyor: {1}.";
$l['unapproved_thread'] = "1 onaylanmamış konu.";
$l['unapproved_threads'] = "{1} tane onaylanmamış konu.";
$l['unapproved_post'] = "1 onaylanmamış yorum.";
$l['unapproved_posts'] = "{1} tane onaylanmamış yorum.";
$l['unapproved_attachment'] = "1 onaylanmamış ek dosya.";
$l['unapproved_attachments'] = "{1} tane onaylanmamış ek dosya(lar).";
$l['unread_report'] = "<strong>1 Tane Rapor Edilen Konu Bildirimi Var.</strong>";
$l['unread_reports'] = "<strong>{1} Tane Rapor Edilen Konu Bildirimi Var.</strong>";
$l['pending_joinrequest'] = "Grup Lideri Notu: Bekleyen 1 Grup üyeliği isteği var.";
$l['pending_joinrequests'] = "Grup Lideri Notu: Bekleyen {1} Grup üyeliği isteği var.";

$l['search_user'] = "Bir kullanıcı ara";

$l['year'] = "Yıl";
$l['year_short'] = "y";
$l['years'] = "Yıl";
$l['years_short'] = "y";
$l['month'] = "Ay";
$l['month_short'] = "a";
$l['months'] = "Ay";
$l['months_short'] = "a";
$l['week'] = "Hafta";
$l['week_short'] = "h";
$l['weeks'] = "Hafta";
$l['weeks_short'] = "h";
$l['day'] = "Gün";
$l['day_short'] = "g";
$l['days'] = "Gün";
$l['days_short'] = "g";
$l['hour'] = "Saat";
$l['hour_short'] = "s";
$l['hours'] = "Saat";
$l['hours_short'] = "s";
$l['minute'] = "Dakika";
$l['minute_short'] = "dk";
$l['minutes'] = "Dakika";
$l['minutes_short'] = "dk";
$l['second'] = "Saniye";
$l['second_short'] = "sn";
$l['seconds'] = "Saniye";
$l['seconds_short'] = "sn";

$l['rel_in'] = "İçinde";
$l['rel_ago'] = "önce";
$l['rel_less_than'] = "Daha az ";
$l['rel_time'] = "<span title=\"{5}{6}\">{1}{2} {3} {4}</span>";
$l['rel_minutes_single'] = "dakika";
$l['rel_minutes_plural'] = "dakika";
$l['rel_hours_single'] = "saat";
$l['rel_hours_plural'] = "saat";

$l['permanent'] = "Kalıcı";
$l['save_draft'] = "Taslak Olarak Kaydet";
$l['go'] = "Git";
$l['bbclosed_warning'] = "<img src=\"images/icons/uyari.gif\" alt=\"\" style=\"vertical-align: middle;\" height=\"14\" width=\"14\" /> <strong>Forum Durumu:</strong> Şu anda kullanıma kapalı";
$l['banned_warning'] = "<div class=\"float_left\"><img src=\"images/icons/yasak.png\" style=\"vertical-align: middle;\" alt=\"\" height=\"32\" width=\"32\" /></div>Forumumuzdaki üyelik hesabınız yönetim kararı ile yasaklanmıştır.<div class=\"float_right\"><img src=\"images/icons/yasak.png\" style=\"vertical-align: middle;\" alt=\"\" height=\"32\" width=\"32\" /></div><br />";
$l['banned_warning2'] = "<strong>Yasaklanma sebebi</strong>";
$l['banned_warning3'] = "<strong>Hesabın tekrar aktif olma süresi</strong>";
$l['banned_lifted_never'] = "Süresiz yasaklandı.";
$l['banned_email_warning'] = "E-posta adresinizin yasaklı listesinde olduğu tespit edildi. Lütfen devam etmeden önce e-porta adresinizi yenileyin.";
$l['powered_by'] = "Türkçe Çeviri: <a href=\"http://mybb.com.tr\" target=\"_blank\" title=\"MyBB - Türkiye Resmi Destek Sitesi\">MCTR</a>, Yazılım:";
$l['copyright'] = "Copyright";
$l['attach_quota'] = "Şu anda kullanmış olduğunuz toplam ek dosya boyutu:<strong>[{1}]</strong>";
$l['attach_usage'] = "Şu anda <strong>{1}</strong> ek dosya alanı kullanıyorsunuz.";
$l['view_attachments'] = "<strong>[Yüklediğim dosyaları göster]<strong>";
$l['unlimited'] = "Sınırsız";

$l['click_hold_edit'] = "(Düzenlemek için basılı tutun.)";

$l['guest_count'] = "1 Ziyaretçi";
$l['guest_count_multiple'] = "{1} Ziyaretçi";

$l['size_yb'] = "YB";
$l['size_zb'] = "ZB";
$l['size_eb'] = "EB";
$l['size_pb'] = "PB";
$l['size_tb'] = "TB";
$l['size_gb'] = "GB";
$l['size_mb'] = "MB";
$l['size_kb'] = "KB";
$l['size_bytes'] = "Bayt";

$l['slaps'] = "kullanıcısının bu mesajda bahsettiği kullanıcı-(lar):";
$l['with_trout'] = "biraz büyük bir aralıkta";

$l['mybb_engine'] = "ÖM/Posta Göndericisi";
$l['quickdelete_confirm'] = "Bu mesajı silmek istediğinizden emin misiniz?";
$l['quickrestore_confirm'] = "Bu mesajı onarmak/geri getirmek istediğinizden emin misiniz?";
$l['newpm_notice_one'] = "<div class=\"float_left\"><a rel=\"nofollow\" href=\"{2}/private.php?action=read&amp;pmid={3}\"><img src=\"images/icons/pm-bildirimi.gif\" style=\"vertical-align: middle;\" alt=\"\" height=\"32\" width=\"32\" /></a></div> {1} adlı kullanıcıdan yeni bir özel mesaj aldınız.<br /><strong>Mesaj Başlığı:</strong> <a rel=\"nofollow\" href=\"{2}/private.php?action=read&amp;pmid={3}\" style=\"font-weight: bold;\">{4}</a>";
$l['newpm_notice_multiple'] = "<div class=\"float_left\"><a rel=\"nofollow\" href=\"{3}/private.php?action=read&amp;pmid={4}\"><img src=\"images/icons/pm-bildirimi.gif\" style=\"vertical-align: middle;\" alt=\"\" height=\"32\" width=\"32\" /></a></div> Okunmamış Toplam: <strong>[{1}]</strong> tane mesajınız var.<br /><strong>Son Mesaj Gönderen:</strong> {2}, <strong>Mesaj başlığı:</strong> <a rel=\"nofollow\" href=\"{3}/private.php?action=read&amp;pmid={4}\" style=\"font-weight: bold;\">{5}</a>";
$l['deleteevent_confirm'] = "Bu etkinliği silmek istediğinizden emin misiniz?";
$l['removeattach_confirm'] = "Bu ek dosyayı konudan tamamen silmek istediğinize emin misiniz?";

$l['latest_threads'] = "Son Aktiviteler";

$l['folder_inbox'] = "Gelen Kutusu";
$l['folder_unread'] = "Okunmamış";
$l['folder_sent_items'] = "Gönderilmiş Mesajlar";
$l['folder_drafts'] = "Taslaklar";
$l['folder_trash'] = "Çöp Kutusu";
$l['folder_untitled'] = "İsimsiz Klasör";

$l['standard_mod_tools'] = "Standart Araçlar";
$l['custom_mod_tools'] = "Özel Araçlar";

$l['error_loadlimit'] = "<img src=\"images/icons/uyari.gif\" alt=\"\" style=\"vertical-align: middle;\" height=\"14\" width=\"14\" /> Sunucu yüklenirken zaman aşımına uğradı. Lütfen daha sonra tekrar deneyiniz.";
$l['error_boardclosed'] = "<center>(<span style=\"color: maroon; font-weight: bold;\"> Forumumuz şu anda kapalıdır.</span> )<br />Kapalı olma nedenimiz aşağıda yazmaktadır.</center>";
$l['error_banned'] = "<img src=\"images/icons/uyari.gif\" alt=\"\" style=\"vertical-align: middle;\" height=\"14\" width=\"14\" /> <strong>Üzgünüz:</strong> Forum hesabınız yasaklanmıştır. yasaklı olduğunuz gibi forumdaki tüm erişim izinlerinizde engellenmiştir. Her hangi bir sorunuz veya yasaklı olmanız ile ilgili görüşmek istedikleriniz varsa, Lütfen forum yöneticisi ile iletişime geçiniz.";
$l['error_cannot_upload_php_post'] = "<img src=\"images/icons/uyari.gif\" alt=\"\" style=\"vertical-align: middle;\" height=\"14\" width=\"14\" /> Dosya boyutu büyük olduğundan işleminiz gerçekleşmedi. - Lütfen geriye dönüp yükleme işlemini tekrar deneyiniz..";
$l['error_empty_post_input'] = "Gönderi verileriniz boş olduğundan dolayı bir hata oluştu. Bu hata tarayıcınızın yenilenmesi veya doğrudan bu sayfaya giriş yapılmasından dolayı olabilir. Tarayıcının geri tuşuna basarak geri dönün ve yeniden başlamanızı öneririz.";
$l['error_database_repair'] = "MyBB otomatik olarak sorunlu tabloların onarım ve bakımını gerçekleştiriyor.";

$l['unknown_user_trigger'] = "Bilinmeyen bir hata oluştu.";
$l['warnings'] = "<strong>Aşağıdaki Hatalar Oluştu:</strong>";

$l['ajax_loading'] = "Lütfen Bekleyiniz.<br />Sayfa Yükleniyor...";
$l['saving_changes'] = "Değişiklikler Kaydediliyor...";
$l['refresh'] = "Yenile";
$l['select_language'] = "Dili Değiştir";
$l['select_theme'] = "Temayı Değiştir";

$l['invalid_post_code'] = "Uygun olmayan kod hatası. Bu işlemi doğru bir şekilde yaptığınızdan emin misiniz? Lütfen geri dönüp tekrar deneyiniz.";
$l['invalid_nocaptcha'] = "Eğer bir Spam Bot veya Robot değilseniz Güvenlik Kodunu doğrulayınız.";
$l['invalid_captcha_verify'] = "Girdiğiniz resim doğrulama kodu yanlış. Lütfen, kodu resimde göründüğü şekilde giriniz.";
$l['image_verification'] = "Güvenlik Kodu:";
$l['human_verification'] = "İnsan Doğrulama:";
$l['verification_note'] = "Lütfen, resmin üzerindeki harf ve rakamlardan oluşan Güvenlik Kodunu, aşağıdaki metin kutusuna giriniz.";
$l['verification_note_nocaptcha'] = "Aşağıda görünen onay kutusunu işaretleyiniz. Bu işlem otomatik spam kayıtları önlemek için kullanılır.";
$l['verification_subnote'] = "(Büyük/Küçük harf duyarsız)";
$l['invalid_nocaptcha_transmit'] = "İnsan veya Robot olup olmadığınız doğrulanırken bir hata oluştu. Lütfen tekrar deneyiniz.";
$l['captcha_fetch_failure'] = 'Resim doğrulama yenilenirken bir hata oluştu.';
$l['question_fetch_failure'] = 'Soru yenilenirken bir hata oluştu.';

$l['timezone_gmt_minus_1200'] = "(GMT -12:00) Howland and Baker Islands";
$l['timezone_gmt_minus_1100'] = "(GMT -11:00) Nome, Midway Island";
$l['timezone_gmt_minus_1000'] = "(GMT -10:00) Hawaii, Papeete";
$l['timezone_gmt_minus_950'] = "(GMT -9:30) Marquesas Islands";
$l['timezone_gmt_minus_900'] = "(GMT -9:00) Alaska";
$l['timezone_gmt_minus_800'] = "(GMT -8:00) Pacific Time";
$l['timezone_gmt_minus_700'] = "(GMT -7:00) Mountain Time";
$l['timezone_gmt_minus_600'] = "(GMT -6:00) Central Time, Mexico City";
$l['timezone_gmt_minus_500'] = "(GMT -5:00) Eastern Time, Bogota, Lima, Quito";
$l['timezone_gmt_minus_450'] = "(GMT -4:30) Caracas";
$l['timezone_gmt_minus_400'] = "(GMT -4:00) Atlantic Time, La Paz, Halifax";
$l['timezone_gmt_minus_350'] = "(GMT -3:30) Newfoundland";
$l['timezone_gmt_minus_300'] = "(GMT -3:00) Brazil, Buenos Aires, Georgetown, Falkland Is.";
$l['timezone_gmt_minus_200'] = "(GMT -2:00) Mid-Atlantic, South Georgia and the South Sandwich Islands";
$l['timezone_gmt_minus_100'] = "(GMT -1:00) Azores, Cape Verde Islands";
$l['timezone_gmt'] = "(GMT) Casablanca, Dublin, Edinburgh, London, Lisbon, Monrovia";
$l['timezone_gmt_100'] = "(GMT +1:00) Berlin, Brussels, Copenhagen, Madrid, Paris, Rome, Warsaw";
$l['timezone_gmt_200'] = "(GMT +2:00) Athens, İstanbul, Cairo, Jerusalem, South Africa";
$l['timezone_gmt_300'] = "(GMT +3:00) Kaliningrad, Minsk, Baghdad, Riyadh, Nairobi";
$l['timezone_gmt_350'] = "(GMT +3:30) Tehran";
$l['timezone_gmt_400'] = "(GMT +4:00) Moscow, Abu Dhabi, Baku, Muscat, Tbilisi";
$l['timezone_gmt_450'] = "(GMT +4:30) Kabul";
$l['timezone_gmt_500'] = "(GMT +5:00) Islamabad, Karachi, Tashkent";
$l['timezone_gmt_550'] = "(GMT +5:30) Mumbai, Calcutta, Madras, New Delhi";
$l['timezone_gmt_575'] = "(GMT +5:45) Kathmandu";
$l['timezone_gmt_600'] = "(GMT +6:00) Almaty, Dhakra, Yekaterinburg";
$l['timezone_gmt_650'] = "(GMT +6:30) Yangon";
$l['timezone_gmt_700'] = "(GMT +7:00) Bangkok, Hanoi, Jakarta";
$l['timezone_gmt_800'] = "(GMT +8:00) Beijing, Hong Kong, Perth, Singapore, Taipei, Manila";
$l['timezone_gmt_850'] = "(GMT +8:30) Pyongyang";
$l['timezone_gmt_875'] = "(GMT +8:45) Eucla";
$l['timezone_gmt_900'] = "(GMT +9:00) Osaka, Sapporo, Seoul, Tokyo, Irkutsk";
$l['timezone_gmt_950'] = "(GMT +9:30) Adelaide, Darwin";
$l['timezone_gmt_1000'] = "(GMT +10:00) Melbourne, Papua New Guinea, Sydney, Yakutsk";
$l['timezone_gmt_1050'] = "(GMT +10:30) Lord Howe Island";
$l['timezone_gmt_1100'] = "(GMT +11:00) Magadan, New Caledonia, Solomon Islands, Vladivostok";
$l['timezone_gmt_1150'] = "(GMT +11:30) Norfolk Island";
$l['timezone_gmt_1200'] = "(GMT +12:00) Auckland, Wellington, Fiji, Marshall Islands";
$l['timezone_gmt_1275'] = "(GMT +12:45) Chatham Islands";
$l['timezone_gmt_1300'] = "(GMT +13:00) Samoa, Tonga, Tokelau";
$l['timezone_gmt_1400'] = "(GMT +14:00) Line Islands";
$l['timezone_gmt_short'] = "GMT {1}({2})";


$l['missing_task'] = "<strong>Hata:</strong> Zamanlanmış Görev Dosyası Yok";
$l['task_backup_cannot_write_backup'] = " <strong>Hata:</strong> Veritabanı Yedeğinizin Yazma İzni Olmadığından Yedekleme Klasörüne Kayıt Edilemedi.";
$l['task_backup_ran'] = "Haftalık Veritabanı Yedekleme Görevi başarıyla tamamlandı.";
$l['task_checktables_ran'] = "Tablo Kontrolü ve Onarım Görevi başarıyla tamamlandı.";
$l['task_checktables_ran_found'] = " <strong>Bilgi:</strong> Tabloların Kontrolü Başarılı Bir Şekilde Tamamlandı ve {1} Tablolar Başarıyla Optimize Edildi.";
$l['task_dailycleanup_ran'] = "Günlük Temizleme Görevi başarıyla tamamlandı.";
$l['task_hourlycleanup_ran'] = "Saatlik Temizleme Görevi başarıyla tamamlandı.";
$l['task_logcleanup_ran'] = "Log Kayıtlarını Temizleme Grevi başarıyla tamamlandı.";
$l['task_promotions_ran'] = "Promosyon Sistemi Görevi başarıyla tamamlandı.";
$l['task_threadviews_ran'] = "Konu Okunma/Gösterim Sayacı Görevi başarıyla tamamlandı.";
$l['task_usercleanup_ran'] = "Yarım Saatte Bir Kullanıcı Temizleme Görevi başarıyla tamamlandı.";
$l['task_userpruning_ran'] = "Kullanıcı Ayıklama/Temizleme Görevi başarıyla tamamlandı.";
$l['task_delayedmoderation_ran'] = "Bekleyen Moderasyon İşlemleri Görevi başarıyla tamamlandı.";
$l['task_massmail_ran'] = "Toplu E-Posta Gönderim Görevi başarıyla tamamlandı.";
$l['task_massmail_ran_errors'] = "\"{1}\": {2} , Gönderme esnasında bir veya daha fazla sorunlar oluştu.";
$l['task_versioncheck_ran'] = "Versiyon/Sürüm Kontrol Görevi başarıyla tamamlandı.";
$l['task_versioncheck_ran_errors'] = "Sürüm kontrolü için MyBB.Com sunucuları ile bağlantı kurulamadı.";
$l['task_recachestylesheets_ran'] = '{1} CSS Stilleri Önbelleğini Güncelleme/Yeniden Oluşturma Görevi başarıyla tamamlandı. (Re-cached)';

$l['dismiss_notice'] = "Bildirimi Kapat";

$l['next'] = "Sonraki";
$l['previous'] = "Önceki";
$l['delete'] = "Sil";

$l['massmail_username'] = "Kullanıcı Adı";
$l['email_addr'] = "E-posta Adresi";
$l['board_name'] = "Forum İsmi";
$l['board_url'] = "Forum Adresi";

$l['comma'] = ", ";

$l['debug_generated_in'] = "Sayfa: {1} oluşturuldu.";
$l['debug_weight'] = "(%{1} PHP / %{2} {3})";
$l['debug_sql_queries'] = "SQL Sorguları: {1}";
$l['debug_server_load'] = "Sunucu Yüklenmesi: {1}";
$l['debug_memory_usage'] = "Bellek Kullanımı: {1}";
$l['debug_advanced_details'] = "Debug Bilgilerini Detaylı İncele";

$l['error_emailflooding_1_second'] = "Üzgünüz, fakat her {1} dakida bir sadece 1 E-Posta gönderebilirsiniz. Lütfen, yeni bir E-Posta göndermeden önce birkaç saniye daha bekleyiniz.";
$l['error_emailflooding_seconds'] = "Üzgünüz, fakat her {1} dakida bir sadece 1 E-Posta gönderebilirsiniz. Lütfen, yeni bir E-Posta göndermeden önce {2} saniye daha bekleyiniz.";
$l['error_emailflooding_1_minute'] = "Üzgünüz, fakat her {1} dakida bir sadece 1 E-Posta gönderebilirsiniz. Lütfen, yeni bir E-Posta göndermeden önce 1 dakika daha bekleyiniz.";
$l['error_emailflooding_minutes'] = "Üzgünüz, fakat her {1} dakida bir sadece 1 E-Posta gönderebilirsiniz. Lütfen, yeni bir E-Posta göndermeden önce {2} dakika daha bekleyiniz.";
$l['error_invalidfromemail'] = "Geçerli bir E-Posta adresi girmediniz.";
$l['error_noname'] = "Geçerli bir isim/nick girmediniz.";
$l['your_email'] = "E-posta Adresiniz:";
$l['email_note'] = "E-posta adresinizi giriniz.";
$l['your_name'] = "İsim/Nick:";
$l['name_note'] = "İsim yada bir Nick giriniz.";

$l['january'] = "Ocak";
$l['february'] = "Şubat";
$l['march'] = "Mart";
$l['april'] = "Nisan";
$l['may'] = "Mayıs";
$l['june'] = "Haziran";
$l['july'] = "Temmuz";
$l['august'] = "Ağustos";
$l['september'] = "Eylül";
$l['october'] = "Ekim";
$l['november'] = "Kasım";
$l['december'] = "Aralık";

$l['moderation_forum_attachments'] = "Bu forumda yeni eklenen ek dosyanın görünür olması için bir yönetici tarafından onaylanması gerekiyor.";
$l['moderation_forum_posts'] = "Bu forumda yeni yazılan yorumların görünür olması için bir yönetici tarafından onaylanması gerekiyor.";
$l['moderation_user_posts'] = "Lütfen yazılan yorumların görünür olması için bir yönetici tarafından onaylanması gerektiğini unutmayın.";
$l['moderation_forum_thread'] = "Bu forumda yeni yeni açılan konuların görünür olması için bir yönetici tarafından onaylanması gerekiyor.";
$l['moderation_forum_edits'] = "Bu forumda düzenlenen konu veya yorumun görünür/geçerli olması için bir yönetici tarafından onaylanması gerekiyor.";
$l['moderation_forum_edits_quick'] = "Bu forumda düzenlenebilir konu veya yorumların görünür/geçerli olması için bir yönetici tarafından onaylanması gerektiğini unutmayın.";
$l['awaiting_message_link'] = " <a rel=\"nofollow\" href=\"{1}/{2}/index.php?module=user-users&amp;action=search&amp;results=1&amp;conditions=a%3A1%3A%7Bs%3A9%3A%22usergroup%22%3Bs%3A1%3A%225%22%3B%7D\">Admin Paneline Git</a>.";
$l['awaiting_message_single'] = "Toplam: <strong>1</strong> yeni kullanıcı aktivasyon bekliyor. Lütfen, admin panelinden aktivasyon bekleyenleri onaylayınız.";
$l['awaiting_message_plural'] = "Toplam: <strong>{1}</strong> yeni kullanıcı aktivasyon bekliyor. Lütfen, admin panelinden aktivasyon bekleyenleri onaylayınız.";

$l['select2_match'] = "Bir sonuç mevcut, gezinmek için aşağı ve yukarı ok tuşlarını kullanın.";
$l['select2_matches'] = "{1} sonuç mevcut, gezinmek için aşağı ve yukarı ok tuşlarını kullanın.";
$l['select2_nomatches'] = "Hiçbir sonuç bulunamadı";
$l['select2_inputtooshort_single'] = "Lütfen, bir veya daha fazla karakter giriniz";
$l['select2_inputtooshort_plural'] = "En az {1} karakter giriniz";
$l['select2_inputtoolong_single'] = "Lütfen, bir karakter silin";
$l['select2_inputtoolong_plural'] = "Lütfen, {1} karakter silin";
$l['select2_selectiontoobig_single'] = "Yanlızca bir öge seçebilirsiniz";
$l['select2_selectiontoobig_plural'] = "Yanlızca, {1} öge seçebilirsiniz";
$l['select2_loadmore'] = "Sonuçlar yükleniyor&hellip";
$l['select2_searching'] = "Aranıyor&hellip;";

$l['stopforumspam_error_decoding'] = 'StopForumSpam.com veri-leri çözme hatası.';
$l['stopforumspam_error_retrieving'] = 'StopForumSpam.com verileri alınırken hata oluştu.';
$l['stopforumspam_invalid_email'] = 'StopForumSpam.Com API\sine göre geçersiz bir e-posta adresi girdiniz.';
$l['stopforumspam_invalid_ip_address'] = 'StopForumSpam.Com Apı\sine göre geçersiz bir IP adresi girdiniz.';

$l['sfs_error_username'] = 'Kullanıcı Adı';
$l['sfs_error_ip'] = 'IP adresi';
$l['sfs_error_email'] = 'E-posta adresi';
$l['sfs_error_or'] = 'veya';

$l['boardclosed_reason'] = 'Bu forum onarım ve bakım çalışmalarından dolayı kısa bir süreliğine kapalıdır.<br />Lütfen daha sonra tekrar ziyaret ediniz.<br /> Anlayışınız için teşekkürler.';