<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Turkish Translation: MCTR Team - XpSerkan
 * Copyright © 2014 TR - MyBBGrup & MCTR Team, All Rights Reserved
 * Last Edit: 30.07.2014 / 11:48 - (XpSerkan)
 */

/*
 * Custom Help Document Translation Format
 *
 * // Help Document {hid}
 * $l['d{hid}_name'] = "Belge Adı";
 * $l['d{hid}_desc'] = "Belge Açıklaması";
 * $l['d{hid}_document'] = "Belge Metni-(text)";
 */
