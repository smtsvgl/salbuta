<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 * 
 * MyBB 1.8 Türkçe Dil Paketi
 * Copyright © 2014 TR - MyBBGrup - MCTR Team, Tüm Hakları Saklıdır.
 * Türkçe Çeviri/Turkish Translation: Machine - MCTR Team - http://mybb.com.tr
 * Website: https://huseyinkorbalta.com
 * Son Güncelleme/Last Edit: 14.01.2018 Saat: 00:35 - Machine
 */

$l['nav_newreply'] = "Yeni Yorum";

$l['post_reply_to'] = "{1} - Yeni Yorum Gönder";
$l['post_new_reply'] = "Yeni Yorum Gönder";
$l['reply_to'] = "{1}: Konusuna Yorum Yaz";
$l['post_subject'] = "Yorum Başlığı:";
$l['your_message'] = "Yorum İçeriği:";
$l['post_options'] = "İmza ve İfade Yönetimi:";
$l['options_sig'] = "<strong>İmza Kullanımı:</strong> İmzanız gösterilsin mi?";
$l['options_emailnotify'] = "<strong>E-posta Bildirimi:</strong> Konuya yazılan her Cevap için otomatik E-posta bildirimi almak istiyorum.";
$l['options_disablesmilies'] = "<strong>İfade Kullanımı:</strong> İfadeler devre dışı bırakılsın mı?";
$l['post_reply'] = "Yeni Yorumu Gönder";
$l['preview_post'] = "Önizleme Yap";
$l['mod_options'] = "Moderatör Seçenekleri:";
$l['close_thread'] = "<strong>Konuyu Kapat:</strong> Konu Kapatılsın mı?";
$l['stick_thread'] = "<strong>Konuyu Üstte Tuttur:</strong> Konu Üstte Tutturulsun mu?";
$l['forum_rules'] = "{1} - Kurallar";
$l['thread_review'] = "Konu Gösterimi: (Sizden önce bu konuya yazılmış yorumlar)";
$l['thread_review_more'] = "Bu konuya yazılmış {1} tane yorum var. Konuyu Okumak İçin; <a href=\"{2}\">Buraya</a> Tıklayın.";
$l['posted_by'] = "Yazan";
$l['draft_saved'] = "Yeni Yorumunuz Başarılı Olarak Taslaklara Kayıtlandı.<br />Şimdi Taslak Listenize Yönlendiriliyorsunuz...";
$l['error_post_already_submitted'] = "Siz bu konuya zaten yorum yazmışsınız. Lütfen yorumunuzu okumak için konuyu ziyaret ediniz.";
$l['multiquote_external_one'] = "Bu Konuya Ait 1 Yorum Seçtiniz.";
$l['multiquote_external'] = "Bu Konuya Ait {1} Yorum Seçtiniz.";
$l['multiquote_external_one_deselect'] = "Bu Yorumun Seçimini Kaldır";
$l['multiquote_external_deselect'] = "Bu Yorumların Seçimini Kaldır";
$l['multiquote_external_one_quote'] = "Bu Yorumu Alıntı Yap";
$l['multiquote_external_quote'] = "Çoklu Alıntı Yap";

$l['redirect_newreply'] = "Teşekkürler, yorumunuz başarılı olarak gönderildi.";
$l['redirect_newreply_moderation'] = "<br />Forum yöneticisi, tüm Yeni Konu Ve Yorumları moderasyon işlemi gerektirecek şekilde ayarlamış.<br /> Şimdi Konuya Geri Yönlendiriliyorsunuz...";
$l['redirect_newreply_post'] = "<br />Şimdi Yorumunuza Geri Yönlendiriliyorsunuz...";
$l['redirect_newreplyerror'] = "Üzgünüz, Yorumunuz İçerik Yetersizliğinden Reddedildi.<br />Şimdi Konuya Geri Yönlendiriliyorsunuz...";
$l['redirect_threadclosed'] = "Bu Konuya, Yorum Yazamazsınız. Çünkü Bu Konu Forum Yöneticileri Tarafından Kapatılmıştır.";
$l['error_post_noperms'] = "Bu taslağı düzenlemek için gerekli yetkiniz yok.";

$l['error_stop_forum_spam_spammer'] = 'Üzgünüz, {1} veritabanımızda kayıtlı bilinen bir spam olarak algılandı. Eğer bunun bir hata olduğunu düşünyorsanız lütfen, iletişim bölümünden forum yöneticisi ile irtibat kurunuz.';
$l['error_stop_forum_spam_fetching'] = 'Üzgünüz, hesabınızın bilinen bir spam olup olmadığını sorgulama sırasında veritabanında bir hata oluştu. Lütfen daha sonra tekrar deneyiniz.';

$l['error_suspendedposting'] = "Üzgünüz, yeni Konu ve Yorum gönderimleriniz; {1} askıya alındı.<br /><br />

Askıya Alınma Tarihi: {2}";
$l['error_suspendedposting_temporal'] = "{1} Tarihine kadar";
$l['error_suspendedposting_permanent'] = "Süresiz olarak";

