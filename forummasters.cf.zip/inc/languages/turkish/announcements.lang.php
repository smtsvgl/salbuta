<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8 Türkçe Dil Paketi
 * Copyright © 2014 TR - MyBBGrup - MCTR Team, Tüm Hakları Saklıdır.
 * Türkçe Çeviri/Turkish Translation: Machine - MCTR Team - http://mybb.com.tr
 * Website: https://huseyinkorbalta.com
 * Son Güncelleme/Last Edit: 13.01.2018 Saat: 23:43 - Machine
 */

$l['nav_announcements'] = "Forum Duyurusu";
$l['announcements'] = "Duyuru";
$l['forum_announcement'] = "Forum Duyurusu: {1}";
$l['error_invalidannouncement'] = "Belirtilen forum duyurusu geçersiz.";

$l['announcement_edit'] = "Bu Duyuruyu Düzenle";
$l['announcement_qdelete'] = "Bu Duyuruyu Sil";
$l['announcement_quickdelete_confirm'] = "Bu duyuruyu kalıcı olarak silmek istediğinizden emin misiniz?";

