<?php
$l['myalerts'] = 'Bildirimler';

$l['myalerts_page_title'] = 'Son Bildirimler';
$l['myalerts_page_getnew'] = 'Yeni bildirimleri kontrol edin.';

$l['myalerts_alerts'] = 'Bildirimler';

$l['myalerts_settings_page_title'] = 'Bildirim Ayarları';

$l['myalerts_online_location_listing'] = 'Bildirimlerini görüntülüyor';

$l['myalerts_unread_title'] = 'Okunmamış bildirimler';

$l['myalerts_no_alerts'] = 'Yeni bir bildirim bulunmamaktadır.';
$l['myalerts_rep'] = '{1} adlı kullanıcı rep puanınızı düzenledi.';
$l['myalerts_pm'] = '{1} adlı kullanıcı size bir özel mesaj gönderdi.Özel mesajın başlığı <b>"{2}"</b>.';
$l['myalerts_buddylist'] = '{1} adlı kullanıcı sizi arkadaş listesine ekledi.';
$l['myalerts_quoted'] = '{1} adlı kullanıcı şu mesajınızı alıntı yaptı <i>Bkz:</i> <b>"{2}"</b>.';
$l['myalerts_post_threadauthor'] = '{1} adlı kullanıcı {2} adlı konunuza yorum yazdı. Bu yorumdan sonra başka yorumlarda gelmiş olabilir,kontrol edin.';
$l['myalerts_subscribed_thread'] = '{1} adlı kullanıcı konunuza cevap yazarak abone oldu.<i>Bkz:</i><b>"{2}"</b>.';

$l['myalerts_setting_rep'] = 'Rep puanınızla ilgili gelişmelerden haberdar olmak ister misiniz ?';
$l['myalerts_setting_pm'] = 'Size özel mesaj geldiğinde uyarı/bildirim almak ister misiniz ?';
$l['myalerts_setting_buddylist'] = 'Bir kullanıcı sizi arkadaş listesine eklediğinde bildirim almak ister misiniz?';
$l['myalerts_setting_quoted'] = 'Bir kullanıcı yorumunuzu alıntı yaptığında bildirim almak ister misiniz?';
$l['myalerts_setting_post_threadauthor'] = 'Açtığınız konulara cevap/yorum geldiğinde bildirim almak ister misiniz?';
$l['myalerts_setting_subscribed_thread'] = 'Açtığınız konuya bir kullanıcı abone olduysa bildirim almak ister misiniz?';
$l['myalerts_settings_save'] = 'Ayarları Kaydet';
$l['myalerts_settings_updated'] = 'Bildirim ayarlarınız başarıyla kaydedilmiştir.Şimdi bildirim ayarlarına geri yönlendiriliyorsunuz...';
$l['myalerts_settings_updated_title'] = 'Bildirim ayarları güncellendi.';

$l['myalerts_delete_deleted'] = 'Bildirim başarıyla silindi.';
$l['myalerts_delete_error'] = 'Bildiriminiz şuanda silinemez durumda.Lütfen daha sonra tekrar deneyin.';
$l['myalerts_delete_read_confirm'] = 'Okunmuş tüm bildirimleri silmek istediğinize emin misiniz? Bu işlemin geri dönüşü yoktur!';
$l['myalerts_delete_all_confirm'] = 'Tüm bildirimleri silmek istediğinizden emin misiniz? Bu işlemin geri dönüşü yoktur!';
$l['myalerts_delete_mass_deleted'] = 'Bildirimler silindi.';
$l['myalerts_delete_all'] = 'Tüm bildirimler başarıyla silinmiştir.';

$l['myalerts_usercp_nav'] = 'Bildirimler';
$l['myalerts_usercp_nav_alerts'] = 'Tümünü görüntüle';
$l['myalerts_usercp_nav_settings'] = 'Bildirim Ayarları';
$l['myalerts_usercp_nav_delete_read'] = 'Eski Bildirimleri Sil';
$l['myalerts_usercp_nav_delete_all'] = 'Tümünü sil';

$l['myalerts_error_alert_not_found'] = 'Bildirim bulunamadı.';

$l['myalerts_delete'] = 'Sil';
