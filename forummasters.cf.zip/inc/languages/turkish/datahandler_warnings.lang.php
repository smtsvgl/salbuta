<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Turkish Translation: MCTR Team - XpSerkan
 * Copyright © 2014 TR - MyBBGrup & MCTR Team, All Rights Reserved
 * Last Edit: 01.08.2014 / 05:19 - (XpSerkan)
 */

$l['warnings_reached_max_warnings_day'] = 'Bu kullanıcının daha önce {1} süreliğine uyarı aldığı görülüyor.<br /><br />Tekrar uyarı verebilmek için uyarı süresinin dolması gerekli.';
$l['warnings_error_invalid_user'] = "Seçilen kullanıcı yok.";
$l['warnings_error_invalid_post'] = "Seçilen mesaj yok.";
$l['warnings_error_cannot_warn_self'] = "Kendi kendinize uyarı veremezsiniz.";
$l['warnings_error_user_reached_max_warning'] = "Bu kullanıcı, maksimum uyarı limitini aştığı için uyarılamaz.";
$l['warnings_error_no_note'] = "Bu uyarı için herhangi bir yönetici notu girmediniz.";
$l['warnings_error_invalid_type'] = "Geçersiz bir uyarı türü seçtiniz.";
$l['warnings_error_cant_custom_warn'] = "Kullanıcılara özel uyarı verme iznine sahip değilsiniz.";
$l['warnings_error_no_custom_reason'] = "Özel uyarı için bir sebep girmediniz.";
$l['warnings_error_invalid_custom_points'] = "Bu kullanıcının uyarı puanına ekleme yapmak yada uyarı puanını güncellemek için geçerli bir değer girmediniz. Ortalama: <b>0</b> ila <b>{1}</b> arası bir değer girmeniz gerekiyor.";
$l['warnings_error_invalid_expires_period'] = "Geçersiz bir uyarı bitiş türü seçtiniz.";
