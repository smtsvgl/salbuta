<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8 Türkçe Dil Dosyası
 * Türkçe Çeviri: Machine (Hüseyin KÖRBALTA)
 * Website: http://mybb.com.tr - http://mybbdepo.com
 * Kişisel blog: https://huseyinkorbalta.com
 * Son Güncelleme: 14.06.2019 - Saat: 18:17
 */

$l['nav_helpdocs'] = "Yardım Dokümanları";
$l['nav_smilies'] = "Smilie Listesi";
$l['nav_syndication'] = "Son Konu Senkronizasyonu (RSS)";

$l['skype'] = "Skype";
$l['yahoo_im'] = "Yahoo IM";
$l['skype_center'] = "Skype Merkezi";
$l['chat_on_skype'] = "Chat with {1} on Skype";
$l['call_on_skype'] = "Call {1} on Skype";
$l['yahoo_center'] = "Yahoo! Merkezi";

$l['send_me_instant'] = "Bana Anlık Mesaj Gönderin";
$l['add_me_buddy_list'] = "Beni Arkadaş Listene ekle";
$l['add_remote_to_page'] = "Sayfanıza Uzaktan Kumanda Ekleyin";

$l['buddy_list'] = "Buddy List";
$l['online'] = "Çevrim İçi";
$l['online_none'] = "<em>Çevrimiçi arkadaşınız yok</em>";
$l['offline'] = "Çevrim Dışı";
$l['offline_none'] = "<em>Çevrimdışı arkadaşınız yok</em>";
$l['delete_buddy'] = "X";
$l['pm_buddy'] = "Özel mesaj gönder";
$l['last_active'] = "<strong>Son Aktif:</strong> {1}";
$l['close'] = "Kapat";
$l['no_buddies'] = "<em>Arkadaş listeniz şu anda boş. Kullanıcıları arkadaş listenize eklemek için Kullanıcı CP'nizi kullanın veya bir kullanıcı profilini ziyaret edin.</em>";

$l['help_docs'] = "Yardım Dökümanları";

$l['search_help_documents'] = "Yardım Dökümanlarında Ara";
$l['search_by_name'] = "İsim Ara";
$l['search_by_document'] = "Yardım Dökümanlarında Ara";
$l['enter_keywords'] = "Anahtar Kelime Gir";
$l['search'] = "Ara";
$l['redirect_searchresults'] = "Teşekkürler, aramanız gönderildi ve şimdi sonuçlar listesine yönlendirileceksiniz.";
$l['search_results'] = "Arama Sonuçları";
$l['help_doc_results'] = "Yardım Doküman Sonuçları";
$l['document'] = "Doküman";
$l['error_nosearchresults'] = "Maalesef, sağladığınız sorgu bilgileri kullanılarak hiçbir sonuç gösterilmedi. Lütfen arama terimlerinizi yeniden tanımlayın ve tekrar deneyin.";
$l['no_help_results'] = "Maalesef, sağladığınız sorgu bilgileri kullanılarak hiçbir sonuç gösterilmedi.";
$l['error_helpsearchdisabled'] = "Yardım belgelerinde arama yeteneği, Yönetici tarafından devre dışı bırakıldı.";

$l['smilies_listing'] = "İfadeler Listesi";
$l['name'] = "İsim";
$l['abbreviation'] = "Kısaltma";
$l['click_to_add'] = "Mesajınıza eklemek için bir ifadeyi tıklayın";
$l['close_window'] = "Pencereyi Kapat";
$l['no_smilies'] = "Şu anda herhangi bir ifade yok.";

$l['who_posted'] = "Kim gönderdi?";
$l['total_posts'] = "Toplam Mesaj:";
$l['user'] = "Kullanıcı";
$l['num_posts'] = "# Gönderi";

$l['forum_rules'] = "{1} - Kurallar";

$l['error_invalid_limit'] = "Girdiğiniz feed öğesi sınırı geçersiz. Lütfen geçerli bir limit belirtin.";

$l['syndication'] = "Son Konular RSS Beslemesi";
$l['syndication_generated_url'] = "Oluşturulan RSS URL'si:";
$l['syndication_note'] = "Bu kısımdan, kendinize özel RSS Takip URL bağlantıları oluşturabilirsiniz.<br />Bu bağlantıyı örneğin; <i><a style=\"color: #333;\" href=\"https://vaybak.com\" target=\"_blank\">Sosyal İçerik</a>li</i> bir sitede veya <i><a style=\"color: #333;\" href=\"http://xpserkan.com\" target=\"_blank\">Kişisel Blog</a></i> sitenizdeki widget araçları için RSS takip/akışı aracı olarak kullanabilirsiniz.<br />Bunun için (Tüm Forumlar RSS), sekmesini seçebilir veya menüdeki seçeneklerden besleme almak istediğiniz tek bir kategoriyi/forumu seçebilirsiniz. <strong>Bkz:</strong> <i><a href=\"http://destek.mybb.com.tr/showthread.php?tid=752\" target=\"_blank\">RSS Nedir?</a></i>";
$l['syndication_forum'] = "RSS Besleme URL'si oluşturulacak forumlar:";
$l['syndication_forum_desc'] = "Lütfen sağ taraftaki menüden beslemesini almak istediğiniz bir forum seçiniz. Çoklu veya özel seçim için <b>(Ctrl)</b> tuşunu kullanabilirsiniz. tüm forumların beslemesini almak için <b>(Tüm Forumlar RSS)</b> sekmesine tıklayınız.";
$l['syndication_version'] = "RSS Feed Versiyon Seçimi:";
$l['syndication_version_desc'] = "Lütfen sağ taraftaki seçeneklerden, oluşturmak istediğiniz RSS beslemesinin sürümünü seçiniz.";
$l['syndication_version_atom1'] = "Atom 1.0";

// Yeni eklenen dil satırı [Machine]
$l['syndication_version_json1'] = "JSON Beslemesi 1";

$l['syndication_version_rss2'] = "RSS 2.00 (Varsayılan Sürüm)";
$l['syndication_generate'] = "RSS Besleme URL'sini oluştur";
$l['syndication_limit'] = "Limit Ayarları:";
$l['syndication_limit_desc'] = "Sağ taraftan, sayfa başına gösterilecek, konu sayısını giriniz. Sayfa başına gösterilecek maksimum konu sayısı <b>50</b>'yi geçmemesi tavsiye edilir.";
$l['syndication_threads_time'] = "Sayfa başına gösterilecek, konu sayısını giriniz. (varsayılan seçim 15)";
$l['syndicate_all_forums'] = "Tüm Forumlar RSS";

$l['redirect_markforumread'] = "Seçilen forumlar okundu olarak işaretlendi.";
$l['redirect_markforumsread'] = "Tüm forumlar okundu olarak işaretlendi.";
$l['redirect_forumpasscleared'] = "Bu forum için kullanılan şifre başarılı olarak temizlendi.";
$l['redirect_cookiescleared'] = "Tüm çerezler başarılı olarak silindi.";

$l['error_invalidforum'] = "Geçersiz forum";
$l['error_invalidhelpdoc'] = "Belirtilen Yardım Belgesi Bulunamıyor.";
$l['error_invalidimtype'] = "Bu Kullanıcının Profil Bilgilerinde, Hiçbir İletişim Bilgisi Belirtilmemiş.";
$l['error_invalidsearch'] = "Geçersiz bir arama tespit edildi. Lütfen geri dönün ve tekrar deneyin.";
$l['error_no_search_support'] = "Veritabanı sistemi bu aramayı desteklemiyor.";
$l['error_searchflooding'] = "Üzgünüz, fakat arama sistemini sadece {1} saniyede bir kullanabilirsiniz. Tekrar arama yapabilmek için lütfen, {2} saniye daha bekleyin.";
$l['error_searchflooding_1'] = "Üzgünüz, fakat arama sistemini sadece {1} saniyede bir kullanabilirsiniz. Tekrar arama yapabilmek için lütfen, 1 saniye daha bekleyin.";

$l['dst_settings_updated'] = "Yaz saati zaman ayarları otomatik olarak ayarlanmıştır.<br /><br />Şimdi Forum Ana Sayfasına Yönlendiriliyorsunuz...";