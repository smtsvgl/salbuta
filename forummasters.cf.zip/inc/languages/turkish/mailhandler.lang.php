<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Turkish Translation: MCTR Team - XpSerkan
 * Copyright © 2014 TR - MyBBGrup & MCTR Team, All Rights Reserved
 * Last Edit: 10.08.2014 / 15:59 - (XpSerkan)
 */

$l['error_no_connection'] = "Sunucu İle Bağlantı Kurulurken Bir Hata Oluştu:";
$l['error_no_message'] = "Hiçbir Mesaj Belirtilmemiş.";
$l['error_no_subject'] = "Hiçbir Konu Belirtilmemiş.";
$l['error_no_recipient'] = "Hiçbir Alıcı Belirtilmemiş.";
$l['error_not_sent'] = "Hata: PHP Mail Fonksiyonu, Mail Göndermeye Çalışırken Bir Sorunla Karşılaştı. Lütfen Daha Sonra Tekrar Deneyiniz.";
$l['error_status_missmatch'] = "Sunucuya Dönen Sonuçlar Beklenirken Oluşan Uyumsuzluklar: ";
$l['error_data_not_sent'] = "Şu Veriler Sunucuya Gönderilemedi: ";

$l['error_occurred'] = "Bir Veya Daha Fazla Hata Oluştu. Lütfen Devam Etmeden önce Aşağıdaki Hataları Düzeltiniz.<br />";
