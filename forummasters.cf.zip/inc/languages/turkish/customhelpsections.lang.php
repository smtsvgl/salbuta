<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Turkish Translation: MCTR Team - XpSerkan
 * Copyright © 2014 TR - MyBBGrup & MCTR Team, All Rights Reserved
 * Last Edit: 30.07.2014 / 11:50 - (XpSerkan)
 */

/*
 * Custom Help Section Translation Format
 *
 * // Help Section {sid}
 * $l['s{sid}_name'] = "Bölüm Adı";
 * $l['s{sid}_desc'] = "Bölüm Açıklaması";
 */
