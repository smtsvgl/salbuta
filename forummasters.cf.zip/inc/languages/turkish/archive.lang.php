<?php
/**
 * MyBB 1.8 English Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8 Türkçe Dil Paketi
 * Copyright © 2014 TR - MyBBGrup - MCTR Team, Tüm Hakları Saklıdır.
 * Türkçe Çeviri/Turkish Translation: Machine - MCTR Team - http://mybb.com.tr
 * Website: https://huseyinkorbalta.com
 * Son Güncelleme/Last Edit: 13.01.2018 Saat: 23:43 - Machine
 */

$l['archive_fullversion'] = "Tam Versiyon:";
$l['archive_replies'] = "Yorumlar";
$l['archive_reply'] = "Yorum";
$l['archive_pages'] = "Sayfalar:";
$l['archive_note'] = "Şu anda <strong>arşiv</strong> modunu görüntülemektesiniz. <a href=\"{1}\">Tam versiyonu görüntülemek için buraya</a> tıklayınız.";
$l['archive_nopermission'] = "Üzgünüz, bu kaynağa erişim yetkiniz bulunmuyor.";
$l['error_nothreads'] = "Şu anda bu forumda konu bulunmuyor veya silinmiş olabilir.";
$l['error_nopermission'] = "Bu forumda ki konuları görüntüleyebilmek için yetkiniz bulunmuyor.";
$l['error_unapproved_thread'] = "Bu konu onaylanmamış.Lütfen, bu konuyu <a href=\"{1}\">tam versiyon</a> kısmından görüntüleyiniz.";
$l['archive_not_found'] = "Belirttiğiniz sayfa veya konu bu forumda bulunamadı.";
$l['error_mustlogin'] = "Bu foruma erişebilmeniz için giriş yapmanız gerekiyor. ";