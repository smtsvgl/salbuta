<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Turkish Translation: MCTR Team - XpSerkan
 * Copyright © 2014 TR - MyBBGrup & MCTR Team, All Rights Reserved
 * Last Edit: 20.08.2014 / 00:59 - (XpSerkan)
 */

$l['forums_and_posts'] = "Kategoriler & Forumlar";

$l['forum_management'] = "<img src=\"../images/admincp/arac.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Forumları Yönet";
$l['forum_announcements'] = "<img src=\"../images/admincp/duyuru.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Forum Duyuruları";
$l['moderation_queue'] = "<img src=\"../images/admincp/moderasyon.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Moderasyonlar";
$l['attachments'] = "<img src=\"../images/admincp/ek-dosya.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Ekli Dosyalar";

$l['can_manage_forums'] = "Forumları Yönetebilir Mi?";
$l['can_manage_forum_announcements'] = "Forum Duyurularını Yönetebilir Mi?";
$l['can_moderate'] = "Konular/Yorumlar ve Ekli Dosyaların Moderasyonları Yönetebilir Mi?";
$l['can_manage_attachments'] = "Ekli Dosyaları Yönetebilir Mi?";

