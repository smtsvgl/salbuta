<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Turkish Translation: MCTR Team - XpSerkan
 * Copyright © 2014 TR - MyBBGrup & MCTR Team, All Rights Reserved
 * Last Edit: 05.11.2016 / 15:20 - (XpSerkan)
 */

// Tabs
$l['banning'] = "Kullanıcı Yasakla";
$l['banned_accounts'] = "Yasaklı Kullanıcı Hesapları";
$l['banned_accounts_desc'] = "Buradan, foruma girişi yasaklanmış olan kullanıcıları yönetebilirsiniz.";
$l['ban_a_user'] = "Kullanıcı Yasakla";
$l['ban_a_user_desc'] = "Kullanıcıları buradan yasaklayabilirsiniz.";
$l['edit_ban'] = "Yasak Düzenleme";
$l['edit_ban_desc'] = "Yasaklanmış Kullanıcıların yasak sebebini ve süresini buradan düzenleyebilirsiniz.";
$l['banned_ips'] = "Yasaklı IP Adresleri";
$l['disallowed_usernames'] = "Yasaklı Kullanıcı Adları";
$l['disallowed_email_addresses'] = "Yasaklı E-Posta Adresleri";

// Errors
$l['error_invalid_ban'] = "Düzenlemek için geçersiz bir yasak seçtiniz.";
$l['error_invalid_username'] = "Girmiş olduğunuz kullanıcı adı yok ya da geçersiz.";
$l['error_no_perm_to_ban'] = "Bu kullanıcıyı yasaklama iznine sahip değilsiniz.";
$l['error_already_banned'] = "Bu kullanıcı zaten yasaklanmış grupta ve yenisine eklenemez.";
$l['error_ban_self'] = "Kendinizi yasaklayamazsınız.";
$l['error_no_reason'] = "Bu kullanıcı için bir yasak sebebi girmediniz.";

// Success
$l['success_ban_lifted'] = "Seçilen yasaklama başarılı bir şekilde kaldırıldı.";
$l['success_banned'] = "Seçilen kullanıcı başarılı bir şekilde yasaklandı.";
$l['success_ban_updated'] = "Seçilen yasaklama başarılı bir şekilde güncellendi.";
$l['success_pruned'] = "Seçilen kullanıcının konu ve yorumları başarılı bir şekilde kaldırıldı/silindi.";

// Confirm
$l['confirm_lift_ban'] = "Bu yasağı iptal etmek istediğinizden emin misiniz?";
$l['confirm_prune'] = "Bu kullanıcıya ait tüm konu ve yorumları kaldırmak/silmek istediğinize emin misiniz?";

//== Pages
//= Add / Edit
$l['ban_username'] = "Kullanıcı Adı <em>*</em>";
$l['autocomplete_enabled'] = "Oto-Tamamlama bu alanda aktif.";
$l['ban_reason'] = "Yasak Sebebi";
$l['ban_group'] = "Yasak Grubu <em>*</em>";
$l['ban_group_desc'] = "Bu kullanıcının yasaklanması için yasak grubuna taşınması gerekir.";
$l['ban_time'] = "Yasak Süresi <em>*</em>";

//= Index
$l['user'] = "Kullanıcı Adı";
$l['moderation'] = "Moderasyon İşlemleri";
$l['ban_lifts_on'] = "Bitiş Tarihi";
$l['time_left'] = "Kalan Süre";
$l['permenantly'] = "(Süresiz)";
$l['na'] = "(Süresiz Yasaklı)";
$l['for'] = "";
$l['bannedby_x_on_x'] = "<strong>{1}</strong><br /><small>Yasaklayan: {2}<br />Yasak Tarihi: {3}<br />Yasak Süresi: {4}</small>";
$l['lift'] = "Yasağı Kaldır";
$l['no_banned_users'] = "Şu anda yasaklanmış kullanıcı yok.";
$l['prune_threads_and_posts'] = "Konu & Yorumlarını kaldır";

// Buttons
$l['ban_user'] = "Kullanıcıyı Yasakla";
$l['update_ban'] = "Yasağı Güncelle";
