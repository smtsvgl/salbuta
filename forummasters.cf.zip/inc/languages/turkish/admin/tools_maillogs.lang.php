<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Turkish Translation: MCTR Team - XpSerkan
 * Copyright © 2014 TR - MyBBGrup & MCTR Team, All Rights Reserved
 * Last Edit: 22.08.2014 / 23:29 - (XpSerkan)
 */

$l['user_email_log'] = "Kullanıcı E-posta Kayıtları";
$l['user_email_log_desc'] = "Bir kullanıcıdan, başka bir kullanıcıya gönderilen E-Posta ve (Konuyu Arkadaşına Gönder) aracı ile gönderilen E-Posta kayıtlarını aşağıdaki alanda görüntüleyebilir ve yönetebilirsiniz.";
$l['prune_user_email_log'] = "Kullanıcı E-posta Kayıtlarını Ayıkla";

$l['close_window'] = "Pencereyi Kapat";
$l['user_email_log_viewer'] = "Kullanıcı E-posta Kaydı Takipcisi";
$l['to'] = "Kime";
$l['from'] = "Gönderen";
$l['ip_address'] = "IP Adresi";
$l['subject'] = "E-Posta Başlığı";
$l['date'] = "Tarih";
$l['email'] = "E-Posta";
$l['date_sent'] = "Gönderilme Tarihi";
$l['deleted'] = "Silinmiş";
$l['sent_using_send_thread_feature'] = "E-Posta, (Konuyu Arkadaşına Gönder) aracı ile Gönderilmiş.";
$l['thread'] = "Konu:";
$l['find_emails_by_user'] = "Bu kullanıcı tarafından gönderilen tüm E-Posta kayıtlarını bul";
$l['find'] = "Ara/Bul";
$l['deleted_user'] = "Silinmiş Kullanıcı-(lar)";
$l['email_sent_to_user'] = "Kullanıcıya Gönderilen E-Posta";
$l['email_sent_using_contact_form'] = "E-Posta, (contact.php) iletişim formu ile gönderilmiş.";
$l['no_logs'] = "Şu anda herhangi bir E-Posta kaydı bulunmamaktadır.";
$l['filter_user_email_log'] = "Kullanıcı E-posta Kayıtlarını Filtrele";
$l['username_is'] = "Kullanıcı Adı";
$l['email_contains'] = "E-posta Adresi";
$l['subject_contains'] = "E-posta Başlığı";
$l['find_emails_to_user'] = "Bu kullanıcıya gönderilmiş olan tüm E-Postaları bul";

$l['error_invalid_user'] = "Belirtmiş olduğunuz kullanıcı mevcut değil.";

