<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Turkish Translation: MCTR Team - XpSerkan
 * Copyright © 2014 TR - MyBBGrup & MCTR Team, All Rights Reserved
 * Last Edit: 22.08.2014 / 23:57 - (XpSerkan)
 */

$l['optimize_database'] = "Veritabanını Optimize Et";

$l['table_selection'] = "Tablo Seçimi";
$l['tables_select_desc'] = "İşlem yapmak istediğiniz veritabanı tablolarını tekil ya da çoğul olarak seçerek, Optimize ve Analiz işlemini yapabilirsiniz.";
$l['select_all'] = "Tümünü Seç";
$l['deselect_all'] = "Tümünün Seçimini Kaldır";
$l['select_forum_tables'] = "Forum Tablolarını Seç";
$l['optimize_selected_tables'] = "Seçilen Tabloları Optimize Et";

$l['error_no_tables_selected'] = "Optimize etmek için hiçbir veritabanı tablosu seçmediniz.";

$l['success_tables_optimized'] = "Seçilen tablolar başarı olarak Optimize ve Analiz edildi.";

