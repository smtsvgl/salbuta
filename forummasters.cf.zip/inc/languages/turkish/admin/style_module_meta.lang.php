<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Turkish Translation: MCTR Team - XpSerkan
 * Copyright © 2014 TR - MyBBGrup & MCTR Team, All Rights Reserved
 * Last Edit: 20.08.2014 / 01:17 - (XpSerkan)
 */

$l['templates_and_style'] = "Temalar & Şablonlar";

$l['themes'] = "<img src=\"../images/admincp/tema.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Temalar";
$l['templates'] = "<img src=\"../images/admincp/sablon.png\" style=\"vertical-align: middle;\" width=\"14\" height=\"14\" alt=\"\" border=\"0\"> Şablonlar";

$l['can_manage_themes'] = "Temaları Yönetebilir Mi?";
$l['can_manage_templates'] = "Şablonları Yönetebilir Mi?";

