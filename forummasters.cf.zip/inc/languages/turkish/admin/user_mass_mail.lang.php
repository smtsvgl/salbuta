<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8 Türkçe Dil Dosyası Paketi
 * Türkçe Çeviri: Machine (Hüseyin KÖRBALTA)
 * Website: http://mybb.com.tr - http://mybbdepo.com
 * Kişisel blog: https://huseyinkorbalta.com
 * Son Güncelleme: 14.06.2019 - Saat: 21:56
 */

$l['mass_mail'] = "Toplu E-Posta";

$l['mass_mail_queue'] = "Toplu E-Posta Durumu";
$l['mass_mail_queue_desc'] = "Bu kısımdan, şimdi gönderilmekte olan ya da daha ileri bir zamanda gönderilecek olan toplu E-Postaları takip edebilir ve düzenleyebilirsiniz.";
$l['create_mass_mail'] = "Yeni E-Posta Gönder";
$l['create_mass_mail_desc'] = "Bu kısımdan, yeni bir toplu E-Posta oluşturabilir ve ayarlarını yönetebilirsiniz.";
$l['mass_mail_archive'] = "Toplu E-Posta Arşivi";
$l['mass_mail_archive_desc'] = "Bu kısımdan, daha önceden gönderilmiş olan toplu E-Postaların kayıtlarını inceleyebilirsiniz.";
$l['edit_mass_mail'] = "Toplu E-Posta Düzenle";
$l['edit_mass_mail_desc'] = "Bu kısımdan, kayıtlı/taslak bir toplu E-Postanın seçeneklerini düzenleyebilirsiniz.";
$l['send_mass_mail'] = "Toplu E-Posta Gönder";

$l['email_addr'] = "E-Posta Adresi Ekle";
$l['board_name'] = "Forum Adı Ekle";
$l['board_url'] = "Forum Linki Ekle";
$l['personalize_message'] = "Bu Mesajı Kişiselleştirin:";

$l['message_settings'] = "Mesaj Ayarları";
$l['subject'] = "E-Posta Başlığı";
$l['subject_desc'] = "Lütfen E-Posta başlığını giriniz.";
$l['send_via_email'] = "E-Posta Yoluyla Gönder";
$l['send_via_pm'] = "Özel Mesaj (Ö.M) Yoluyla Gönder";
$l['message_type'] = "Gönderim Metodu";
$l['deliver_immediately'] = "Hemen Gönder";
$l['deliver_specific'] = "Belirli Bir Tarihte Gönder";
$l['delivery_date'] = "Gönderim Tarihi";
$l['delivery_date_desc'] = "Lütfen, E-Postayı göndermek istediğiniz zaman aralığını seçin";
$l['per_page'] = "Sayfa Başına";
$l['per_page_desc'] = "Lütfen sayfa başına gönderilecek E-Posta sayısını giriniz.";
$l['plain_text_only'] = "Sadece Düz Metin";
$l['html_only'] = "Sadece HTML";
$l['html_and_plain_text'] = "HTML ve Düz Metin";
$l['message_format'] = "Mesaj İçeriği Formatı";
$l['define_html_message'] = "HTML Mesajı Tanımla";
$l['define_html_message_desc'] = "Lütfen HTML mesajınızı giriniz";
$l['auto_gen_plain_text'] = "Otomatik metin formatı oluşturmayı dene";
$l['define_text_version'] = "Metin Formatı Tanımla";
$l['define_text_version_desc'] = "Lütfen metin formatını mesaja giriniz";
$l['define_the_recipients'] = "Alıcıları Tanımla";
$l['username_contains'] = "Şu Kullanıcı adına:";
$l['email_addr_contains'] = "Şu E-Posta Adresine:";
$l['members_of'] = "Şu Kullanıcı Gruplarına:";
$l['greater_than'] = "Daha Fazla";
$l['is_exactly'] = "Tam Olarak";
$l['less_than'] = "Daha Az";
$l['more_than'] = "Daha Fazla";
$l['post_count_is'] = "Şu Mesaj Sayısı Aralığında ki Kullanıcılara:";
$l['hours'] = "Saat";
$l['days'] = "Gün";
$l['weeks'] = "Hafta";
$l['months'] = "Ay";
$l['years'] = "Yıl";
$l['ago'] = "";
$l['user_last_active'] = "Şu Zaman Aralığında Kayıt Olan Kullanıcılara:";
$l['user_registered'] = "Şu Zaman Aralığında Aktif Olan Kullanıcılara:";
$l['save_mass_mail'] = "Toplu E-Postayı Kaydet";

$l['step_four'] = "Aşama 4 &raquo;";
$l['delivery_method'] = "Gönderim Metodu";
$l['private_message'] = "Özel Mesaj (Ö.M) Yoluyla";
$l['email'] = "E-Posta Yoluyla";
$l['subject'] = "E-Posta Başlığı";
$l['message'] = "Mesaj İçeriği";
$l['text_based'] = "Düz Metin";
$l['preview'] = "Önizleme";
$l['mass_mail_preview'] = "Toplu Maili Önizle";
$l['html_based'] = "HTML Tabanlı";
$l['total_recipients'] = "Toplam Alıcı";
$l['change_recipient_conds'] = "Alıcı Şartlarını Düzenle";
$l['review_message'] = "Mesajı Gözden Geçir";
$l['define_delivery_date'] = "Teslim Tarihi Belirle";
$l['schedule_for_delivery'] = "E-Postayı Gönder/Programla";
$l['username'] = "Kullanıcı Adı Ekle";

$l['step_three'] = "Aşama 3 &raquo;";
$l['next_step'] = "Sonraki Adım &raquo;";

$l['step_two'] = "Aşama 2 &raquo;";
$l['review_text_version'] = "Metin Formatını Gözden Geçir";
$l['review_text_version_desc'] = "Lütfen otomatik oluşan metin formatını gözden geçirin";

$l['step_one'] = "Aşama 1 &raquo;";

$l['status'] = "E-Posta Durumu";
$l['recipients'] = "Alıcılar";
$l['delivered'] = "Gönderildi";
$l['canceled'] = "İptal Edildi";
$l['resend'] = "Tekrar Gönder";
$l['no_archived_messages'] = "Daha önce gönderilmiş ya da iptal edilmiş herhangi bir toplu E-Posta mevcut değil.";

$l['draft'] = "Taslak Oluşturuldu";
$l['queued'] = "Beklemede";
$l['delivering'] = "Gönderiliyor...";
$l['na'] = "Mevcut Değil";
$l['mass_mail_cancel_confirmation'] = "Bu toplu E-Postanın gönderilmesini iptal etmek istediğinizden emin misiniz?";
$l['no_unsent_messages'] = "Gönderilmemiş, bekleyen ya da şu an gönderilen toplu E-Posta bulunmamaktadır.";

$l['error_invalid_mid'] = "Geçersiz bir toplu E-Posta mesajı seçtiniz";
$l['error_only_in_future'] = "Toplu E-Postaları sadece ileriki bir zamanda teslim edebilirsiniz.";
$l['error_no_users'] = "Arama terime uyan herhangi bir kullanıcı bulunamadı. Lütfen, farklı bir arama terimi girerek tekrar deneyin.";
$l['error_missing_plain_text'] = "Bu mesaj içeriği için bir düz metin formatı girmediniz.";
$l['error_missing_subject'] = "Bu toplu E-Posta için bir başlık girmediniz.";
$l['error_missing_message'] = "Gönderilecek bir mesaj içeriği girmediniz";
$l['error_missing_html'] = "Bu mesaj için bir HTML versiyonu girmediniz.";
$l['error_delete_invalid_mid'] = "Silmek için geçersiz bir toplu E-Posta seçtiniz.";

$l['success_mass_mail_saved'] = "Toplu E-Posta başarılı bir şekilde kaydedildi";
$l['success_mass_mail_deleted'] = "Seçilen toplu E-Posta başarılı bir şekilde silindi.";
$l['success_mass_mail_resent'] = "Toplu E-Posta başarılı bir şekilde kopyalandı. Lütfen aşağıdan inceleyin.";
$l['success_mass_mail_canceled'] = "Toplu E-Posta gönderimi, başarılı bir şekilde iptal edildi.";

$l['mass_mail_deletion_confirmation'] = "Bu toplu E-Postayı silmek istediğinizden emin misiniz?";