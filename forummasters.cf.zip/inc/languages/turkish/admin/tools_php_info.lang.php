<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Turkish Translation: MCTR Team - XpSerkan
 * Copyright © 2014 TR - MyBBGrup & MCTR Team, All Rights Reserved
 * Last Edit: 22.08.2014 / 23:57 - (XpSerkan)
 */

$l['php_info'] = "PHP Bilgileri";
$l['browser_no_iframe_support'] = "Tarayıcınız iframeleri desteklemiyor. Lütfen, farklı bir tarayıcı ile deneyiniz.";

