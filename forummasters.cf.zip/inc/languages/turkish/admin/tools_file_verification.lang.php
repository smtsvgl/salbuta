<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8 Türkçe Dil Dosyası Paketi
 * Türkçe Çeviri: Machine (Hüseyin KÖRBALTA)
 * Website: http://mybb.com.tr - http://mybbdepo.com
 * Kişisel blog: https://huseyinkorbalta.com
 * Son Güncelleme: 14.06.2019 - Saat: 19:47
 */

$l['file_verification'] = "Dosya Sistemi Doğrulaması";
$l['checking'] = "Doğrulama İşlemi Yapılıyor...";
$l['file_verification_message'] = "Bu süreçte geçerliliğini kontrol etmek için tüm, varsayılan MyBB dosyalarınızın doğruluğu kontrol edilir.<br />Bu işlemi gerçekleştirebilmek için ''Evet'' tuşuna basın ve devam edin.<br /><small>Lütfen Dikkat! Doğrulama işlemi, yapmış olduğunuz özel modifikasyonlarınızın, orjinal dosyalar ile arasında farkı belirleyemez ve özgünlüğünü kaybetmiş ya da düzenlenmiş dosyalarınız hatalı olarak görülebilir. Bu sebepten dolayı, dosyalarınızın özgünlüğü ve yapmış olduğunuz düzenleme ve özel modifikasyonlarınız silinebilir.</small><br />

<b>Not:</b> Mecbur kalmadıkça, bu bölümü kullanmamanız tavsiye edilir. Eğer kulanacaksanız lütfen, işlem öncesi (full yedek) almayı ihmal etmeyiniz.";
$l['error_communication'] = "Doğrulama sırasında, MyBB forumunuz, sunucu ile bağlantı kurarken hata oluştu. Lütfen, daha sonra tekrar deneyiz.";
$l['file'] = "Dosya";
$l['no_corrupt_files_found'] = "Tebrikler! Sisteminizde yüklü, bozuk ya da özgünlüğünü yitirmiş herhangi bir dosya bulunmadı.";
$l['found_problems'] = "Bulunan Hatalar";
$l['no_problems_found'] = "Herhangi bir sorun bulunamadı";
$l['changed'] = "Değiştirilmiş";
$l['missing'] = "Kayıp";
$l['status'] = "Durum";

