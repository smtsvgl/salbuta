<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Turkish Translation: MCTR Team - XpSerkan
 * Copyright © 2014 TR - MyBBGrup & MCTR Team, All Rights Reserved
 * Last Edit: 29.12.2016 / 04:49 - (XpSerkan)
 */

$l['report_reasons'] = "Rapor Sebepleri";
$l['report_reasons_desc'] = "Bu ayar grubu, kullanıcılar tarafından rapor edilen içerik sebeplerini düzenleme, yeni sebep/kural ekleme ve yönetmenize olana sağlar.";
$l['add_new_reason'] = "Yeni Rapor Sebebi";
$l['add_new_reason_desc'] = "Bu kısımdan, forumunuz için yeni bir rapor sebebi oluşturabilirsiniz.";
$l['edit_reason'] = "Düzenle";
$l['edit_reason_desc'] = "Bu kısımdan, rapor sebebini düzenleyebilirsiniz.";

$l['applies_to'] = "Rapor Tipi";
$l['order'] = "Sıralama";
$l['extra_comment'] = "Rapor Açıklaması?";
$l['options'] = "Seçenekler";
$l['delete_reason'] = "Sil";
$l['no_report_reasons'] = "Şu anda oluşturulmuş hiçbir rapor sebebi mevcut değil.";

$l['reason_title'] = "Rapor Başlığı";
$l['reason_title_desc'] = "Rapor etme sebebi için bir başlık giriniz.";
$l['requires_extra'] = "Rapor Açıklaması Gerektirir Mi?";
$l['requires_extra_desc'] = "Bu seçenek, mevcut rapor sebebi için, rapor etme sebebine dair kullanıcılara ek açıklama alanı eklemenize olanak sağlar. (Rapor sebebi seçilince hemen alt kısmında açıklama girilmesi için metin kutusu gösterilir.)";
$l['save_reason'] = "Rapor Sebebini Kaydet";

$l['content_colon'] = "İçerik:";

$l['all_content'] = "Tüm İçerik";
$l['select_content'] = "İçerik Seç";

// Content types
$l['report_content_'] = "Hiçbiri";
$l['report_content_all'] = "Tümü";
$l['report_content_post'] = "İçerik Raporu";
$l['report_content_profile'] = "Profil Raporu";
$l['report_content_reputation'] = "Rep Puanı Raporu";

// Content reasons
$l['report_reason_rules'] = "Forum Kurallarına Aykırı";
$l['report_reason_bad'] = "Sakıncalı İçerik";
$l['report_reason_spam'] = "Spam İçerik";
$l['report_reason_wrong'] = "Yanlış Giden Bir Şeyler Var";
$l['report_reason_other'] = "Diğer Belirtiniz";

$l['default_report_reason'] = "Varsayılan";
$l['custom_report_reason'] = "Özel";

$l['update_reasons_order'] = "Rapor Sebeplerini Güncelle";

$l['error_cannot_modify_reason'] = "Üzgünüz fakat, bu rapor sebebini değiştiremezsiniz.";
$l['error_cannot_delete_reason'] = "Üzgünüz fakat, bu rapor sebebini silemezsiniz.";
$l['error_invalid_reason'] = "Seçilen rapor sebebi geçersiz.";
$l['error_missing_title'] = "Bu rapor sebebi için bir başlık girmediniz.";
//$l['error_missing_applies_to'] = "You did not select what content this reason applies to.";
$l['error_missing_extra'] = "Bu rapor sebebi için ek açıklama isteyip istemediğinizi seçmediniz.";

$l['success_reasons_disporder_updated'] = "Rapor sebeplerini görüntüleme sırası başarıyla güncellendi.";
$l['success_reason_created'] = "Rapor sebebi başarıyla oluşturuldu.";
$l['success_reason_updated'] = "Rapor sebebi başarıyla güncellendi.";
$l['success_reason_deleted'] = "Rapor sebebi başarıyla silindi.";

$l['confirm_reason_deletion'] = "Bu rapor sebebini silmek istediğinizden emin misiniz?";

