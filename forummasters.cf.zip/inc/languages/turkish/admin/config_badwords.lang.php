<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8 Türkçe Dil Dosyası Paketi
 * Türkçe Çeviri: Machine (Hüseyin KÖRBALTA)
 * Website: http://mybb.com.tr - http://mybbdepo.com
 * Kişisel blog: https://huseyinkorbalta.com
 * Son Güncelleme: 23.08.2018 - Saat: 15:31
 */

$l['bad_words'] = "Kelime Filtreleme";
$l['edit_bad_word'] = "Filtre Düzenleme";
$l['edit_bad_word_desc'] = "Bu kısımdan, kelime filtrelerini düzenleyebilirsiniz.";
$l['bad_word_filters'] = "Kelime Filtreleme";
$l['bad_word_filters_desc'] = "Bu kısımdan, Kelime Filtreleme Sistemini Kullanarak Forumunuzda İstenmeyen Argo (küfürlü) Sözleri Engelleyebilir, Yerine Çıkmasını İstediğiniz Kelimeleri Belirleyebilirsiniz.";

$l['bad_word_desc'] = "Engelemek İstediğiniz Kelimeyi Giriniz.";
$l['bad_word_max'] = "Filtrelemek istediğiniz kelime, en fazla 100 karakter uzunluğunda olmalıdır.";
$l['replacement'] = "Filtrelenen Kelime Yerine Gösterilecek Kelime";
$l['replacement_desc'] = "Filtrelemek İstediğiniz Kelimenin Yerine Çıkacak Olan Kelimeyi Giriniz. Eğer Boş Bırakırsanız Otomatik Olarak Yerine, <b>(***)</b> İşaretleri Gösterilecektir.";
$l['regex'] = "Düzenli İfade";
$l['regex_desc'] = "\"Word\" alanını normal ifade olarak ele alın.";
$l['replacement_word_max'] = "Değiştirmek istediğiniz kelime, en fazla 100 karakter uzunluğunda olmalıdır.";
$l['error_replacement_word_invalid'] = "Filtrelenmiş kelime ile değiştirmek istediğiniz kelime aynı olmamalıdır.";

$l['save_bad_word'] = "Save Filter";
$l['no_bad_words'] = "There are no word filters currently set at this time.";
$l['add_bad_word'] = "Add a Filter";

$l['error_missing_bad_word'] = "Filtrelenecek Kelime Girmediniz.";
$l['error_invalid_bid'] = "Belirtmiş Olduğunuz Filtre Bulunamadı.";
$l['error_bad_word_filtered'] = "Girdiğiniz Kelime Filtresi Zaten Ekli.";
// Yeni eklenen dil satırı. [Machine]
$l['error_invalid_regex'] = "Belirtilen düzenli ifade geçersiz.";

$l['success_added_bad_word'] = "Filtrelenecek Kelime Başarılı Olarak Eklendi.";
$l['success_deleted_bad_word'] = "Filtrelenecek Kelime Başarılı Olarak Silindi.";
$l['success_updated_bad_word'] = "Filtrelenecek Kelime Başarılı Olarak Güncellendi.";

$l['confirm_bad_word_deletion'] = "Filtrelemiş Olduğunuz Bu Kelimeyi Silmek İstediğinizden Emin Misiniz?";