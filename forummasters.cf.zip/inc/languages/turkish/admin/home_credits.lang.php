<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Turkish Translation: MCTR Team - XpSerkan
 * Copyright © 2014 TR - MyBBGrup & MCTR Team, All Rights Reserved
 * Last Edit: 26.02.2015 / 16:42 - (XpSerkan)
 */

$l['mctr_credits'] = "MyBB.Com.TR Ekibi";
$l['mctr_credits_description'] = "Aşağıda Listelenmiş Olan Kişiler, MyBB Forum Scriptinin Türkiye Resmi Destek Temsilcileri ve Geliştiricileridir.";
$l['about_mctr_team'] = "Ekip Hakkında";

$l['mybb_credits'] = "MyBB.Com Ekibi";
$l['mybb_credits_description'] = "Aşağıda Listelenmiş Olan Kişiler, MyBB Forum Scriptinin Üretici ve Geliştiricileridir.";
$l['about_the_team'] = "Ekip Hakkında";

$l['check_for_updates'] = "Revizyon Kontrolü";
$l['error_communication'] = "Revizyon kontrolü yapılırken bir hata oluştu. Lütfen, daha sonra tekrar deneyiniz.";
$l['no_credits'] = "Hiçbir değişiklik mevcut değil. <a rel=\"nofollow\" href=\"index.php?module=home-credits&amp;fetch_new=1\">Güncellemeleri Kontrol Et</a>.";
$l['success_credits_updated'] = 'MyBB Ekip sayfası önbelleği başarıyla güncellendi.';
