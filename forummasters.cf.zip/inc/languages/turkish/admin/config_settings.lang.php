<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8 Türkçe Dil Dosyası Paketi
 * Türkçe Çeviri: Machine (Hüseyin KÖRBALTA)
 * Website: http://mybb.com.tr - http://mybbdepo.com
 * Kişisel blog: https://huseyinkorbalta.com
 * Son Güncelleme: 14.06.2019 - Saat: 18:59
 */

$l['board_settings'] = "Genel Forum Ayarları";
$l['change_settings'] = "Yapılandırma Ayarları";
$l['change_settings_desc'] = "Bu kısımdan, forumunuz için tüm genel ayarları yapılandırabilirsiniz. Aşağıda görmüş olduğunuz ayar grubu listesinden birini seçerek o grubun ayarlarını yönetebilirsiniz.";
$l['add_new_setting'] = "Yeni Ayar Ekle";
$l['add_new_setting_desc'] = "Bu kısımdan forumunuza yeni bir ayar ekleyebilirsiniz.";
$l['modify_existing_settings'] = "Ayar Grubu Düzenle";
$l['modify_existing_settings_desc'] = "Bu kısımdan forumunuzdaki mevcut ayar gruplarını düzenleyebilirsiniz.";
$l['add_new_setting_group'] = "Yeni Ayar Grubu Ekle";
$l['add_new_setting_group_desc'] = "Bu kısımdan bireysel ayarları kategorize edebilir ve yeni bir ayar grubu ekleyebilirsiniz.";
$l['edit_setting_group'] = "Ayar Grubu Düzenle";
$l['edit_setting_group_desc'] = "Bu kısımdan forumunuzdaki mevcut ayar gruplarını düzenleyebilirsiniz.";

$l['title'] = "Ayar Başlığı";
$l['description'] = "Kısa Bilgi";
$l['group'] = "Ayar Grubu";
$l['display_order'] = "Görüntülenme Sırası";
$l['name'] = "Tanımlayıcı";
$l['name_desc'] = "Bu seçenek, benzersiz tanımlayıcı ayarlarında, bu ayar dizilerini, (scriptleri, çevirileri, ve şablonları) referans etmek için kullanılmasına olanak sağlar.";
$l['group_name_desc'] = "Bu tanımlayıcı eşsiz çeviri sistemi için kullanılmaktadır.";
$l['text'] = "Metin";
$l['numeric_text'] = "Sayısal Metin";
$l['textarea'] = "Metin Alanı";
$l['yesno'] = "Evet / Hayır Seçimi";
$l['onoff'] = "Açık / Kapalı Seçimi";
$l['select'] = "Seçilebilir Kutular";
$l['radio'] = "Radyo Düğmeleri";
$l['checkbox'] = "Kontrol Kutuları";
$l['language_selection_box'] = "Dil Seçimi Kutusu";
$l['forum_selection_box'] = "Forum Seçimi Kutusu";
$l['forum_selection_single'] = "Tek Forum Seçimi Kutusu";
$l['group_selection_box'] = "Grup Seçimi Kutusu";
$l['group_selection_single'] = "Tek Grup Seçimi Kutusu";
$l['adminlanguage'] = "Yönetim Dil Seçimi Kutusu";
$l['cpstyle'] = "Kontrol Paneli Stil Seçimi Kutusu";
$l['php'] = "PHP Yapılandırma";
$l['type'] = "Tür";
$l['extra'] = "Esktra";
$l['extra_desc'] = "Eğer bu ayar seçimi, radyo veya kontrol kutusu ise öge listesinde gösterilmesi için (anahtar = öğe) eşleşen bir anahtar kelime giriniz. Anahtar kelimeleri girerken virgül ile ayırınız. Eğer PHP ise PHP için bir değer giriniz.";
$l['value'] = "Değer";
$l['insert_new_setting'] = "Yeni Ayarı Ekle";
$l['edit_setting'] = "Ayarı Düzenle";
$l['delete_setting'] = "Ayarı Sil";
$l['setting_configuration'] = "Ayarları Yapılandır";
$l['update_setting'] = "Ayarı Güncelle";
$l['save_settings'] = "Ayarları Kaydet";
$l['setting_groups'] = "Genel Ayar Grupları";
$l['bbsettings'] = "Ayarlar";
$l['insert_new_setting_group'] = "Yeni Ayar Grubu Ekle";
$l['setting_group_setting'] = "Ayar Grupları / Ayarlar";
$l['order'] = "Sıralama";
$l['delete_setting_group'] = "Ayar Grubunu Sil";
$l['save_display_orders'] = "Görüntülenme Sırasını Kaydet/Güncelle";
$l['update_setting_group'] = "Ayar Grubunu Güncelle";
$l['modify_setting'] = "Ayarı Değiştir";
$l['search'] = "Ara";
$l['plugin_settings'] = "Eklenti Ayarları";

$l['show_all_settings'] = "Tüm Ayar Gruplarını Görüntüle";
$l['settings_search'] = "Ayar Araması..";

$l['confirm_setting_group_deletion'] = "Bu ayar grubunu silmek istediğinizden emin misiniz?";
$l['confirm_setting_deletion'] = "Bu ayarı silmek istediğinizden emin misiniz?";

$l['error_format_dimension'] = "Tanımlanmış olan {1} formatı geçersiz.";
$l['error_field_postmaxavatarsize'] = "Maksimum Avatar Boyutları";
$l['error_field_useravatardims'] = "Varsayılan Avatar Boyutları";
$l['error_field_maxavatardims'] = "Maksimum Avatar Boyutları";
$l['error_field_memberlistmaxavatarsize'] = "Maksimum Görünen Avatar Boyutları";
$l['error_missing_title'] = "Bu ayar için bir başlık girmediniz.";
$l['error_missing_group_title'] = "Bu Ayar Grubu için Bir Başlık Girmediniz.";
$l['error_invalid_gid'] = "Bu Ayar için Geçerli Bir Grup Seçmediniz.";
$l['error_invalid_gid2'] = "Belirtmiş Olduğunuz Ayar Grubu Bağlantısı Yanlış. Lütfen Doğruluğunu Kontrol Ediniz.";
$l['error_missing_name'] = "Bu Ayar için Bir Tanımlayıcı Girmediniz.";
$l['error_missing_group_name'] = "Bu Ayar Grubu için Bir Tanımlayıcı Girmediniz.";
$l['error_invalid_type'] = "Bu Ayar için Geçerli Bir Tür Belirtmediniz.";
$l['error_invalid_sid'] = "Belirtmiş Olduğunuz Ayar Mevcut Değil.";
$l['error_duplicate_name'] = "\"{1}\" Ayarı zaten bir süredir tanımlayıcı olarak kullanılıyor. -- Bu benzersiz ayar olmalıdır.";
$l['error_duplicate_group_name'] = "\"{1}\" Grup ayarı zaten bir süredir tanımlayıcı olarak kullanılıyor. -- Bu benzersiz grup ayarı olmalıdır.";
$l['error_no_settings_found'] = "Belirtmiş olduğunuz terime göre hiçbir ayar bulunamadı.";
$l['error_cannot_edit_default'] = "Varsayılan ayar ve gruplar düzenlenemez veya düzenleme izni kaldırılmış olabilir.";
$l['error_cannot_edit_php'] = "Bu düzenlenemez özel bir ayar türüdür.";
$l['error_ajax_search'] = "Arama ayarlarında bir hata oluştu.";
$l['error_ajax_unknown'] = "Ayarları ararken bilinmeyen bir hata oluştu.";
$l['error_chmod_settings_file'] = " \"./inc/settings.php\" dosyası yazılabilir değil. Lütfen, <strong>./inc/settings.php</strong> dosyasının CHMOD izinlerini 777 yapınız.<br />CHMOD izinleri hakkında ayrıntılı bilgi için: <a href=\"http://destek.mybb.com.tr/showthread.php?tid=6435\" target=\"_blank\" title=\"MyBB CHMOD Ayarları Nedir? - Nasıl Yapılır.\">MyBB CHMOD Ayarları</a> <img src=\"../images/icons/external_link.png\" alt=\"\" width=\"9\" height=\"9\" />sayfasını ziyaret edebilirsiniz.";

$l['success_setting_added'] = "Ayar başarılı olarak oluşturuldu.";
$l['success_setting_updated'] = "Ayar başarılı olarak güncellendi.";
$l['success_setting_deleted'] = "Ayar başarılı olarak silindi.";
$l['success_settings_updated'] = "Ayar başarılı olarak güncellendi.";
$l['success_settings_updated_hiddencaptchaimage'] = '<div class="smalltext" style="font-weight: normal;">Kayıt formundaki <strong>{2}</strong> alanıyla bir sebpten dolayı çakışan <strong>Gizli CAPTCHA</strong> alan ayarının <strong>{1}</strong> olarak döndürülmüş olduğunu unutmayın.</div>';
$l['success_settings_updated_username_method'] = '<div class="smalltext" style="font-weight: normal;">Aynı e-posta adresini kullanarak birden fazla kullanıcı bulunduğundan, <b>Kullanıcı Giriş ve Kayıt Ayarlarındaki</b> ayarın güncellenmediğini unutmayın.</div>';
$l['success_settings_updated_allowmultipleemails'] = '<div class="smalltext" style="font-weight: normal;">Aynı e-posta adresi ile birden fazla kayıt olunmasına izin verilsin mi? <b>Kullanıcı Giriş ve Kayıt Ayarlarında</b>, kullanıcılara e-posta adresiyle giriş yapmalarına olanak sağlandığı için ayar etkinleştirilemez.</div>';
$l['success_settings_updated_captchaimage'] = '<div class="smalltext" style="font-weight: normal;">Genel yapılandırma ayarlarındaki özel Captcha seçenklerinde key olmadığından dolayı, <strong>Kayıt ve Mesaj Gönderme</strong> işlemlerinde <strong>MyBB Default Captcha</strong> aracı aktif edilecektir.</div>';
$l['success_display_orders_updated'] = "Görüntüleme sırası başarılı olarak güncellendi.";
$l['success_setting_group_added'] = "Ayar grubu başarılı olarak oluşturuldu.";
$l['success_setting_group_updated'] = "Ayar grubu başarılı olarak güncellendi.";
$l['success_setting_group_deleted'] = "Ayar grubu başarılı olarak silindi.";
$l['success_duplicate_settings_deleted'] = "Tüm ayar grupları başarılı olarak silindi.";

$l['searching'] = 'Aranıyor...';
$l['search_error'] = 'Arama sonuçları getirilirken bir hata oluştu:';
$l['search_done'] = 'Tamamlandı!';

// Diğer Ayarlar [orjinalinde yoktur - Machine]
// Ayar Grubu 1: "Board Online / Offline"
$l['setting_group_onlineoffline'] = "Forum Kullanıma Açık / Kapalı";
$l['setting_group_onlineoffline_desc'] = "Bu ayar grubu, forumunuzun kullanıma açık veya kapalı, olup olmadığını yönetmenizi ve aynı zamanda forumun neden kapalı olduğuna dair açıklama yazısı göstermenizide sağlar.";
// 1 Nolu Ayar Grubu Seçenekleri
$l['setting_boardclosed'] = "Forumu Kullanıma Aç / Kapat";
$l['setting_boardclosed_desc'] = "Eğer forumunuzda bakım ve onarım veya güncelleme yapıyorsanız, aşağıdaki <strong>Evet</strong> seçeneğini kullanarak forumunuzu kullanıma kapatabilir ve kullanıcıların forumda işlem yapmalarını engelleyebilirsiniz.<br /><br /><strong>Not:</strong> Forumu sadece <span style=\"color: green;\"><strong>Admin Grubu</strong></span> görebilir, diğer tüm gruplara kapalı gösterilecektir.";
$l['setting_boardclosed_reason'] = "Forumun Kapalı Olma Nedeni?";
$l['setting_boardclosed_reason_desc'] = "Eğer forumunuzu geçici olarak kullanıma kapatmak istiyorsanız, aşağıdaki metin kutusunu kullanarak, sitenize gelen ziyaretçi ve üyelerinize gösterilmesi için bir mesaj, (kapalı olma sebebi) yazabilirsiniz.";
// Ayar Grubu 2: "Site Details"
$l['setting_group_details'] = "Forum Bilgileri";
$l['setting_group_details_desc'] = "Bu ayar grubu, forum adı, forum url'si, iletişim bilgileri ve çerez ayarları gibi çeşitli ayarları yönetmenize olanak sağlar.";
// 2 Nolu Ayar Grubu Seçenekleri
$l['setting_bbname'] = "Forum Adı - Title";
$l['setting_bbname_desc'] = "Aşağıdaki metin kutusuna forumunuz için bir ad giriniz, 75 karakteri geçmemezi önerilir. Aynı zamanda belirlemiş olduğunuz forum adı title olarak kullanılmaktadır.";
$l['setting_bburl'] = "Forum Adresi";
$l['setting_bburl_desc'] = "Aşağıdaki metin kutusuna, forumunuzun URL adresinizi giriniz. Başında, http:// içermelidir, sonunda slash / işareti olmamasına dikkat ediniz.";
$l['setting_homename'] = "Forum Ana Sayfa Adı";
$l['setting_homename_desc'] = "Aşağıdaki metin kutusuna, forumun ana sayfası için bir ad giriniz, belirtmiş olduğunuz ana sayfa adı, footer kısmında iletim linkinin yanında gösterilecektir.";
$l['setting_homeurl'] = "Forum Ana Sayfa Adresi";
$l['setting_homeurl_desc'] = "Aşağıdaki metin kutusuna, bir üst kısımda belirtmiş olduğunuz ana sayfa adı için bir URL adresi giriniz.";
$l['setting_adminemail'] = "Admin E-Posta Adresi";
$l['setting_adminemail_desc'] = "Aşağıdaki metin kutusuna, forum yöneticisinin ve irtibata geçilmesini istediğiniz bir E-Posta  adresi giriniz.";
$l['setting_returnemail'] = "E-Posta Dönüşü - Geri Bildirim";
$l['setting_returnemail_desc'] = "Aşağıdaki metin kutusuna, E-Postaların geri dönüşü için farklı bir posta adresi yazabilir veya bir üsteki belirmiş olduğunuz ''Admin E-Posta Adresi'' kullanılması için boş bırakabilirsiniz.";
$l['setting_contactemail'] = "İletişim Adresi";
$l['setting_contactemail_desc'] = "Aşağıdaki metin kutusuna, tüm forum sayfalarının en alt kısmında, (footer) gösterilmesi için E-Posta adresi giriniz.<br />Eğer, ./contact.php iletişim formunu kullanmak istemiyorsanız, <strong>Örnek:</strong> (mailto:bilgi@siteadı.com) şeklinde bir E-Posta adresi giriniz veya Yönetici E-Posta adresinin kullanılması için boş bırakabilirsiniz.";
$l['setting_contactlink'] = "İletişim Linki";
$l['setting_contactlink_desc'] = "Aşağıdaki metin kutusuna, tüm forum sayfalarının en alt kısmında, (footer) gösterilmesi için iletişim bağlantı adresi giriniz.<br />./contact.php veya <strong>Örnek:</strong> (mailto:bilgi@siteadı.com) şeklinde bir E-Posta adresi giriniz veya boş bırakınız.";
$l['setting_cookiedomain'] = "Çerez [Cookie] Domain Dizini";
$l['setting_cookiedomain_desc'] = "Aşağıdaki metin kutusundan, çerezlerin depolanması için domain dizin yolunu giriniz, aynı zamanda belirtmiş olduğunuz yol tüm alt domainleride kapsamaktadır.<br /><strong>Örnek 1:</strong> .mybb.com.tr gibi olmalıdır. (ana dizin yoludur.)<br /><strong>Örnek 2:</strong> .forum.mybb.com.tr gibi olmalıdır. (alt dizin yoludur.)<br /><strong>Örnek 3:</strong> .mybb.com.tr/forum gibi olmalıdır. (alt dizin ve forum klasörü yoludur.)<br />Forumunuz alt alanda veya forum klasörü olarak kuruluysa ve sorun yaşıyorsanız eğer üsteki vermiş olduğum 2 ve 3 nolu örneklere bakınız.";
$l['setting_cookiepath'] = "Çerez [Cookie] Yolu";
$l['setting_cookiepath_desc'] = "Bu ayar genellikle slash / işareti ekli olarak kalmalıdır ve mecbur kalmadıkça değiştirilmesi tavsiye edilmez.<br />Değiştirmek isterseniz eğer site adresini tam ve doğru bir şekilde yazmanız gereklidir, aksi halde foruma giriş ve çıkış sorunları oluşabilir.<br /><strong>Not:</strong> Eğer siteniz forum klasörüne kuruluysa <strong>/forum/</strong> şeklinde ayarlamanız giriş/çıkış sorunlarını çözmenize yardımcı olacaktır.";
$l['setting_cookieprefix'] = "Çerez Ön Eki [Prefix]";
$l['setting_cookiesamesiteflag'] = "Aynı Site Çerez Bayrağı";
$l['setting_cookiesamesiteflag_desc'] = "Kimlik doğrulama çerezleri CSRF saldırılarını önlemek için SameSite (Aynı Site) çerez bayrağını kullanacak. Kökeni (cross-origin) olan POST istekleri beliyorsanız bu ayarı devre dışı bırakın.";
$l['setting_cookiesecureflag'] = "Güvenli Çerez Bayrağı";
$l['setting_cookiesecureflag_desc'] ="Siteniz HTTPS kullanıyorsa sitenizde ki çerez bilgilerini şifreli bir şekilde aktarmak için bu ayarı aktif ediniz.Not: Siteniz https yani ssl kullanmıyor ise bu ayarı aktif etmeniz gerekmiyor.";
$l['setting_cookieprefix_desc'] = "Bu ayar, Çerez <strong>[Cookie] Domain Dizini</strong> ve <strong>Çerez [Cookie] Yolu</strong> için <strong>Çerez Ön Eki [Prefix]</strong> eklemenize olanak sağlar ve genelde boş olarak bırakılması tavsiye edilir.";
$l['setting_showvernum'] = "MyBB Versiyonunuz Gösterilsin Mi?";
$l['setting_showvernum_desc'] = "Bu ayar sayesinde, kullanmış olduğunuz MyBB versiyonunuzun <strong>footer</strong> kısmında gösterilip gösterilmeyeceğini belirleyebilirsiniz.<br /><strong>Not:</strong> Bu ayarın <strong>Güvenlik</strong> gereği ''Kapalı'' olarak seçilmesi tavsiye edilir.";
$l['setting_mailingaddress'] = "COPPA için E-posta Adresi";
$l['setting_mailingaddress_desc'] = "Bu ayar, COPPA formunda aşağıdaki metin kutusuna gireceğiniz, E-Posta adresinizin gösterilmesini sağlar.";
$l['setting_faxno'] = "COPPA için Faks Numarası";
$l['setting_faxno_desc'] = "Eğer, bir faks numaranız var ise, aşağıdaki metin kutusuna girebilir ve COPPA formunda gösterilemesini sağlayabilirsiniz.";
// Ayar Grubu 3: "General Configuration"
$l['setting_group_general'] = "Genel Yapılandırma Ayarları";
$l['setting_group_general_desc'] = "Bu ayar grubu, dil ve tema seçimi, Captcha, resim ve video gizleme gibi çeşitli ayarları yönetmenize olanak sağlar.";
// 3 Nolu Ayar Grubu Seçenekleri
$l['setting_bblanguage'] = "Varsayılan Dil Seçimi";
$l['setting_bblanguage_desc'] = "Aşağıdaki açılır dil seçimi menüsünden, forumunuzu ziyaret edenler ve üyeleriniz için varsayılan forum dilini değiştirebilirsiniz.";
$l['setting_captchaimage'] = "Captcha - Günvelik Kodu Kullanılsın Mı?";
$l['setting_captchaimage_desc'] = "Bu ayar, eğer hostunuzda <strong>GD kütüphanesi</strong> yüklü ise, üye kayıtları, konu ve yorum gönderimlerinde <strong>Güvenlik Kodu</strong> (resim doğrulama) girilmesini sağlar.<br />Bunun amacı oluşabilecek spam kayıtları, konu ve yorumları engellemek içindir. <br /><strong>GD kütüphanesi</strong>nin hostunuzda yüklü olup olmadığını, host sağlayıcınızdan öğrenebilirsiniz.";
$l['setting_captchaimage_0'] = "Captcha kullanıma kapat?";
$l['setting_captchaimage_1'] = "MyBB Default CAPTCHA Kullanıma Aç?";
$l['setting_captchaimage_2'] = "Google reCAPTCHA Kullanıma Aç?";
$l['setting_captchaimage_3'] = "Are You a Human Kullanıma Aç?";
$l['setting_captchaimage_4'] = "NoCAPTCHA reCAPTCHA";
$l['setting_captchapublickey'] = "reCAPTCHA Public/Site Key?";
$l['setting_captchapublickey_desc'] = "reCAPTCHA public/Site key numarınızı aşağıdaki metin kutusuna giriniz.<br /> Public key numarınızı öğrenmek yada almak için <strong><a  target=\"_blank\" href=\"http://www.google.com/recaptcha/\">Buraya</a> <img src=\"../images/icons/external_link.png\" alt=\"\" width=\"9\" height=\"9\"></strong> tıklayınız. <strong>Not:</strong> (Bu işlem için google hesabınız ile giriş yapmış olmalısınız.)";
$l['setting_captchaprivatekey'] = "reCAPTCHA Private/Secret Key?";
$l['setting_captchaprivatekey_desc'] = "reCAPTCHA private/secret key numarınızı aşağıdaki metin kutusuna giriniz.<br /> Private key numarınızı öğrenmek yada almak için <strong><a  target=\"_blank\" href=\"http://www.google.com/recaptcha/\">Buraya</a> <img src=\"../images/icons/external_link.png\" alt=\"\" width=\"9\" height=\"9\"></strong> tıklayınız. <strong>Not:</strong> (Bu işlem için google hesabınız ile giriş yapmış olmalısınız.)";

$l['setting_ayahpublisherkey'] = "Are You a Human için Publisher Key";
$l['setting_ayahpublisherkey_desc'] = "Aşağıdaki metin kutusuna yayıncı anahtarı (Publisher Key) giriniz.";

$l['setting_ayahscoringkey'] = "Are You a Human için Scoring Key";
$l['setting_ayahscoringkey_desc'] = "Aşağıdaki metin kutusuna puanlama anahtarı (Scoring Key) giriniz.";

$l['setting_reportmethod'] = "Rapor Edilen Konu ve Yorumlar";
$l['setting_reportmethod_desc'] = "Lütfen aşağıdaki Seçeneklerden, rapor edilen konu ve yorumların nasıl depolanacağını seçiniz.";
$l['setting_reportmethod_db'] = "Veritabanına depolansın?";
$l['setting_reportmethod_pms'] = "Özel Mesaj olarak gönderilsin?";
$l['setting_reportmethod_email'] = "E-Posta olarak gönderilsin?";
$l['setting_statslimit'] = "Forum İstatistikleri Limit Ayarları";
$l['setting_statslimit_desc'] = "Bu ayar sayesinde, forum istatistikleri (stats.php) sayfasında, <strong>En çok yorumlanan</strong> ve <strong>En çok okunan</strong> konuların kaç tane gösterilmesini istiyorsanız ayarlayabilirsiniz.";
$l['setting_statstopreferrer'] = "İstatistik Sayfasında En Çok Referansı Olan Gösterilsin Mi?";
$l['setting_statstopreferrer_desc'] = "Bu ayar, forum istatistikleri sayfasında ''En çok referansı olan kullanıcı''nın gösterilip gösterilmeyeceğini belirlemenizi sağlar.<br />(<strong>Not:</strong> Bu özellik aktif edilirse, sunucuya ek bir sorgu yükleyecektir.)";
$l['setting_decpoint'] = "Ondalık Sayı Birimi";
$l['setting_decpoint_desc'] = "Bölgenizde kullanılan ondalık puan/sayı birimini aşağıdaki metin kutusuna yazınız.";
$l['setting_thousandssep'] = "1000-lik Numara Ayıracı";
$l['setting_thousandssep_desc'] = "Kullanmak istediğiniz numara ayıracını giriniz. <strong>(Örnek:</strong> 1500 rakamı için eğer aşağıdaki metin kutusuna virgün ',' eklenirse şu şekilde ayrılmış olacaktır; 1,500)";
$l['setting_showlanguageselect'] = "Dil Seçimi Gösterilsin Mi?";
$l['setting_showlanguageselect_desc'] = "Bu ayar, eğer forumunuzda çoklu dil kullanıyorsanız <strong>Footer</strong> kısmında bulunan ve forumun tüm sayfalarında görünecek olan forum dili seçimi aracının gösterilip gösterilmeyeceğini ayarlamanızı sağlar.";
$l['setting_showthemeselect'] = "Tema Seçimi Gösterilsin Mi?";
$l['setting_showthemeselect_desc'] = "Bu ayar, eğer forumunuzda birden fazla tema yüklü ise <strong>Footer</strong> kısmında bulunan ve forumun tüm sayfalarında görünecek olan forum teması seçimi aracının gösterilip gösterilmeyeceğini ayarlamanızı sağlar.";
$l['setting_maxmultipagelinks'] = "Maksimum Sayfa Numaralandırma Linkleri Limiti";
$l['setting_maxmultipagelinks_desc'] = "Bu ayar, forum ve konu gösterimindeki sayfa numaraları için ''önceki sayfa'' ve ''sonraki sayfa'' butonları arasında kaç x tane sayfa numarası/linki gösterileceğini ayarlamanıza olanak sağlar.";
$l['setting_jumptopagemultipage'] = "Sayfalar Arası Hızlı Geçiş Kutusunu Göster?";
$l['setting_jumptopagemultipage_desc'] = "Bu ayar, ''Maksimum Sayfa Numaralandırma Linkleri'' kısmında eğer limit girilmiş ise, sayfa numaraları sonunda hızlı geçiş kutusunun gösterilmesini sağlar.";
$l['setting_no_plugins'] = "Tüm Eklentileri Kapat?";
$l['setting_no_plugins_desc'] = "Bu ayar, eğer <strong>Evet</strong> olarak seçilirse forumdaki yüklü tüm eklentileri tek seferde devre dışı bırakmanızı sağlar. Bu işlem güncellemeler sırasında oldukça kullanışlıdır.<br />Ayrıca bu özellik eklentileri sadece devre dışı bırakır ve yapmış olduğunuz ayarları vs. silmez. Tekrar aktif edilince, aktif olarak çalışan tüm eklentileriniz yapılan ayarları ile birlikte kaldığı yerden devam edecektir.";
$l['setting_soft_delete'] = "Geçici Sil/Gizle Aktif Edilsin Mi?";
$l['setting_soft_delete_desc'] = "Bu ayar, eğer <strong>Evet</strong> olarak seçilirse kullanıcılar tarafından forumdaki konu ve yorumlar silinse bile onarılıp geri getirilmesini sağlar.<br />Bir nevi silen kişiye silinmiş gibi gözüksede aslında silinmemiştir ve sadece yönetici onayı ile silinebilir ve geri getirilebilir.<br /> Eğer, <strong>Hayır</strong> olarak seçilirse silinen konu ve yorumlar sistemden tamamen silinecektir ve geri getirme işlemi mümkün olmayacaktır..";
$l['setting_announcementshtml'] = "Duyurular'da HTML Kullanımına İzin Ver";
$l['setting_announcementshtml_desc'] = "Yöneticilerin forum duyuruları kısmında HTML kodlarının kullanmasına izin verilsin mi?";
$l['setting_helpsearch'] = "Yardım Belgelerinde Arama Kutusunu Göster?";
$l['setting_helpsearch_desc'] = "Bu ayar, yardım belgeleri sayfasının altında belge içi aramaları yapmak için arama kutusu aracını eklemenizi sağlar.";
$l['setting_deleteinvites'] = "Grup Üyeliği Davetleri için Geçerlilik Süresi";
$l['setting_deleteinvites_desc'] = "Bu ayar, Kullanıcı grupları üyeliği davetlerinde onay bekleyen herhangi bir davet varsa maksimum bekleme süresini/gününü belirlemenizi sağlar.<br />Belirlenen süre/gün bitiminde mevcut davetler geçerliliğini yitirip iptal edilecektir.<br />Varsayılan ayar: 180 gün, devre dışı bırakmak için: 0 değeri giriniz.";
$l['setting_hidewebsite'] = "Web Site Adresleri & WWW Butonlarını Gizlemek İstediğiniz Kullanıcı Grupları?";
$l['setting_hidewebsite_desc'] = "Bu ayar, kullanıcı profillerindeki ''web site adresleri'' ve konu/yorum gösterimindeki ''WWW'' butonlarını beliryeceğiniz kullanıcı gruplarına gizlemenizi (gösterime tamamen kapatmanızı) sağlar.";
$l['setting_hidesignatures'] = "Kullanıcı İmzalarını Gizle";
$l['setting_hidesignatures_desc'] = "Bu ayar, kullanıcı profillerindeki ve konu/yorum gösterimindeki ''imzaları'' beliryeceğiniz kullanıcı gruplarına gizlemenizi (gösterime tamamen kapatmanızı) sağlar.";
// Ayar Grubu 4: "Server and Optimization Options"
$l['setting_group_server'] = "Sunucu ve Optimizasyon Ayarları";
$l['setting_group_server_desc'] = "Bu ayar grubu, forumunuzun performansını arttırmanıza yardımcı olacak, çeşitli ayarları yönetmenize olanak sağlar.";
// 4 Nolu Ayar Grubu Seçenekleri
$l['setting_seourls'] = "Arama Motoru Dostu SEF URL-ler Aktif Edilsin Mi?";
$l['setting_seourls_desc'] = "Arama motoru dostu SEf URL değişimi, MyBB forumunuzun linklerini arama motorlarının tercih ettiği kısa halleriyle değişmesine olanak sağlar. <br /><strong>Örnek:</strong> showthread.php?tid=1 => thread-1.html şeklinde değişmiş olur. <strong>Not:</strong> Bu özellik <strong>Windows</strong> tabanlı sunucularda çalışmayabilir.";
$l['setting_seourls_auto'] = "Otomatik Bulucuyu Kullan?";
$l['setting_seourls_yes'] = "SEF URL-leri Aktifleştir?";
$l['setting_seourls_no'] = "SEF URL-leri Pasifleştir?";
$l['setting_seourls_archive'] = "Arşiv Sayfaları için Sef URL-ler Aktif Edilsin Mi?";
$l['setting_seourls_archive_desc'] = "Arşiv sayfaları için arama motoru dostu sef URL'lerin aktif edilmesini istiyor musunuz?";
$l['setting_gzipoutput'] = "Gzip Sayfa Sıkıştırması Kullanılsın Mı?";
$l['setting_gzipoutput_desc'] = "Bu ayar, tarayıcıların sitenizin sayfalarını GZip formatına sıkıştırarak, kullanıcı ve ziyaretçilerin sitenizi daha hızlı dolaşmalarına ve trafik kullanımınızı düşürmenize olanak sağlar.<br />Bu ayar bazı firmaların sunucu yapılandırmalarındaki eksiliklerinden dolayı doğru olarak çalışmayabilir ve sayfa bulunamadı, sıkıştırma ve/veya biçimlendirme hatası gibi çeşitli hatalara yol açabilir.";
$l['setting_gziplevel'] = "Gzip Sayfa Sıkıştırması için Seviye Ayarları";
$l['setting_gziplevel_desc'] = "<strong>Örnek Kullanım Değerleri:</strong><br />0=> Sıkıştırma yapmaz.<br />4=> Varsayılan sıkıştırma.<br />6=> Orta sevileyeli sıkıştırma.<br />9=> Maksimum sıkıştırma yapar.<br />Maksimum sıkıştırma için PHP versiyonunuzun minimum 5.2 olması gerekli. PHP versiyonunuzu admin paneli ana sayfasındaki istatistik tablosundan görebilirsiniz.<br /><strong>Not:</strong> Başlanğıç seviyesi olarak (4) değeri çoğu yüklemeler için tavsiye edilir.";
$l['setting_nocacheheaders'] = "Önbelleksiz Başlıklar Gönderilsin Mi?";
$l['setting_nocacheheaders_desc'] = "Bu ayar, tarayıcılar tarafından forum sayfalarının önbeleğe depolanmasını/alınmasını önlemenizi sağlar.";
$l['setting_redirects'] = "Sayfa Yönlendirmeleri Kapatılsın Mı?";
$l['setting_redirects_desc'] = "Bu ayar, kullanıcıların sitenizde yapmış oldukları işlemler sırasında, karşılarına çıkacak olan yönledirme bilgilerini kapatıp, açmanıza olanak sağlar.<br />Sayfalar arası geçiş ve yapılan işlerde çıkan yönlendirme mesajları olarak nitelendirebiliriz.";
$l['setting_load'] = "*NIX Sunucu Yükleme Limiti";
$l['setting_load_desc'] = "Bu ayar, sunucunuzun belirli bir seviyede çalışmasını ve aşırı kasılma ve yüklenmeleri önlemenizi sağlar, aynı zamanda limit aşımlarında kullanıcıları engeller ve bilinmeyen bir hata oluştu uyarısı verir.<br />Diğer bir anlamda, ''Process Load'' sırada bekleyen işlemlerin sayısını belirler.<br /><strong>Örnek Kullanım Şekilleri:</strong><br />Varsılan Limit: 0<br />Tavsiye edilen en yüsek değer: 5.0";
$l['setting_tplhtmlcomments'] = "Şablonların Başlangıç & Bitiş Açıklamaları Gösterilsin Mi?";
$l['setting_tplhtmlcomments_desc'] = "Bu ayar sayesinde, kullandığınız temanın, Sayfa Kaynağında gösterilen ve şablonlar için kullanılan kalıp, (HTML kod) başlangıç ve bitiş noktalarının gösterilmesini engelleyebilir ve özellikle, özel tema tasarımlarınızın kaynak kodlarından, Ç-alınmasına karşılık ufak bir önlem olarak gösterime kapatabilirsiniz.";
$l['setting_use_xmlhttprequest'] = "XMLHttp Dinamik Ajax Özelliği Aktifleştirilsin Mi?";
$l['setting_use_xmlhttprequest_desc'] = "Bu ayar, XMLHttp Dinamik Ajax Özelliğini kullanmanıza olanak sağlar. XMLHttp, özellikle ''Hızlı Cevap'' editörünün ajaxlı olması için kullanılmaktadır. isteğe bağlı olarak kullanıma kapatabilir veya sayfa yükünü hızlandırmak için aktif edebilirsiniz.";
$l['setting_extraadmininfo'] = "Gelişmiş İstatistik \ Debug Bilgisi Gösterilsin Mi?";
$l['setting_extraadmininfo_desc'] = "Sunucu yüklemesi, gzip sıkıştırması, SQL sorguları, PHP versiyonu ve bellek kullanımı vb. gibi istatistiklerin her sayfanın footer kısmında gösterilmesine olanak sağlar. Bu bilgileri sadece adminler görebilir.";
$l['setting_uploadspath'] = "Dosya Upload/Yükleme Dizini";
$l['setting_uploadspath_desc'] = "Forumunuza yükleme yaptığınız ./uploads klasörünün yoludur ve dilerseniz bu dizini aşağıdaki metin kutusundan değiştirebilirsiniz.<br />Dosya yükleme işlemlerinin gerçekleşmesi için ./uploads klasörünün CHMOD izinleri (777) olmalıdır.";
$l['setting_useerrorhandling'] = "Hata Yüklenmesini Aç / Kapat";
$l['setting_useerrorhandling_desc'] = "MyBB için entegre edilmiş, hata yükleyicisisini kullanmak istemiyorsanız bu seçeneği kapatabilirsiniz. Ancak bu seçeneğin <strong>''Açık''</strong> olarak seçili olması tavsiye edilir.";
$l['setting_errorlogmedium'] = "Hata Kayıtlarını Tutma Tipi";
$l['setting_errorlogmedium_desc'] = "Bu ayar, seçeceğiniz işlem tipine bağlı hata kayıtlarını tutarak manuel mudahele etmenize olanak sağlar. Aşağıdaki seçeneklerden hata kayıtlarının tutulacağı bir işlem tipi seçiniz.";
$l['setting_errorlogmedium_none'] = "Hiçbiri";
$l['setting_errorlogmedium_log'] = "Kayıt Hataları";
$l['setting_errorlogmedium_email'] = "E-Posta Hataları";
$l['setting_errorlogmedium_both'] = "Kayıt ve E-Posta Hataları";
$l['setting_errortypemedium'] = "Hata Mesajı Ekranı Gösterim Tipi";
$l['setting_errortypemedium_desc'] = "Bu ayar, hata kayıtları için gösterilmesini istediğiniz işlem tipini seçmenize olanak sağlar. Aynı zamanda mybb hata ekranı mesajındaki hata mesajlarını site üzerinde gizlemenize ve/veya göstermenize de olanak sağlar. Gösterilecek hata kayıtları tipini aşağıdaki açılır seçenek sekmesinden seçiniz. Bu ayarın, ''Uyarı ve Hataları Gizle'' seçeneği olarak seçilmesi tavsiye edilir. Bu sayede hata mesajı ekranında veritabanı adı vb. bilgileri güvenlik gereği gizlemiş olursunuz ve ilgili hata mesajlarının kaydını sadece <strong>./error.log</strong> dosyasında tutarak görüntüleyebilir ve aynı zamanda <strong>Forum Bilgileri</strong> kısmında yer alan, (Admin E-Posta Adresi) kısmına girmiş olduğunuz e-posta adresine hata çıktılarının bilgi maili olarak gönderilmesi sağlanmış olur.";
$l['setting_errortypemedium_warning'] = "Uyarıları Göster";
$l['setting_errortypemedium_error'] = "Hataları Göster";
$l['setting_errortypemedium_both'] = "Uyarı ve Hataları Göster";
$l['setting_errortypemedium_none'] = "Uyarı ve Hataları Gizle";
$l['setting_errorloglocation'] = "Hata Kayıtlarının Yolu";
$l['setting_errorloglocation_desc'] = "Forumda oluşan hata kayıtlarının tutulduğu dosya yoludur ve dilerseniz bu dosyanın adını aşağıdaki metin kutusundan değiştirebilirsiniz.";
$l['setting_enableforumjump'] = "Forum Atlama - Hızlı Menü Gösterilsin Mi?";
$l['setting_enableforumjump_desc'] = "Forum atlama, ''Hızlı Menü'' aracı, forum ve konu gösterimlerinde kulanılır. Bu aracı kullanmak istemiyorsanız eğer aşağıdaki seçeneklerden ''Hayır'' seçeneğini seçiniz.";
$l['setting_ip_forwarded_check'] = "Kullanıcı IP Adreslerini Kontrol Et?";
$l['setting_ip_forwarded_check_desc'] = "<strong>HTTP_X_FORWARDED_FOR</strong> veya <strong>HTTP_X_REAL_IP</strong> başlıkları için kullanıcıların IP adreslerini kontrol etmek istiyor musunuz?<br />Eğer bu ayarın ne olduğundan tam olarak emin değilseniz, seçeneği <strong>''Hayır''</strong> olarak seçili bırakın.";
$l['setting_minifycss'] = "Minify CSS Modeli Aktif Edilsin Mi?";
$l['setting_minifycss_desc'] = "Bu ayar, forumdaki mevcut tüm css stillerini sıkıştırıp bant genişliğini minimum düzeye düşürerek kaydetmenize ve sayfa açılış hızlarını arttımanıza yardımcı olur.<br />Performans arayanlar için bu ayarın <strong>''Evet''</strong> olarak seçilmesi tavsiye edilir.";
$l['setting_usecdn'] = "CDN Servisi Aktif Edilsin Mi?";
$l['setting_usecdn_desc'] = "Bu ayar, forumun CSS stilleri, JavaScript ve Grafik dosyalarını statik olarak yükletmek için bir CDN (Content Delivery Network) servisi kullanmanıza olanak sağlar.<br />Eğer, statik bir CDN servisi kullanmak istiyorsanız bu ayarı aktif edebilirsiniz.";
$l['setting_cdnurl'] = "CDN Servisi için Statik URL Adresi";
$l['setting_cdnurl_desc'] = "Eğer, yukarıdaki ''CDN Servisi'' aktif edilmiş ise aşağıdaki metin kutusuna statik içeriğin (CSS stilleri, JavaScript ve Grafik dosyalarının) çekileceği URL adresini giriniz.<br />Statik URL adresinin sonunda  (slash) / işareti kullanmayın.";
$l['setting_cdnpath'] = "CDN Servisi için Statik Dosyaların Saklanacağı Dizin";
$l['setting_cdnpath_desc'] = "Eğer, yukarıdaki ''CDN Servisi için Statik URL Adresi'' kısmına statik bir URL adresi eklenmiş ise, isteğe bağlı olarak statik dosyaların (CSS stilleri, JavaScript ve Grafik dosyalarının) depolanacağı tam yolu giriniz.<br />Bu ''Sıkıştırma'' tipi CDN veya yerel alt alan adı (sub-domain) kurulumları için oldukça yararlı bir yöntemdir. Dizin yolu için (slash) / işareti kullanılmamalıdır.";
// Ayar Grubu 5: "Date and Time Formats"
$l['setting_group_datetime'] = "Tarih ve Saat Ayarları";
$l['setting_group_datetime_desc'] = "Bu ayar grubu, forumunuzun Tarih ve Saat formatlarını ayarlamanıza olanak sağlar.";
// 5 Nolu Ayar Grubu Seçenekleri
$l['setting_dateformat'] = "Tarih Formatı";
$l['setting_dateformat_desc'] = "Bu kısımdan, forumunuzun Tarih formatını ayarlayabilirsiniz.";
$l['setting_timeformat'] = "Saat Formatı";
$l['setting_timeformat_desc'] = "Bu kısımdan, forumunuzun Saat formatını ayarlayabilirsiniz.";
$l['setting_datetimesep'] = "Tarih & Saat Ayracı";
$l['setting_datetimesep_desc'] = "Bu ayar, MyBB'nin Tarih & Saat formatları için kullanılacak olan ayracını belirlemenizi sağlar.<br /><strong>Örnek:</strong> , Saat: gibi veya sadece virgül kullanabilir ya da boş olarak bırakabilirsiniz.";
$l['setting_regdateformat'] = "Kayıt Olunan Tarih Formatı";
$l['setting_regdateformat_desc'] = "Bu kısımda, kullanıcıların üyelik tarihi formatını ayarlayabilirsiniz. Bu format, postbit, üye profili ve üye listesi için kullanılmaktadır.";
$l['setting_timezoneoffset'] = "Varsayılan Zaman Dilimi";
$l['setting_timezoneoffset_desc'] = "Bu kısımdan, bulunduğunuz kesime/bölgeye ait zaman dilimini seçiniz.";
$l['setting_dstcorrection'] = "Yaz / Kış Sezonu Saati (DST) Zaman Ayarları";
$l['setting_dstcorrection_desc'] = "Bu kısımda, ''varsayılan zaman dilimi'' doğru seçilmiş ise, otomatik olarak yaz / kış sezonu (<acronym title=\"Daylight Saving Time\">DST</acronym>) zaman ayarlarının algılanmasını sağlayabilirsiniz.";
// Ayar Grubu 6: "Forum Home Options"
$l['setting_group_forumhome'] = "Anasayfa Ayarları - [index]";
$l['setting_group_forumhome_desc'] = "Bu ayar grubu, forumunuzun ana sayfası, [index.php] için çeşitli ayarları yönetmenize olanak sağlar.";
// 6 Nolu Ayar Grubu Seçenekleri
$l['setting_showdescriptions'] = "Forum Açıklamaları Gösterilsin Mi?";
$l['setting_showdescriptions_desc'] = "Bu ksımdan, oluşturmuş olduğunuz forumlar için eğer varsa eklediğiniz forum açıklamalarının gösterilmesi yada gizli olmasını sağlarsınız.";
$l['setting_subforumsindex'] = "Ana Sayfada Kaç Tane Alt Forum Gösterilsin?";
$l['setting_subforumsindex_desc'] = "Bu kısımdan, forum ana sayfası ve forum görüntülemede kaç tane alt forum gösterilmesini istiyorsanız ayarlayabilirsiniz.";
$l['setting_subforumsstatusicons'] = "Alt Forumlar için Durum İkonları Gösterilsin Mi?";
$l['setting_subforumsstatusicons_desc'] = "Bu kısımdan, alt forumlar için ''yeni yorum var'' , '' yeni yorum yok'' gibi, mini durum ikonlarını gösterime kapatabilir ya da açabilirsiniz.";
$l['setting_hideprivateforums'] = "Özel Forumlar Gösterime Kapatılsın Mı?";
$l['setting_hideprivateforums_desc'] = "Bu kısımdan, forumunuz için oluşturmuş olduğunuz özel forumların, belirlediğiniz gruplar dışında olan, kullanıcı gruplarına gizli/görünmez olmasını sağlayabilirsiniz.";
$l['setting_modlist'] = "Forum Yöneticileri Gösterilsin Mi?";
$l['setting_modlist_desc'] = "Bu kısımdan, forum ana sayfasında ve forum görüntülemede, bölüm yöneticilerinin gösterilmesini sağlayabilirsiniz.";
$l['setting_showbirthdays'] = "Bugün Doğum Günü Olanlar Gösterilsin Mi?";
$l['setting_showbirthdays_desc'] = "Bu kısımdan, forum ana sayfasındaki, forum istatistikleri kısmında ''Bugün Doğum Günü Olanların'' gösterilmesini sağlayabilirsiniz.";
$l['setting_showbirthdayspostlimit'] = "Kaç X Mesajı Olanlar Doğum Günü Listesinde Gösterilsin?";
$l['setting_showbirthdayspostlimit_desc'] = "Aşağıdaki metin kutusuna, Maksimum kaç x mesajı olan kullanıcıların doğum günleri gösterilsin giriniz? Eğer, sıfır (0) olarak bırakılırsa limit olmaz ve tüm doğum günleri olanlar gösterilir.";
$l['setting_showwol'] = "Kimler Çevrimiçi Gösterilsin Mi?";
$l['setting_showwol_desc'] = "Bu kısımdan, forum ana sayfasındaki forum istatistikleri kısmında, çevrimiçi olan kullanıcıların gösterilmesini veya gösterime kapatılmasını sağlayabilirsiniz.";
$l['setting_showindexstats'] = "Forum İstatistikleri Gösterilsin Mi?";
$l['setting_showindexstats_desc'] = "Bu kısımdan, forum ana sayfasında toplam konu, yorum ve üye sayılarının gösterime kapatılması veya açılmasını sağlayabilirsiniz.";
$l['setting_showforumviewing'] = "X Forumu Görüntülüyor Gösterilsin Mi?";
$l['setting_showforumviewing_desc'] = "Bu kısımdan, forum ana sayfasında, x forumu görüntüleyen kullanıcı sayısının, gösterime kapatılmasını veya açılmasını sağlayabilirsiniz.";
// Ayar Grubu 7: "Forum Display Options"
$l['setting_group_forumdisplay'] = "Forum Görüntüleme Ayarları - [forumdisplay]";
$l['setting_group_forumdisplay_desc'] = "Bu ayar grubu, forum görüntüleme, [forumdisplay.php] için çeşitli ayarları yönetmenize olanak sağlar.";
// 7 Nolu Ayar Grubu Seçenekleri
$l['setting_threadsperpage'] = "Sayfa Başına Gösterilecek Konu Sayısı?";
$l['setting_threadsperpage_desc'] = "Bu kısımda, forum görüntülemede sayfa başına, listelenmesini istediğiniz konu sayısını ayarlayabilirsiniz.";
$l['setting_hottopic'] = "Sıcak Konu Olması için Yorum Sayısı?";
$l['setting_hottopic_desc'] = "Bu kısımda, bir konunun sıcak konu olabilmesi için kaç tane yorum yazılması gerektiğini ayarlayabilirsiniz.";
$l['setting_hottopicviews'] = "Sıcak Konu Olması için Okunma Sayısı?";
$l['setting_hottopicviews_desc'] = "Bu kısımda, bir konunun sıcak konu olabilmesi için kaç defa okunması, (görüntülenmesi) gerektiğini ayarlayabilirsiniz.";
$l['setting_usertppoptions'] = "Sayfa Başına Kullanıcıların Seçebileceği Konu Sayısı?";
$l['setting_usertppoptions_desc'] = "Bu kısımda, kullanıcıların sayfa başına kaç tane konu görüntülemesini istiyorsanız, aşağıdaki metin kutusuna, sayfa başına gösterilecek konu sayılarını virgül ile ayıyarak giriniz.<br /><strong>Örnek:</strong> 10,20,30,40 yada 5,10,15,20 gibi.";
$l['setting_dotfolders'] = "Nokta İkonları kullanılsın Mı?";
$l['setting_dotfolders_desc'] = "Bu kısımda, konu gösterinde kullanıcı sayısını belirtmek için kullanılan ''nokta'' iconlarının kulanılmasını veya kullanıma kapatılmasını ayarlayabilirsiniz.";
$l['setting_allowthreadratings'] = "Konu Oylama Kullanılsın Mı?";
$l['setting_allowthreadratings_desc'] = "Tüm kullanıcı grupları, konuları oylayabilsin mi ? Kullanıma kapatmak için <strong>HAYIR</strong> seçiniz. Bu aynı zamanda forum ve konu görüntülemedeki, (<strong>5 yıldız</strong>) oylamanında kullanıma/gösterime kapatılmasını sağlar.";
$l['setting_browsingthisforum'] = "Forumu Görüntüleyen Kullanıcılar Gösterilsin Mi?";
$l['setting_browsingthisforum_desc'] = "Bu kısımdan, forum görüntülemedeki <strong>Forumu Görüntüleyenler</strong> fonksiyonunu gösterime kapatabilir ya da açabilirsiniz.";
$l['setting_announcementlimit'] = "Kaç Tane Duyuru Gösterilsin?";
$l['setting_announcementlimit_desc'] = "Bu kısımda, Forum görüntülemede kaç tane duyuru gösterilmesini istiyorsanız, aşağıdaki metin kutusuna giriniz.";
$l['setting_readparentforums'] = "Alt Forumları Okundu Olarak Zorlama";
$l['setting_readparentforums_desc'] = "Evet olarak ayarlandığı zaman bu ayar, alt forumlardaki mesajların okundu olarak işaretlendiğinde, işaretlenmeyen mesajların onaylanmasını sağlayacaktır. Ayrıca bu ayar, performans ve çoklu veritabanı sorgularının azalmasını ya da sunucu durumunuza göre artmasını sağlayabilir, bu nedenle deneysel olarak sık sık kontrol etmeniz tavsiye edilir.";
// Ayar Grubu 8: "Show Thread Options"
$l['setting_group_showthread'] = "Konu Gösterim Ayarları - [showthread]";
$l['setting_group_showthread_desc'] = "Bu ayar grubu, Konu gösterimi [showthread.php] için çeşitli ayarları yönetmenize olanak sağlar.";
// 8 Nolu Ayar Grubu Seçenekleri
$l['setting_postlayout'] = "Konu Gösterim Stili";
$l['setting_postlayout_desc'] = "Bı kısımda, konu gösterim stilini yatay veya klasik, (dikey) olarak değiştirebilirsiniz. Yatay postbit seçildiğinde, yazar bilgileri konunun üstünde gösterilir, klasik, (dikey) postbit seçildiğinde ise yazar bilgileri sağ'da konu sol'da gösterilir. fakat dikey postbit seçimi sadece ziyaretçiler için geçerli olacaktır. Tüm kullanıcıların klasik, (dikey) postbit stilini kullanabilmeleri için bazı değişiklikler yapmanız gerebilir.";
$l['setting_postlayout_horizontal'] = "Yatay Postbit Stilini Kullan?";
$l['setting_postlayout_classic'] = "Klasik/Dikey Postbit Stilini Kullan?";
$l['setting_postsperpage'] = "Sayfa Başına Gösterilecek Yorum Sayısı?";
$l['setting_postsperpage_desc'] = "Bu kısımda, konu gösteriminde sayfa başına, gösterimesini istediğiniz yorum sayısını ayarlayabilirsiniz. Sayfa başına gösterilecek yorum sayısı; 10 ile 15 arası olması tavsiye edilir.";
$l['setting_userpppoptions'] = "Sayfa Başına Kullanıcıların Seçebileceği Yorum Sayısı?";
$l['setting_userpppoptions_desc'] = "Bu kısımda, kullanıcıların sayfa başına kaç tane yorum görüntülemesini istiyorsanız, aşağıdaki metin kutusuna, sayfa başına gösterilecek yorum sayısını virgül ile ayıyarak giriniz.<br /><strong>Örnek:</strong> 10,20,30,40 ya da 5,10,15,20 gibi.";
$l['setting_postmaxavatarsize'] = "Konu & Yorumlar İçin Maksimum Avatar Buyutu?";
$l['setting_postmaxavatarsize_desc'] = "Konu & yorumlarda gösterilmesini istediğiniz maksimum avatar Buyutunu giriniz. Eğer kullanılan avatar izin verilenden büyük ise otomatik olarak boyutlandırılır.";
$l['setting_threadreadcut'] = "Konu Bilgileri Veritabanında Kaç Gün Tutulsun?";
$l['setting_threadreadcut_desc'] = "Bu kısımdan, Konu bilgilerini okumak için veritabanında kaç gün tutmak/saklamak istiyorsanız belirtiniz.<br />Büyük forumlar için gün sayısının yüksek olması forumları yavaşlatacağından dolayı tavsiye edilmez. Bu özelliği devre dışı bırakmak için sıfır (0) değeri giriniz.";
$l['setting_threadusenetstyle'] = "Usenet Konulara Bakma Stili Aktifleştirilsin Mi?";
$l['setting_threadusenetstyle_desc'] = "Bu kısımda, konularda yazılan yorumların <strong>usenet</strong> yani yorumları liste halinde göstermek istiyorsanız, aşağıdaki seçeneklerden Evet'i seçiniz.";
$l['setting_quickreply'] = "Hızlı Cevap Editörü/Kutusu Gösterilsin Mi?";
$l['setting_quickreply_desc'] = "Bu kısımdan, konu gösterimindeki en alt kısımda yer alan <strong>hızlı cevap editörünü</strong> kullanıma kapatabilir ya da açabilirsiniz.";
$l['setting_multiquote'] = "Çoklu Alıntı Butonları Gösterilsin Mi?";
$l['setting_multiquote_desc'] = "Bu kısımda, çoklu alıntı (+/-) tuşlarını kullanıma kapatabilirsiniz. genellikle birden fazla yorumları alıntı yaparak cevap yazmada kullanışlıdır.";
$l['setting_showsimilarthreads'] = "Benzer Konular Listesi Gösterilsin Mi?";
$l['setting_showsimilarthreads_desc'] = "Bu ayar, konu gösteriminde görüntülenen konu ile alakalı benzer konuların listesini gösterime açmanızı sağlar.";
$l['setting_similarityrating'] = "Benzer Konular Kaç X Görüntülenme/Okunma Sayısına Göre Gösterilsin?";
$l['setting_similarityrating_desc'] = "Bu kısımda, benzer konuların okunma yani izlenme sayılarına ilşkin gösterilmesini sağlayabilirsiniz. Bu ayarın 1 ila 7 arası olması tavsiye edilir.";
$l['setting_similarlimit'] = "Benzer Konular Limiti";
$l['setting_similarlimit_desc'] = "Bu kısımda, benzer konuların listesi için gösterilmesini istediğiniz konu sayısını giriniz. Bu sayının 5 ila 10 arası olması tavsiye edilir.";
$l['setting_showforumpagesbreadcrumb'] = "Multipage Dropdown Aracı Gösterilsin Mi?";
$l['setting_showforumpagesbreadcrumb_desc'] = "Forum konularında 1-den fazla sayfa varsa, navbarda küçük mavi ok simgesinin/açılan pagination menüsünün görüntülenmesini istiyor musunuz?";
$l['setting_browsingthisthread'] = "Konuyu Okuyan Kullanıcılar Gösterilsin Mi?";
$l['setting_browsingthisthread_desc'] = "Bu kısımdan, <strong>Şu anda bu konuyu okuyanlar</strong> fonksiyonunu gösterime kapatabilir ya da açabilirsiniz.";
$l['setting_delayedthreadviews'] = "Konu Gösterim/Okunma Sayaçları Güncellensin Mi?";
$l['setting_delayedthreadviews_desc'] = "Bu kısımda, konu gösterim/okunma sayaçlarının anlık olarak yansıltımasını devre dışı bırakabilirsiniz.<br />Eğer, aşağıdaki seçeneklerden ''Açık'' seçilirse, sayaçların sayma işlemi arkaplanda devam edecektir ve bir konunun kaç defa görüntülendiğine/okunduğuna dair sayma işlemi arkaplanda devam edeceği için sayaçlara anlık olarak yansıtılmaz.";
// Ayar Grubu 9: "Login and Registration Options"
$l['setting_group_member'] = "Kullanıcı Giriş ve Kayıt Ayarları";
$l['setting_group_member_desc'] = "Bu ayar grubu, kullanıcıların giriş ve kayıt işlemlerinin izinlerini ve çeşitli ayarları yönetmenize olanak sağlar.";
// 9 Nolu Ayar Grubu Seçenekleri
$l['setting_disableregs'] = "Üyelik Kayıtları Durdurulsun mu?";
$l['setting_disableregs_desc'] = "Bu kısımdan, forumunuza gelen ziyaretçilerin üye/kayıt olmalarını engeleyebilirsiniz.";
$l['setting_regtype'] = "Üye Kayıtları için Onay Metodu Seçiniz";
$l['setting_regtype_desc'] = "Bu kısımdan, kayıt olan üyelerin üyelik hesapları için onay türünü aşağıdaki açılır seçenek sekmesinden ayarlayabilirsiniz.";
$l['setting_regtype_instant'] = "Anında Aktif";
$l['setting_regtype_verify'] = "E-Posta Aktivasyonu Gönder";
$l['setting_regtype_randompass'] = "Rastgele Bir Şifre Gönder";
$l['setting_regtype_admin'] = "Yönetici Onaylı";
$l['setting_regtype_both'] = "E-Posta Aktivasyonu & Yönetici Onaylı";

$l['setting_awactialert'] = "Aktivasyon Onayı Bekleyenler Bildirimi";
$l['setting_awactialert_desc'] = "Bu ayar, forum yöneticilerine aktivasyon onayı bekleyen varsa, kırmızı renkli bir bildirim çubugu gösterilmesini sağlar.";

$l['setting_forcelogin'] = "Ziyaretçileri Giriş/Kayıt Yapmaları için Zorla?";
$l['setting_forcelogin_desc'] = "Bu ayar, foruma gelen ziyaretçileri forum içeriğini görebilmeleri için giriş ve/veya kayıt yapmalarını zorunlu hale getirmenizi sağlar.<br />Bir nevi gelen ziyaretçilere forumu tamamen kapatıp yararlanabilmeleri için giriş ve/veya kayıt olmaya zorlar.";
$l['setting_minnamelength'] = "İzin Verilen Minimum Kullanıcı Adı Uzunluğu?";
$l['setting_minnamelength_desc'] = "Bu kısımdan, izin verilen minimum kullanıcı adı uzunluğunun kaç karakter olmasını istiyorsanız ayarlayabilirsiniz.";
$l['setting_maxnamelength'] = "İzin Verilen Maksimum Kullanıcı Adı Uzunluğu?";
$l['setting_maxnamelength_desc'] = "Bu kısımdan, izin verilen maksimum kullanıcı adı uzunluğunun kaç karakter olmasını istiyorsanız ayarlayabilirsiniz.";
$l['setting_minpasswordlength'] = "İzin Verilen Minimum Şifre Uzunluğu?";
$l['setting_minpasswordlength_desc'] = "Bu kısımdan, izin verilen minimum şifre uzunluğunu belirleyebilirsiniz.";
$l['setting_requirecomplexpasswords'] = "Karmaşık Şifre Kullanımı Aktif Edilsin Mi?";
$l['setting_requirecomplexpasswords_desc'] = "Bu kısımdan, kullanıcı kayıtları için kullanıcak olan karmaşık şifre özelliğini aktif edebilirsiniz.<br /><strong>Karmaşık şifre:</strong> en az 6 karakter uzunluğunda, rakam ve büyük/küçük harflerden oluşan karışık, güvenli şifredir.";
$l['setting_maxpasswordlength'] = "İzin Verilen Maksimum Şifre Uzunluğu?";
$l['setting_maxpasswordlength_desc'] = "Bu kısımdan, izin verilen maksimum şifre uzunluğunu belirleyebilirsiniz.";
$l['setting_betweenregstime'] = "İzin Verilen Kayıt Olma Aralığı?";
$l['setting_betweenregstime_desc'] = "Bu kısımdan, forumunuza bir günde kaç defa, aynı IP adresi ile yapılacak olan kayıtların, zaman aralığını <strong>Saat Biriminden</strong> ayarlayabilirsiniz.";
$l['setting_maxregsbetweentime'] = "Aynı IP Adresinden Maksimum Kayıt Limiti?";
$l['setting_maxregsbetweentime_desc'] = "Bu kısımdan, Kullanıcıların aynı gün içerisinde, aynı ıp adresi ile kaç defa kayıt yapabileceklerini belirleyebilirsiniz.";
$l['setting_allowmultipleemails'] = "Aynı E-Posta Adresi ile Çoklu kayıtlara İzin Verilsin Mi?";
$l['setting_allowmultipleemails_desc'] = "Bu kısımdan, aynı E-Posta adresi ile forumunuza çoklu kayıt iznini aktif yada pasif edebilirsiniz.";
$l['setting_emailkeep'] = "Yasaklı E-Posta Adreslerinin Kaydı Tutulsun Mu?";
$l['setting_emailkeep_desc'] = "Yeni/güncel kayıtlar sırasında eğer, yasaklı bir E-Posta adresi kullanıyorsa bunun kaydı tutulsun mu?";
$l['setting_hiddencaptchaimage'] = "Gizli Bir CAPTCHA Güvenlik Kodu Gösterilsin Mi?";
$l['setting_hiddencaptchaimage_desc'] = "Kayıt sırasında spam botları engellemek için gizli bir CAPTCHA güvenlik kodu kullanılmasını istiyor musunuz?";
$l['setting_hiddencaptchaimagefield'] = "Gizli CAPTCHA Alanı?";
$l['setting_hiddencaptchaimagefield_desc'] = "Aşağıdaki gizli CAPTCHA alanı için bir isim girebilirsiniz.";
$l['setting_usereferrals'] = "Referans Sistemi Aktif Edilsin Mi?";
$l['setting_usereferrals_desc'] = "Bu kısımdan, Kullanıcı kayıt formunda gösterilecek olan, <strong>(Referans Bilgileri Kutusunu)</strong>, tavsiye eden kullanıcı bölümünü pasif ya da aktif edebilirsiniz.";
$l['setting_coppa'] = "COPPA 13 Yaş Sınırı Kontrolü Aktif Edilsin Mi?";
$l['setting_coppa_desc'] = "Bu kısımdan, <a href=\"http://www.coppa.org/comply.htm\" target=\"_blank\">COPPA</a> yani kayıt formunun ilk aşamasında gösterilecek olan (13) yaş sınırı doğrulama kutusunu aktif etmek istiyorsanız, aşağıdaki seçeneklerden size uygun olanı seçiniz.";
$l['setting_coppa_enabled'] = "13 Yaş Sınırı Kontrolünü Aktifleştir?";
$l['setting_coppa_deny'] = "13 Yaşının Altındaki Kullanıcı Kayıtlarına İzin Verme?";
$l['setting_coppa_disabled'] = "13 Yaş Sınırı Kontrolünü Devre Dışı Bırak?";
$l['setting_username_method'] = "Kullanıcı Giriş Metodu?";
$l['setting_username_method_desc'] = "Bu ayar, Kullanıcılara giriş sırasında, aşağıdaki seçeneklere göre giriş yapmalarına olanak sağlar.";
$l['setting_username_method_0'] = "Kullanıcı Adı ile Giriş Yapılsın?";
$l['setting_username_method_1'] = "E-Posta adresi ile Giriş Yapılsın?";
$l['setting_username_method_2'] = "Kullanıcı Adı veya E-Posta Adresi ile Giriş Yapılsın?";
$l['setting_failedcaptchalogincount'] = "Başarışız Girişlerde Güvenlik Kodu Doğrulaması Gösterilsin Mi?";
$l['setting_failedcaptchalogincount_desc'] = "Bu kısımdan, kaç x defa giriş denemesi yapıldığı zaman <strong>(güvenlik kodu)</strong>, resim doğrulamasının çıkmasını istiyorsanız ayarlayabilirsiniz.<br /><strong>Örnek:</strong> Bir alttaki seçenekte giriş limiti varsayılan: 10 olarak belirtilmiş, güvenlik doğrulması için 3, bu durumda her 3 denemede bir güvenlik kodu doğrulaması gösterilecektir.<br />Ayrıca bu seçeneği devre dışı bırakmak için aşağıdaki metin kutusuna, sıfır <strong>(0)</strong> değeri verebilirsiniz.";
$l['setting_failedlogincount'] = "İzin Verilen Başarısız Giriş Limiti?";
$l['setting_failedlogincount_desc'] = "Bu kısımdan, izin verilen maksimum giriş sayısını ayarlayabilirsiniz. Bu seçeneği devre dışı bırakmak için aşağıdaki metin kutusuna ''0'' değeri giriniz.";
$l['setting_failedlogintime'] = "İzin verilen Başarısız Giriş Aralığı?";
$l['setting_failedlogintime_desc'] = "Bu kısımdan, izin verilen başarısız giriş sayısı/limiti aşıldığında, otomatik olarak çıkan giriş yasağı uyarısının zaman/dakika ayarlarını yapabilirsiniz.<br />Bu seçeneği devre dışı bırakmak için aşağıdaki metin kutusuna, sıfır <strong>(0)</strong> değeri giriniz.";
$l['setting_failedlogintext'] = "Başarısız Giriş Sayısı Gösterilsin Mi?";
$l['setting_failedlogintext_desc'] = "Bu kısımda, giriş yapan kullanıcılara kaç x defa giriş denemesi yaptıklarını gösteren uyarıyı devre dışı bırakabilirsiniz.";
$l['setting_regtime'] = "Minimum Kayıt Formunu Doldurma Süresi?";
$l['setting_regtime_desc'] = "Bu ayar, kayıt sayfasındaki kayıt formunun minimum kaç x saniyede doldurulmasını belirmenizi sağlar. Bu işlem otomatik spam kayıtları engellemek için oldukça faydalıdır.";
$l['setting_securityquestion'] = "Güvenlik Soruları Gösterilsin Mi?";
$l['setting_securityquestion_desc'] = "Bu ayar, üye kayıt formunda güvenlik soruları kutusunu gösterime açma ve kapatmanıza olanak sağlar.";
// Ayar Grubu 10: "Profile Options"
$l['setting_group_profile'] = "Kullanıcı Profili Ayarları";
$l['setting_group_profile_desc'] = "Bu ayar grubu, Kullanıcıların avatar, imza vb. gibi çeşitli profil ayarları yönetmenize olanak sağlar.";
// 10 Nolu Ayar Grubu Seçenekleri
$l['setting_sigmycode'] = "İmzada MyKod Kullanımına İzin Verilsin Mi?";
$l['setting_sigmycode_desc'] = "Bu kısımdan, kullanıcıların imzalarında Mycode Kullanım izinlerini yönetebilirsiniz.";
$l['setting_sigcountmycode'] = "İmza Kullanımında Mykod-ların Etkisi?";
$l['setting_sigcountmycode_desc'] = "Bu kısımdan, imzalardaki karakter uzunluğuna Mykod etiketlerinin de dahil edilmesini istiyorsanız, aşağıdaki seçeneklerden <strong>Evet</strong> seçeneğini seçiniz, sayılmasını (dahil edilmesini) istemiyorsanız <strong>Hayır</strong> seçeneğini seçiniz.";
$l['setting_sigsmilies'] = "İmzada İfade Kullanımına İzin Verilsin Mi?";
$l['setting_sigsmilies_desc'] = "Bu kısımdan, kullanıcıların imzalarında gülümseme\ifade Kullanım izinlerini yönetebilirsiniz.";
$l['setting_sightml'] = "İmzada [HTML] Kod Kullanımına İzin Verilsin Mi?";
$l['setting_sightml_desc'] = "Bu kısımdan, Kullanıcıların imzalarında [HTML] kod Kullanım izinlerini yönetebilirsiniz.";
$l['setting_sigimgcode'] = "İmzada [İMG] Etiketi Kullanımına İzin Verilsin Mi?";
$l['setting_sigimgcode_desc'] = "Bu kısımdan, kullanıcıların imzalarında [İMG], yani resim ekleme etiketinin, Kullanım izinlerini yönetebilirsiniz.";
$l['setting_maxsigimages'] = "İmza Başına İzin Verilen Maksimum Resim Sayısı?";
$l['setting_maxsigimages_desc'] = "Bu kısımdan, kullanıcıların imzalarında kullanabilecekleri maksimum resim sayılarını belirleyebilirsiniz.<br />Bu seçeneği devre dışı bırakmak için aşağıdaki metin kutusuna, sıfır <strong>(0)</strong> değeri giriniz.";
$l['setting_siglength'] = "İmzalarda İzin Verilen Maksimum Karakter Uzunluğu?";
$l['setting_siglength_desc'] = "Bu kısımdan, kullanıcıların imzalarında kullanabilecekleri maksimum karakter uzunluğu için Kullanım izinlerini yönetebilirsiniz.";
$l['setting_useravatar'] = "Varsayılan Kullanıcı Avatarı";
$l['setting_useravatar_desc'] = "Bu ayar, x Kullanıcının eğer avatarı yoksa varsayılan avatarını belirmenizi sağlar.";
$l['setting_useravatardims'] = "Varsayılan Avatar Boyutları";
$l['setting_useravatardims_desc'] = "Bu ayar, varsayılan avatar boyutlarını (genişlik x yükseklik) olarak belirlemenizi sağlar. <strong>Örnek:</strong> (50|50) pixel.";
$l['setting_useravatarrating'] = "İzin Verilen Gravatar Derecelendirmesi?";
$l['setting_useravatarrating_desc'] = "Bu ayar eğer, herhangi bir kullanıcı normal avatar yüklemek/kullanmak yerine Gravatar kullanmayı tercih ederse, Gravatar resimleri için resim içeriği derecelendirmesini belirlemenizi sağlar.<br />Eğer, aşağıdaki açılır seçenek sekmesinden seçmiş olduğunuz derecelendirme üzerinde bir Gravatar resmi kullanılacak olursa, otomatik olarak belirlemiş olduğunuz varsayılan avatar kullanımı devreye girecektir.<br /><strong>Gravatar Derecelendirmeleri:</strong><ul>
<li><strong>G</strong>: Herhangi bir izleme türü olan ve tüm web sitelerinde görüntülenebilir resimlere izin verilsin mi? (tavsiye edilir)</li>
<li><strong>PG</strong>: Az ya da hafif Kötü hareketler, kışkırkıtıcı giyinmiş bireyler içeren resimlere izin verilsin mi?</li>
<li><strong>R</strong>: Küfür, yoğun şiddet, çıplaklık veya tütün, akol ya da ilaç türü şeyler içeren resimlere izin verilsin mi?</li>
<li><strong>X</strong>: Cinsellik ya da aşırı rahatsız edici şiddet içeren resimlere izin verilsin mi?</li>
</ul>";
$l['setting_maxavatardims'] = "Avatar İçin İzin Verilen Maksimum Resim Boyutu?";
$l['setting_maxavatardims_desc'] = "Bu kısımdan, kullanıcıların kullanabilecekleri maksimum avatar boyutları (genişlik x yükseklik) için Kullanım izinlerini yönetebilirsiniz. <strong>Örnek:</strong> (50x50) pixel.";
$l['setting_avatarsize'] = "Avatar İçin İzin Verilen Maksimum Dosya Boyutu?";
$l['setting_avatarsize_desc'] = "Bu kısımdan, kullanıcıların yükleyebilecekleri maksimum avatar dosya boyutu (KB) izinlerini yönetebilirsiniz.";
$l['setting_avatarresizing'] = "Otomatik Avatar Boyutlandırma Modu Aktif Edilsin Mi?";
$l['setting_avatarresizing_desc'] = "Bu kısımdan, kullanıcıların kullandıkları/yükleyecekleri avatarları aşağıdaki seçenekleri kullanarak yeniden boyutlandırabilir yada bu seçimi kullanıcılara bırabilirsiniz.";
$l['setting_avatarresizing_auto'] = "Avatarları Otomatik Olarak Boyutlandır?";
$l['setting_avatarresizing_user'] = "Avatarları Boyutlandırmaları için Kullanıcılara Seçenek Göster?";
$l['setting_avatarresizing_disabled'] = "Otomatik Avatar Boyutlandırıcısını Devre Dışı Bırak?";
$l['setting_avataruploadpath'] = "Avatarların Yükleneceği Dizin Yolu?";
$l['setting_avataruploadpath_desc'] = "Bu kısımdan, avatar resimlerinin yüklenmesini istediğiniz dizin, (klasörün) yolunu ayarlayabilirsiniz. Ayrıca kullanıcıların bu dizine/klasöre avatar yükleyebilmeleri için CHMOD izinleri (777) olmalıdır.";
$l['setting_allowremoteavatars'] = "Uzaktan Avatar Kullanımına İzin Ver";
$l['setting_allowremoteavatars_desc'] = "Uzak bir sunucudan avatar kullanımına izin verip/vermeyeceğinizi ayarladığınız kısımdır.Bu ayarın etkin olması, sunucu IP adresinizin gözükmesine neden olabilmektedir.";

$l['setting_customtitlemaxlength'] = "İzin Verilen Maksimum Özel Kullanıcı Başlığı Uzunluğu?";
$l['setting_customtitlemaxlength_desc'] = "Bu kısımdan, izin verilen maksimum özel kullanıcı başlıkları uzunluğunun ayarlarını yapabilirsiniz.";
$l['setting_allowaway'] = "İzinli Statüsü Aktif Edilsin Mi?";
$l['setting_allowaway_desc'] = "Bu kısımdan, Kullanıcıların durumlarına dair, izinli olup olmadıklarını gösteren, izinli olma sebebi, gidiş ve dönüş tarihlerini belirleyebilecekleri özelliği aktif edebilirsiniz.";
$l['setting_allowbuddyonly'] = "İzin Verilen Özel Mesajlaşma Türü?";
$l['setting_allowbuddyonly_desc'] = "Bu kısımdan, kayıtlı kullanıcıların sadece arkadaş listesindeki arkadaşları ile özel mesaj sistemini kullanmalarını/seçmelerini sağlayabilirsiniz.";
// Ayar Grubu 11: "Posting"
$l['setting_group_posting'] = "Konu & Yorum Gönderimi";
$l['setting_group_posting_desc'] = "Bu ayar grubu, Kullanıcıların forumlara yeni konu ve yorum gönderebilmeleri için çeşitli ayarları yönetmenize olanak sağlar.";
// 11 Nolu Ayar Grubu Seçenekleri
$l['setting_minmessagelength'] = "İzin Verilen Minimum Konu ve Yorum Uzunluğu?";
$l['setting_minmessagelength_desc'] = "Bu kısımda, kullanıcıların gönderebilecekleri konu ve yorumlar için ''minimum'' karakter uzunluğunu ayarlayabilirsiniz.";
$l['setting_maxmessagelength'] = "İzin Verilen Maksimum Konu ve Yorum Uzunluğu?";
$l['setting_maxmessagelength_desc'] = "Bu kısımda, kullanıcıların gönderebilecekleri konu ve yorumlar için ''maksimum'' karakter uzunluğunu ayarlayabilirsiniz.";
$l['setting_mycodemessagelength'] = "Konu & Yorumlara Mykod-ların Etkisi?";
$l['setting_mycodemessagelength_desc'] = "Bu kısımdan, konu ve yorumların karakter uzunluğuna Mykod etiketlerinin de dahil edilmesini istiyorsanız, aşağıdaki seçeneklerden <strong>''Evet''</strong> seçeneğini seçiniz, sayılmasını (dahil edilmesini) istemiyorsanız <strong>''Hayır''</strong> seçeneğini seçiniz.";
$l['setting_postfloodcheck'] = "Flood Mesaj Koruması Aktif Edilsin Mi?";
$l['setting_postfloodcheck_desc'] = "Bu kısımda, kullanıcıların arka arkaya flood mesaj yazmalarını istemiyorsanız aşağıdaki <strong>Aç</strong> kutucuğunu işaretleyeniz.";
$l['setting_postfloodsecs'] = "İzin Verilen Flood Mesaj Aralığı?";
$l['setting_postfloodsecs_desc'] = "Bu kısımda, aşağıdaki metin kutusunda belirtecek olduğunuz zaman aralığı için kullanıcılara <strong>(kaç saniye)</strong> beklemeleri gerektiğini gösteren bir uyarı çıkmasını sağlayabilirsiniz.<br />Bu özelliği kullanabilmeniz için bir üsteki ''Flood Mesaj Koruması''nın aktif olması gerekir.";
$l['setting_postmergemins'] = "Flood Mesajların Birleştirme Süresi?";
$l['setting_postmergemins_desc'] = "Bu kısımda, arka arkaya yazılan flood mesajlar için birleştirme süresini dakika olarak ayarlayabilirsiniz. Böylece ard arda yazılan flood mesajlar tek bir mesaj olarak kesme çizgisi ile gösterilecektir.<br />Bu özelliği devra dışı bırakmak için aşağıdaki metin ktusuna <strong>0 (sıfır)</strong> değeri girebilirsiniz.";
$l['setting_postmergefignore'] = "Mesaj Birleştirmesinden Muaf Tutulacak Forumlar?";
$l['setting_postmergefignore_desc'] = "Bu kısımda, flood mesaj birleştirmesi için muaf, yani bu özelliğin kullanılmasını istemediğiniz forumların ID-nolarını virgül ile ayırıp aşağıdaki metin kutusuna girebilirsiniz.<br />Bu özelliği kullanmak istemiyorsanız, metin kutusunu boş bırakınız.";
$l['setting_postmergeuignore'] = "Mesaj Birleştirmesinden Muaf Tutulacak Kullanıcı Grupları?";
$l['setting_postmergeuignore_desc'] = "Bu kısımda, flood mesaj birleştirmesi için muaf, yani bu özelliğin kullanılmasını istemediğiniz kullanıcı grupların ID-nolarını virgül ile ayırıp aşağıdaki metin kutusuna girebilirsiniz.<br />Bu özelliği kullanmak istemiyorsanız, metin kutusunu <strong>Boş</strong> bırakınız.";
$l['setting_postmergesep'] = "Mesaj Birleştirme İçin Kullanılacak Ayıraç?";
$l['setting_postmergesep_desc'] = "Bu kısımda, ard arda yazılan flood mesajlar için kullanılmasını istediğiniz ayıraç türünü ayarlayabilirsiniz. Varsayılan ayıraç: <strong>[hr]</strong><br />Ayıraç için BBkod kullanarak bir grafikte ekleyebilirsiniz.";
$l['setting_logip'] = "Konu & Yorum Gönderenin IP Adresi Gösterilsin Mi?";
$l['setting_logip_desc'] = "Bu kısımda, konu ve yorum gönderen kullanıların IP adresleriniyönetici yada kullanıcı grupları için gösterim ayarlarını yapabilirsiniz.";
$l['setting_logip_no'] = "IP Adreslerini Gizle?";
$l['setting_logip_hide'] = "Sadece Admin ve Moderatörlere Göster?";
$l['setting_logip_show'] = "Tüm Kullanıcı Gruplarına Göster?";
$l['setting_showeditedby'] = "Düzenleyen Yazısı Konu ve Yorumlarda Gösterilsin Mi?";
$l['setting_showeditedby_desc'] = "Bu kısımda, herhangi bir kullanıcı konu ve yorum düzenlediği zaman, kimin düzenleme yaptığına dair bilgi gösterilmesini sağlayabilirsiniz.";
$l['setting_showeditedbyadmin'] = "Düzenleyen Yazısı Sadece Yöneticilere Gösterilsin Mi?";
$l['setting_showeditedbyadmin_desc'] = "Bu kısımda, düzenleme yapılan konu ve yorumların, düzenleyen bilgisini sadece yöneticilere gösterilmesini sağlayabilirsiniz.";
$l['setting_maxpostimages'] = "Konu ve Yorumlarda İzin Verilen Maksimum Resim Sayısı?";
$l['setting_maxpostimages_desc'] = "Bu kısımda, tüm kullanıcı grupları için konu ve yorumlara ekleyebilecekleri <strong>(gülümseme\ifade resimleride dahil)</strong> maksimum <strong>''resim''</strong> sayısını ayarlayabilirsiniz.<br /> Bu özelliğin sınırsız olması için aşağıdaki metin kutusuna <strong>0 (sıfır)</strong> değeri girebilirsiniz.";
$l['setting_maxpostvideos'] = "Konu & Yorumlarda İzin Verilen Maksimum Video Sayısı?";
$l['setting_maxpostvideos_desc'] = "Bu kısımda, tüm kullanıcı grupları için konu ve yorumlara ekleyebilecekleri maksimum <strong>video</strong> sayısını ayarlayabilirsiniz.<br /> Bu özelliğin sınırsız olması için aşağıdaki metin kutusuna <strong>0 (sıfır)</strong> değeri girebilirsiniz.";
$l['setting_subscribeexcerpt'] = "Abonelik Bildirimleri İçin Önizleme Karakter Miktarı?";
$l['setting_subscribeexcerpt_desc'] = "Bu kısımda, abonelik bildirimleri için gönderilecek olan e-posta bildirimlerinde başlık özeti olarak gösterilmesini istediğiniz mesajın karater sayısını ayarlayabilirsiniz.";
$l['setting_wordwrap'] = "Kelime Paketleme işlemi İçin İzin Verilen Karakter Sayısı?";
$l['setting_wordwrap_desc'] = "Bu kısımda, forum düzeninin işleyişi açısında faydalı olabilecek kelime paketleme işleminden önce, yapılacak olan işlemin karakter sayısını ayarlayabilirsiniz.<br />Bu özelliği devre dışı bırakmak için <strong>0 (sıfır)</strong> değeri verebilirsiniz.";
$l['setting_maxquotedepth'] = "İzin Verilen Maksimum İç İçe Alıntı Sayısı?";
$l['setting_maxquotedepth_desc'] = "Bu kısımda, konularda yapılan alıntıların iç içe gösterim sayısını ayarlayabilirsiniz.<br /><strong>Varsayılan değer:</strong> 2 olarak ayarlıdır, bu durumda 2'den fazla iç içe alıntı cevap yazıldığında, 2'den sonraki alıntı yazılar alıntı kutusunun gösterim özelliğinden ayrı (muaf) tutulacaktır.<br />Bu özelliği devre dışı bırakmak için <strong>1</strong> , sınırsız yapmak için sıfır, <strong>(0)</strong> değeri verebilirsiniz.<br />Bu ayarın maksimum, 2 olarak kalması tavsiye edilir.";
$l['setting_polloptionlimit'] = "İzin Verilen Maksimum Anket Seçenekleri Uzunluğu?";
$l['setting_polloptionlimit_desc'] = "Bu kısımda, anket seçenekleri için kullanılan başlıkların karakter uzunluklarını ayarlayabilirsiniz. bu özelliği devre dışı bırakmak için <strong>0 (sıfır)</strong> değeri verebilirsiniz.";
$l['setting_maxpolloptions'] = "İzin Verilen Maksimum Anket Seçenekleri Sayısı?";
$l['setting_maxpolloptions_desc'] = "Bu kısımda, kullanıcıların başlatacağı anketler için maksimum seçenek sayısını ayarlayabilirsiniz.";
$l['setting_polltimelimit'] = "Anket Eklemek için Zaman Sınırı?";
$l['setting_polltimelimit_desc'] = "Bu ayar, Normal üyeler için açmış oldukları konulara anket ekleme süresi sınırı koymanızı sağlar. Belirlemiş olduğunuz süre aşılmış ise, konuya anket ekleyemezler.<br />Varsayılan sınır: 12 saat, sınırsız yapmak/devre dışı bırakmak için sıfır (0) değeri giriniz.";
$l['setting_threadreview'] = "Yeni Yorum Yazılırken Son Cevaplar Gösterilsin Mi?";
$l['setting_threadreview_desc'] = "Bu kısımda, konulara yeni bir yorum, (cevap) yazılırken bir önceki yazılan yorumların listesini, editörün hemen altında görüntülenmesini istemiyorsanız aşağıdaki <strong>Hayır</strong>ı seçebilirsiniz.";
$l['setting_alloweditreason'] = "Düzenleme Sebebi İzni?";
$l['setting_alloweditreason_desc'] = "Bu ayar, kullanıcılara konu ve yorumlarını düzenleme yaptıklarında, düzenleme sebebi eklemelerini sağlayan özelliği aktif etmenizi sağlar.<br />Eğer, <strong>''Hayır''</strong> seçeneği seçilirse, düzenleme sebebi kısmı kullanıma kapatılacaktır.";
// Ayar Grubu 12: "Attachments"
$l['setting_group_attachments'] = "Ek Dosya Ayarları";
$l['setting_group_attachments_desc'] = "Bu ayar grubu, ek-(li) dosyalar için çeşitli ayarları yönetmenize olanak sağlar.";
// 12 Nolu Ayar Grubu Seçenekleri
$l['setting_enableattachments'] = "Ek Dosya Sistemi Aktif Edilsin Mi?";
$l['setting_enableattachments_desc'] = "Bu ayar, ek dosya sistemi kullanımı devre dışı bırakmanızı sağlar. Eğer, <strong>''Hayır''</strong> seçeneği seçilirse foruma ek dosya eklenmez ve varsa, mevcut ek-(li) dosyalar kullanıma tamamen kapatılır.";
$l['setting_maxattachments'] = "Konu ve Yorumlarda İzin Verilen Ek Dosya Sayısı?";
$l['setting_maxattachments_desc'] = "Bu kısımda, tüm kullanıcı grupları için konu ve yorumlara yükleyebilecekleri maksimum <strong>ek dosya (eklenti)</strong> sayısını ayarlayabilirsiniz.<br /> Bu özelliğin sınırsız olması için aşağıdaki metin kutusuna <strong>0 (sıfır)</strong> değeri girebilirsiniz.";
$l['setting_attachthumbnails'] = "Konu ve Yorumlara Eklenen Ek Dosya Tırnakları Gösterilsin Mi?";
$l['setting_attachthumbnails_desc'] = "Bu kısımda, kullanıcıların konu ve yorumlara ek dosya olarak eklemiş oldukları resimlerin, tırnak olarak gösterilme türünü ayarlayabilirsiniz.";
$l['setting_attachthumbnails_yes'] = "Tırnak Olarak Göster?";
$l['setting_attachthumbnails_no'] = "Tam Boyut Resim Göster?";
$l['setting_attachthumbnails_download'] = "İndirme Linki Olarak Göster?";
$l['setting_attachthumbh'] = "İzin Verilen Maksimum Tırnak Yüksekliği? - (height)";
$l['setting_attachthumbh_desc'] = "Bu kısımda, kullanıcıların ek dosya olarak eklemiş oldukları resimlerin, maksimum yükselik ayarlarını yapabilirsiniz.";
$l['setting_attachthumbw'] = "İzin Verilen Maksimum Tırnak Genişliği? - (width)";
$l['setting_attachthumbw_desc'] = "Bu kısımda, kullanıcıların ek dosya olarak eklemiş oldukları resimlerin, maksimum genişlik ayarlarını yapabilirsiniz.";
// Ayar Grubu 13: "Member List"
$l['setting_group_memberlist'] = "Üye Listesi Ayarları";
$l['setting_group_memberlist_desc'] = "Bu ayar grubu, üye listesi [memberlist.php] için çeşitli ayarları yönetmenize olanak sağlar.";
// 13 Nolu Ayar Grubu Seçenekleri
$l['setting_enablememberlist'] = "Üye Listesi Aktif Edilsin Mi?";
$l['setting_enablememberlist_desc'] = "Bu kısımdan, üye listesinin kullanıma/gösterime tamamen kapatabilir veya açabilirsiniz.";
$l['setting_membersperpage'] = "Sayfa Başına Gösterilecek Üye Sayısı?";
$l['setting_membersperpage_desc'] = "Bu kısımdan, üye listesinde sayfa başına kaç tane üye gösterileceğini ayarlayabilirsiniz.";
$l['setting_default_memberlist_sortby'] = "Varsayılan Listeleme Seçimi";
$l['setting_default_memberlist_sortby_desc'] = "Bu kısımda, aşağıdaki seçeneklerden üye listesi için varsayılan listeme türünü ayarlayabilirsiniz.";
$l['setting_default_memberlist_sortby_regdate'] = "Üyelik Tarihine Göre Listele";
$l['setting_default_memberlist_sortby_postnum'] = "Konu & Yorum Sayısına Göre Listele";
$l['setting_default_memberlist_sortby_username'] = "Kullanıcı Adına Göre Listele";
$l['setting_default_memberlist_sortby_lastvisit'] = "Son Ziyarete Göre Listele";
$l['setting_default_memberlist_order'] = "Varsayılan Listeleme Gösterimi";
$l['setting_default_memberlist_order_desc'] = "Bu kısımda, aşağıdaki seçeneklerden varsayılan gösterim stilini ayarlayabilirsiniz.";
$l['setting_default_memberlist_order_ascending'] = "Artan";
$l['setting_default_memberlist_order_descending'] = "Azalan";
$l['setting_memberlistmaxavatarsize'] = "Maksimum Gösterilecek Avatar Boyutları?";
$l['setting_memberlistmaxavatarsize_desc'] = "Bu kısımdan, üye listesi için kullanıcıların avatar boyutlarını ayarlayabilirsiniz. Büyük avatar resimleri otomatik olarak boyutlandırılır.";
// Ayar Grubu 14: "Reputation"
$l['setting_group_reputation'] = "Rep Puanı Ayarları";
$l['setting_group_reputation_desc'] = "Bu ayar grubu, rep puanı sistemi [reputation.php] için çeşitli ayarları yönetmenize olanak sağlar.";
// 14 Nolu Ayar Grubu Seçenekleri
$l['setting_enablereputation'] = "Rep Puanı Sistemi Aktif Edilsin Mi?";
$l['setting_enablereputation_desc'] = "Bu kısımdan, rep puanı sistemini kullanıma tamamen kapatabilir veya açabilirsiniz.";
$l['setting_negrep'] = "Negatif Rep Puanı İzni Verisiln Mi?";
$l['setting_negrep_desc'] = "Bu kısımda, bir kullanıcının başka bir kullanıcıya negatif <strong>(-)</strong> rep puanı verip, vermeyeceğini ayarlayabilirsiniz.";
$l['setting_posrep'] = "Pozitif Rep Puanı Kullanımına İzin Verisiln Mi?";
$l['setting_posrep_desc'] = "Bu kısımda, bir kullanıcının başka bir kullanıcıya pozitif <strong>(+)</strong> rep puanı verip, vermeyeceğini ayarlayabilirsiniz.";
$l['setting_neurep'] = "Tarafsız Rep Puanı Kullanımına İzin Verilsin Mi?";
$l['setting_neurep_desc'] = "Bu kısımda, bir kullanıcının başka bir kullanıcıya tarafsız <strong>(0)</strong> rep puanı verip, vermeyeceğini ayarlayabilirsiniz.";
$l['setting_multirep'] = "Çoklu Rep Puanı Kullanımına İzin Verilsin Mi?";
$l['setting_multirep_desc'] = "Bu kısımda, bir kullanıcının başka bir kullanıcıya bir defadan fazla rep puanı vermesini engelleyebilirsiniz.<br /><strong>Not:</strong> Verilen rep puanların konu ve yorumlara etki yoktur.";
$l['setting_postrep'] = "Konu & Yorum Bağlantılı Rep Puanı Verilsin Mi?";
$l['setting_postrep_desc'] = "Bu kısımda, verilen rep puanlarının konu ve yorumlar için bağlantılı olup olmayacağını ayarlayabilirsiniz.";
$l['setting_repsperpage'] = "Sayfa Başına Gösterilecek Rep Puanı Yorumları?";
$l['setting_repsperpage_desc'] = "Bu kısımda, bir kullanıcının rep puanı tablosundaki sayfa başına gösterilmesini istediğiniz yorum sayısını ayarlayabilirsiniz.";
$l['setting_maxreplength'] = "Maksimum Rep Puanı Yorumu Uzunluğu?";
$l['setting_maxreplength_desc'] = "Bu kısımdan, rep puanı yorumları için izin verilen maksimum karakter sayısını ayarlayabilirsiniz.";
$l['setting_minreplength'] = "Minimum Rep Puanı Yorumu Uzunluğu?";
$l['setting_minreplength_desc'] = "Bu kısımdan, rep puanı yorumları için izin verilen minimum karakter sayısını ayarlayabilirsiniz.";
// Ayar Grubu 15: "Warning System Settings"
$l['setting_group_warning'] = "Uyarı Sistemi Ayarları";
$l['setting_group_warning_desc'] = "Bu ayar grubu, uyarı sistemi için çeşitli ayarları yönetmenize olanak sağlar.";
// 15 Nolu Ayar Grubu Seçenekleri
$l['setting_enablewarningsystem'] = "Uyarı Sistemi Aktif Edilsin Mi?";
$l['setting_enablewarningsystem_desc'] = "Bu kısımda, uyarı sistemini kullanıma kapatabilir yada açabilirsiniz.";
$l['setting_allowcustomwarnings'] = "Özel Uyarı Tipine İzin Verilsin Mi?";
$l['setting_allowcustomwarnings_desc'] = "Bu kısımda, uyarı sistemi için özel bir sebep ve kullanıcıları uyarmak için verilen izinlere göre belirtilen uyarı seviyesi miktarının kullanılmasına olanak sağlayabilirsiniz.";
$l['setting_canviewownwarning'] = "Kullanıcılar Kendi Uyarılarına Bakabilir Mi?";
$l['setting_canviewownwarning_desc'] = "Bu kısımda, kullanıcıların kontrol paneli aracılığı ile kendi uyarı puanlarına bakmalarını sağlayabilirsiniz.";
$l['setting_allowanonwarningpms'] = "Uyarı Bildirimleri (ÖM) Anonim/Gizli Gönderilsin Mi?";
$l['setting_allowanonwarningpms_desc'] = "Bu ayar, forum yöneticileri için uyarı verdikleri kullanıcılara, özel mesaj bildirimi ile bilgilendirme mesajını anonim/gizli kullanıcı olarak gönderebilmelerini sağlar.";
$l['setting_maxwarningpoints'] = "İzin Verilen Maksimum Uyarı Seviyesi?";
$l['setting_maxwarningpoints_desc'] = "Bu kısımda, bir kullanıcıya verilebilecek maksimum uyarı puanı için %100 üzerinden seviye ayarlarını yapabilirsiniz.<br /><strong>Örnek:</strong> 1 ila 10 arası değerler için: +1 --> %10 yada +10 --> %100 gibi gösterilir.";
// Ayar Grubu 16: "Private Messaging"
$l['setting_group_privatemessaging'] = "Özel Mesaj Sistemi";
$l['setting_group_privatemessaging_desc'] = "Bu ayar grubu, MyBB özel mesaj sistemi [private.php] için çeşitli ayarları yönetmenize olanak sağlar.";
// 16 Nolu Ayar Grubu Seçenekleri
$l['setting_enablepms'] = "Özel Mesaj Sistemi Aktif Edilsin Mi?";
$l['setting_enablepms_desc'] = "Bu kısımdan, özel mesaj (ÖM) sistemini kulanıma tamamen kapatabilir yada açabilirsiniz.";
$l['setting_pmquickreply'] = "Hızlı Cevap Kutusu Gösterilsin Mi?";
$l['setting_pmquickreply_desc'] = "Bu ayar, gelen özel mesajlar görüntülenince, hemen altında hızlı cevap formunun/kutusunun çıkmasını sağlar.";
$l['setting_pmsallowhtml'] = "Özel Mesajlarda [HTML] Kod Kulanımına İzin Verilsin Mi?";
$l['setting_pmsallowhtml_desc'] = "Bu kısımdan, kullanıcıların özel mesaj gönderimleri için [HTML] kod Kullanım izinlerini yönetebilirsiniz.";
$l['setting_pmsallowmycode'] = "Özel Mesajlarda [MyKod] Etiketleri Kulanımına İzin Verilsin Mi?";
$l['setting_pmsallowmycode_desc'] = "Bu kısımdan, kullanıcıların özel mesaj gönderimleri için [MyKod] Kullanım izinlerini yönetebilirsiniz.";
$l['setting_pmsallowsmilies'] = "Özel Mesajlarda (İfade) Kulanımına İzin Verilsin Mi?";
$l['setting_pmsallowsmilies_desc'] = "Bu kısımdan, kullanıcıların özel mesaj gönderimleri için gülümseme\ifade Kullanım izinlerini yönetebilirsiniz.";
$l['setting_pmsallowimgcode'] = "Özel Mesajlarda [İMG] Etiketi Kulanımına İzin Verilsin Mi?";
$l['setting_pmsallowimgcode_desc'] = "Bu kısımdan, kullanıcıların özel mesaj gönderimleri için [İMG] etiketinin Kullanım izinlerini yönetebilirsiniz.";
$l['setting_pmsallowvideocode'] = "Özel Mesajlarda [Video] Etiketi Kulanımına İzin Verilsin Mi?";
$l['setting_pmsallowvideocode_desc'] = "Bu kısımdan, kullanıcıların özel mesaj gönderimleri için [Video] etiketinin Kullanım izinlerini yönetebilirsiniz.";
$l['setting_pmfloodsecs'] = "Özel Mesajlaşma İçin İzin Verilen Flood Zaman Aralığı?";
$l['setting_pmfloodsecs_desc'] = "Bu kısımda, kullanıcıların kendi aralarında özel mesaj alım ve gönderimleri için izin verilen zaman aralığını saniye olarak ayarlayabilirsiniz.<br />Varsayılan zaman aralığı: 60 saniye (1 dk.), Bu özelliği sınırsız yapmak için ''0'' değeri verebilirsiniz.";
$l['setting_showpmip'] = "Özel Mesaj Gönderenin IP Adresi Gösterilsin Mi?";
$l['setting_showpmip_desc'] = "Bu kısımdan, özel mesaj (ÖM) gönderen kullanıların IP adreslerini yönetici yada kullanıcı grupları için gösterim ayarlarını yapabilirsiniz.";
$l['setting_showpmip_no'] = "IP Adreslerini Gizle?";
$l['setting_showpmip_hide'] = "Sadece Admin ve Moderatörlere Göster?";
$l['setting_showpmip_show'] = "Tüm Kullanıcı Gruplarına Göster?";
$l['setting_maxpmquotedepth'] = "İzin Verilen Maksimum İç İçe (ÖM) Alıntı Sayısı?";
$l['setting_maxpmquotedepth_desc'] = "Bu kısımdan, özel mesajlarda alıntıların iç içe gösterim sayısını ayarlayabilirsiniz.<br /><strong>Varsayılan değer:</strong> 2 olarak ayarlıdır, bu durumda 2'den fazla iç içe alıntı cevap yazıldığında, 2'den sonraki alıntı yazılar alıntı kutusunun gösterim özelliğinden ayrı (muaf) tutulacaktır.<br />Bu özelliği devre dışı bırakmak için 1 , sınırsız yapmak için sıfır, <strong>(0)</strong> değeri giriniz.<br />Bu ayarın maksimum, 2 olarak kalması tavsiye edilir.";
// Ayar Grubu 17: "Calendar"
$l['setting_group_calendar'] = "Takvim - Ajanda Ayarları";
$l['setting_group_calendar_desc'] = "Bu ayar grubu, takvim sayfası [calendar.php] için çeşitli ayarları yönetmenize olanak sağlar.";
// 17 Nolu Ayar Grubu Seçenekleri
$l['setting_enablecalendar'] = "Takvim Sayfası Aktif Edilsin Mi?";
$l['setting_enablecalendar_desc'] = "Bu kısımdan, Takvim sayfasını kullanıma tamamen kapatabilir yada açabilirsiniz.";
// Ayar Grubu 18: "Who's Online"
$l['setting_group_whosonline'] = "Kimler Çevrimiçi Ayarları";
$l['setting_group_whosonline_desc'] = "Bu ayar grubu, kimler çevrimiçi fonksiyonları [online.php] için çeşitli ayarları yönetmenize olanak sağlar.";
// 18 Nolu Ayar Grubu Seçenekleri
$l['setting_wolcutoffmins'] = "Çevrimiçi Olarak Geçirilen Zaman Ayarı?";
$l['setting_wolcutoffmins_desc'] = "Bu kısımda, kullanıcıların forumdan çıkış yaptıkları halde çevrimiçi listesinde online gösterileceği zaman ayarını dakika olarak değiştirebilirsiniz.<br />Tavsiye edilen çevrimiçi süresi: 15 dk'dır.";
$l['setting_refreshwol'] = "Kimler Çevrimiçi Listesinin Yenilenmesi Süresi?";
$l['setting_refreshwol_desc'] = "Bu kısımda, kimler çevrimiçi, [online.php] sayfası için yenilenmesini istediğiniz zaman ayarını dakika olarak değiştirebilirsiniz.<br /><strong>Örnek:</strong> 1 dk. 60 saniye.";
$l['setting_wolorder'] = "Kimler Çevrimiçi Listeleme Metodu?";
$l['setting_wolorder_desc'] = "Bu ayar, çevrimiçi kullanıcıları, kullanıcı adı veya zon ziyaretine göre listelemenize olanak sağlar.<br /><strong>Not:</strong> Bu özellik sadece, forum index sayfası ve portal sayfasındaki kimler çevrimiçi listesi için geçerlidir.";
$l['setting_wolorder_username'] = "Kullanıcı Adına Göre Listele (Artan)";
$l['setting_wolorder_activity'] = "Son Ziyarete Göre Listele (Azalan)";
// Ayar Grubu 19: "User Pruning"
$l['setting_group_userpruning'] = "Kullanıcı Ayıklama Sistemi";
$l['setting_group_userpruning_desc'] = "Bu ayar grubu, sisteminizdeki aktif olmayan kullanıcıların ayıklanmasına, silinmesine ve konu & yorumlarınında temizlenmesine olanak sağlar.";
// 19 Nolu Ayar Grubu Seçenekleri
$l['setting_enablepruning'] = "Kullanıcı Ayıklama Sistemi Aktif Edilsin Mi?";
$l['setting_enablepruning_desc'] = "Bu kısımda, kullanıcı ayıklama sitemini tamamen açabilir yada kapatabilirsiniz.";
$l['setting_enableprunebyposts'] = "Kullanıcıların Konu & Yorum Sayıları Ayıklansın Mı?";
$l['setting_enableprunebyposts_desc'] = "Bu kısımda, kullanıcıların konu & yorumlarının ayıklanmasını sağlayabilirsiniz.";
$l['setting_prunepostcount'] = "Ayıklanmasını İstediğiniz Konu & Yorum Sayısı?";
$l['setting_prunepostcount_desc'] = "Bu kısımda, kullanıcıların ayıklanmasını istediğiniz konu & yorum sayısını ayarlayabilirsiniz.";
$l['setting_prunepostcountall'] = "Tüm Mesajlar Sayılsın Mı?";
$l['setting_prunepostcountall_desc'] = "Eğer evet olarak seçilirse, kullanıcıların tüm mesajları, (Konu & Yorumları) dikkate alınarak ayıklama işlemi uygulanacaktır.";
$l['setting_dayspruneregistered'] = "İzin Verilen Günlük Konu & Yorum Sayısı?";
$l['setting_dayspruneregistered_desc'] = "Bu kısımda, kullanıcıların bir günlük gönderebilecekleri konu & yorum sayısını ayarlayabilirsiniz.";
$l['setting_pruneunactived'] = "Aktif - ''Online'' Olmayan Kullanıcılar Ayıklansın Mı?";
$l['setting_pruneunactived_desc'] = "Bu kısımda, uzun süre online olmayan kullanıcıların ayıklanmasını sağlayabilirsiniz.";
$l['setting_dayspruneunactivated'] = "Hesabı Aktif Olmayan Kullanıcılar Ayıklansın Mı?";
$l['setting_dayspruneunactivated_desc'] = "Bu kısımda, hesapları aktif edilmemiş kullanıcıların ayıklanmasını sağlayabilirsiniz.";
$l['setting_prunethreads'] = "Kullanıcıların Konu & Yorumları Ayıklansın Mı?";
$l['setting_prunethreads_desc'] = "Bu kısımda, hesabı aktif olmayan, uzun süre online olmayan kullanıcıların konu & yorumlarının silinmesini sağlayabilirsiniz.";
// Ayar Grubu 20: "Portal Settings"
$l['setting_group_portal'] = "Portal Ayarları";
$l['setting_group_portal_desc'] = "Bu ayar grubu, portal sayfası [portal.php] için çeşitli ayarları yönetmenize olanak sağlar.";
// 20 Nolu Ayar Grubu Seçenekleri
$l['setting_portal'] = "Portal Sayfası Aktif Edilsin Mi?";
$l['setting_portal_desc'] = "Bu kısımdan, Portal sayfasını kullanıma tamamen kapatabilir yada açabilirsiniz.";
$l['setting_portal_announcementsfid'] = "Portal Sayfasında Hangi Forumlardaki Konular Gösterilsin?";
$l['setting_portal_announcementsfid_desc'] = "Bu kısımdan, portal sayfasında çıkmasını istediğiniz konulara ait forum-(ları) seçebilirsiniz.";
$l['setting_portal_numannouncements'] = "Portal'da Sayfa Başına Gösterilmesini İstediğiniz Duyuru Sayısı?";
$l['setting_portal_numannouncements_desc'] = "Bu kısımdan, portal sayfası için sayfa başına duyuru olarak gösterilmesini istediğiniz konu sayısını ayarlayabilirsiniz.<br />Örneğin sayfa başına 5 konu gösterilsin şeklinde belirtilirse, 5 konudan sonrası için (multipage) fonksiyonu devreye girecektir.";
$l['setting_portal_showwelcome'] = "Hoşgeldiniz - Login Kutusu Gösterilsin Mi?";
$l['setting_portal_showwelcome_desc'] = "Bu kısımda, forumunuza gelen ziyaretçiler için hoşgeldiniz, (giriş yap) kutusunu gösterebilirsiniz.";
$l['setting_portal_showpms'] = "Kayıtlı Kullanıcılara Özel Mesaj Sayısı Gösterilsin Mi?";
$l['setting_portal_showpms_desc'] = "Bu kısımda, portal sayfasını ziyaret eden kayıtlı kullanıcılar için özel mesaj sayılarını gösteren bilgi kutusunu gösterebilirsiniz.";
$l['setting_portal_showstats'] = "Forum İstatistikleri Gösterilsin Mi?";
$l['setting_portal_showstats_desc'] = "Bu kısımda, toplam konu, yorum ve üye gibi istatiskleri gösteren küçük forum istatistikleri kutusunun gösterilmesini sağlayabilirsiniz.";
$l['setting_portal_showwol'] = "Kimler Çevrimiçi Kutusu Gösterilsin Mi?";
$l['setting_portal_showwol_desc'] = "Bu kısımda, portal sayfasını ziyaret eden kullanıcılar için kimler çevriçi kutusunu gösterebilirsiniz.";
$l['setting_portal_showsearch'] = "Hızlı Arama Kutusu Gösterilsin Mi?";
$l['setting_portal_showsearch_desc'] = "Bu kısımda, portal sayfasını ziyaret eden kullanıcılar için hızlı arama kutusunu gösterebilirsiniz.";
$l['setting_portal_showdiscussions'] = "Son Yorumlar Kutusu Gösterilsin Mi?";
$l['setting_portal_showdiscussions_desc'] = "Bu kısımda, portal sayfasını ziyaret eden kullanıcılar için forumdaki son yorumlara ilişkin kutuyu gösterebilirsiniz.";
$l['setting_portal_showdiscussionsnum'] = "Son Yorumlar Kaç Tane Gösterilsin?";
$l['setting_portal_showdiscussionsnum_desc'] = "Bu kısımda, portal sayfası için gösterilmesini istediğiniz son yorumların sayısını ayarlayabilirsiniz.";
$l['setting_portal_excludediscussion'] = "Son Yorumlarda Muaf Tutulacak Forum-(lar)?";
$l['setting_portal_excludediscussion_desc'] = "Bu ayar, portal sayfasındaki ''son yorumlar kutusunda'' gösterilmesini istemediğiniz konulara ait forumları seçmenize olanak sağlar.<br />Aşağıdaki seçeneklerden seçiminize bağlı olarak seçmiş olduğunuz forum ya da forumlarda, açılan konulara yorum yazılınca, portal sayfasındaki ''son yorumlar kutusunda'' gösterilmez.";
// Ayar Grubu 21: "Search System"
$l['setting_group_search'] = "Gelişmiş Arama Sistemi";
$l['setting_group_search_desc'] = "Bu ayar grubu, MyBB'nin gelişmiş arama sistemi [search.php] için çeşitli ayarları yönetmenize olanak sağlar.";
// 21 Nolu Ayar Grubu Seçenekleri
$l['setting_searchtype'] = "Arama Sistemi Türü?";
$l['setting_searchtype_desc'] = "Bu kısımdan, arama sistemi türünü <strong>standart</strong> yada <strong>Tam Metin</strong> araması olarak ayarlayabilirsiniz. <br />Standart arama hızlı aramalar için kelime odaklıdır, tam metin araması, standart arama türüne göre daha güçlü ve gelişmiş bir tarama özelliğine sahiptir.";
$l['setting_searchtype_standard'] = "Standart Arama";
$l['setting_searchtype_fulltext'] = "Tam Metin Arama";
$l['setting_searchfloodtime'] = "Arama İçin İzin Verilen Flood Zaman Aralığı?";
$l['setting_searchfloodtime_desc'] = "Bu kısımdan, kullanıcılara aşırı arama yapmalarını ve sunucunun kasmasını önlemek için aşağıdaki metin kutusuna, ard arda arama yapmaları için izin verilen zaman aralığını saniye olarak girebilirsiniz.<br />Bu özelliği devre dışı bırakmak için <strong>0 (sıfır)</strong> değeri verebilirsiniz.";
$l['setting_minsearchword'] = "Aranacak Kelime İçin Minimum Karakter Uzunluğu?";
$l['setting_minsearchword_desc'] = "Bu kısımdan, kullanıcıların arama yapacakları kelime için minimum karakter sınırını ayarlayabilrisiniz.<br /><strong>MySQL sorgularını azaltmak için Tavsiye edilen karakter sayısı:</strong> 3 ila 4 arasıdır.";
$l['setting_searchhardlimit'] = "Maksimum Gösterilecek Arama Sonuçları Sayısı?";
$l['setting_searchhardlimit_desc'] = "Bu kısımdan, arama sonuçları için listelenecek olan konu sayısını belirleyebilirsiniz. Büyük forumlar için tavsiye edilen sayı: 1000'den fazla olmamalıdır.<br />Bu özelliği devre dışı bırakmak için <strong>0 (sıfır)</strong> değeri verebilirsiniz.";
// Ayar Grubu 22: "Clickable Smilies and BB Code"
$l['setting_group_clickablecode'] = "Tıklanalabilir İfadeler & BB Kodları";
$l['setting_group_clickablecode_desc'] = "Bu ayar grubu, tıklanabilir gülümseme\ifade ve BB kodları/butonları için çeşitli ayarları yönetmenize olanak sağlar.";
// 22 Nolu Ayar Grubu Seçenekleri
$l['setting_bbcodeinserter'] = "Konu Editöründe BB Kodları/Butonları Gösterilsin Mi?";
$l['setting_bbcodeinserter_desc'] = "Bu kısımda, Konu açma editöründe (mykod) BB kodları butonlarını gösterime kapatabilir veya açabilirsiniz.<br />Bu ayarın, <strong>''Açık''</strong> olarak seçilmesi tavsiye edilir.";
$l['setting_partialmode'] = "Tıklanabilir BB Kodları Kısmi Modunda Göster";
$l['setting_partialmode_desc'] = "Bu seçenek eğer, <strong>''Evet''</strong> olarak seçilirse metin edötörü kısmi modunda olacaktır. Böylece, [quote] , [img] ve [video] vb. gibi mykod etiketleri düz metin olarak yazı alanında gösterilecektir.";
$l['setting_smilieinserter'] = "Tıklanalabilir ifadeler Gösterilsin Mi?";
$l['setting_smilieinserter_desc'] = "Bu kısımdan, yeni konu yada yeni yorum yazarken gülümseme\ifadeleri gösterime kapatabilir veya açabilirsiniz.<br />Bu ayarın, <strong>''Açık''</strong> olarak seçilmesi tavsiye edilir.";
$l['setting_smilieinsertertot'] = "Gösterilecek Tıklanalabilir İfade Sayısı?";
$l['setting_smilieinsertertot_desc'] = "Bu kısımdan, yeni konu yada yeni yorum yazarken gösterilmesini istediğiniz gülümseme\ifade sayısını ayarlayabilirsiniz.";
$l['setting_smilieinsertercols'] = "Gösterilecek Tıklanalabilir İfade Bloğu Sayısı?";
$l['setting_smilieinsertercols_desc'] = "Bu kısımdan, yeni konu yada yeni yorum yazarken gösterilmesini istediğiniz gülümseme\ifadeler için blok/sütun sayısını ayarlayabilirsiniz.";
$l['setting_allowbasicmycode'] = "Temel MyKod Butonları Gösterilsin Mi?";
$l['setting_allowbasicmycode_desc'] = "Bu ayar, metin editöründeki temel, <strong>[b], [i], [u], [s], [hr]</strong>  mykod butonlarını gösterime kapatmanızı sağlar. ";
$l['setting_allowcolormycode'] = "Yazı Rengi Butonu Gösterilsin Mi?";
$l['setting_allowcolormycode_desc'] = "Bu ayar, metin editöründe <strong>''yazı rengi''</strong> seçimi için kullanılan, mykod/bbcode butonunu gösterime kapatmanızı sağlar.";
$l['setting_allowsizemycode'] = "Yazı Boyutu Butonu Gösterilsin Mi?";
$l['setting_allowsizemycode_desc'] = "Bu ayar, metin editöründe <strong>''yazı boyutu''</strong> seçimi için kullanılan, mykod/bbcode butonunu gösterime kapatmanızı sağlar.";
$l['setting_allowfontmycode'] = "Yazı Tipi Butonu Gösterilsin Mi?";
$l['setting_allowfontmycode_desc'] = "Bu ayar, metin editöründe <strong>''yazı tipi''</strong> seçimi için kullanılan, mykod/bbcode butonunu gösterime kapatmanızı sağlar.";
$l['setting_allowlinkmycode'] = "Link Ekleme Butonu Gösterilsin Mi?";
$l['setting_allowlinkmycode_desc'] = "Bu ayar, metin editöründe <strong>''[url] / link eklemek''</strong> için kullanılan, mykod/bbcode butonunu gösterime kapatmanızı sağlar.";
$l['setting_allowemailmycode'] = "E-Posta Ekleme Butonu Gösterilsin Mi?";
$l['setting_allowemailmycode_desc'] = "Bu ayar, metin editöründe <strong>''[email] / e-posta adresi eklemek''</strong> için kullanılan, mykod/bbcode butonunu gösterime kapatmanızı sağlar.";
$l['setting_allowalignmycode'] = "Yazıyı Hizalama Butonları Gösterilsin Mi?";
$l['setting_allowalignmycode_desc'] = "Bu ayar, metin editöründe yazıyı hizalamak için <strong>''[align=left], [align=center], [align=right], [align=justify]''</strong> kullanılan, mykod/bbcode butonlarını gösterime kapatmanızı sağlar.";
$l['setting_allowlistmycode'] = "Yazı Listeleme Butonları Gösterilsin Mi?";
$l['setting_allowlistmycode_desc'] = "Bu ayar, metin editöründe yazıyı listelemek için <strong>''[list] ve [list=1]''</strong> kullanılan, (noktalı/numaralı liste) mykod/bbcode butonlarını gösterime kapatmanızı sağlar.";
$l['setting_allowcodemycode'] = "Alın, Kod & PHP Kod Butonları Gösterilsin Mi?";
$l['setting_allowcodemycode_desc'] = "Bu ayar, metin editöründeki <strong>''[code], [php] ve [quote]''</strong> için kullanılan, mykod/bbcode butonlarını gösterime kapatmanızı sağlar.";
$l['setting_allowsymbolmycode'] = "Özel Sembol Mykodlarına İzin Verilsn Mi?";
$l['setting_allowsymbolmycode_desc'] = "Bu ayar, tüm kullanıcılara mevcut, (tm), (c) ve (r) mykod etiketlerini kullanmalarına izin verir.<br /><strong>Örnek:</strong> (tm) => ™ , (c) => © , (r) => ®";
$l['setting_allowmemycode'] = "/me ve /slap Etiketleri Kullanımı Aktif Edilsin Mi?";
$l['setting_allowmemycode_desc'] = "Bu ayar, konu ve yorumlarda kullanıcıların birbirlerinden bahsettiklerini ''kırmızı renkli yazı'' ile imleyen kısa yol komutlarıdır.<br />/me komutu bir üyenin kendi adını, /slap komutu ile de bir üyenin başka bir üye ve/veya üyelerden bahsettiğini göstermeyi sağlar.<br /><strong>Örneklere bakınız:</strong><br />Resim 1 /me : <a href=\"../images/admincp/misc/me.png\" target=\"_blank\">Tıkla</a> <img src=\"../images/icons/external_link.png\" alt=\"\" width=\"9\" height=\"9\" /><br />Resim 2 /slap : <a href=\"../images/admincp/misc/slap.png\" target=\"_blank\">Tıkla</a> <img src=\"../images/icons/external_link.png\" alt=\"\" width=\"9\" height=\"9\" />";
$l['setting_guestimages'] = "Resim Önizlemelerini Ziyaretçilere Göster?";
$l['setting_guestimages_desc'] = "Bu ayar, forumdaki <strong>[img]resim[/img]</strong> etiketileri içinde eklenen resimlerin önizlemelerini ziyaretçilere kapatıp link olarak gösterilmesini sağlar.<br />Resimleri tamamen gizlemez, sadece önizlemeyi engelleyip resimlerin kaynak linkini gösterir.";
$l['setting_guestvideos'] = "Video Önizlemelerini Ziyaretçilere Göster?";
$l['setting_guestvideos_desc'] = "Bu ayar, forumdaki <strong>[video]video[/video]</strong> etiketileri içinde eklenen videoların önizlemelerini ziyaretçilere kapatıp link olarak gösterilmesini sağlar.<br />Videoları tamamen gizlemez, sadece önizlemeyi engelleyip videoların kaynak linkini gösterir.";
// Ayar Grubu 23: "Control Panel Preferences (Global)"
$l['setting_group_cpprefs'] = "Admin Paneli Tercihleri (Genel)";
$l['setting_group_cpprefs_desc'] = "Bu ayar grubu, MyBB admin kontrol panelinin dil seçimi, tema değişiklikleri için çeşitli ayarları yönetmenize olanak sağlar.";
// 23 Nolu Ayar Grubu Seçenekleri
$l['setting_cplanguage'] = "Admin Paneli Dil Seçimi";
$l['setting_cplanguage_desc'] = "Bu kısımda, MyBB admin kontrol paneli için kullanmak istediğiniz dili seçebilirsiniz.";
$l['setting_cpstyle'] = "Admin Paneli Tema Seçimi";
$l['setting_cpstyle_desc'] = "Bu kısımda, MyBB admin kontrol paneli için kullanmak istediğiniz tema stilini seçebilirsiniz.";
$l['setting_maxloginattempts'] = "İzin Verilen Maksimum Başarısız Giriş Denemesi?";
$l['setting_maxloginattempts_desc'] = "Bu kısımda, MyBB admin kontrol paneli için izin verilen maksimum başarısız giriş sayısını ayarlayabilirsiniz.<br />Bu özelliği devre dışı bırakmak için <strong>0 (sıfır)</strong> değeri verebilirsiniz.";
$l['setting_loginattemptstimeout'] = "İzin Verilen Başarısız Giriş Zaman Aralığı?";
$l['setting_loginattemptstimeout_desc'] = "Bu kısımda, MyBB admin kontrol paneli için izin verilen başarısız giriş sayısı aşıldığında beklenmesi gereken zaman aralığını dakika olarak ayarlayabilirsiniz.<br />Bu özelliği devre dışı bırakmak için <strong>0 (sıfır)</strong> değeri verebilirsiniz.";
// Ayar Grubu 24: "Mail Settings"
$l['setting_group_mailsettings'] = "E-Posta & Toplu E-Posta Ayarları";
$l['setting_group_mailsettings_desc'] = "Bu ayar grubu, MyBB'nin E-Posta sistemi, PHP ve SMTP Toplu E-Posta işleyicileri için çeşitli ayarları yönetmenize olanak sağlar.";
// 24 Nolu Ayar Grubu Seçenekleri
$l['setting_mail_handler'] = "E-Posta İşleyicisi Seçimi";
$l['setting_mail_handler_desc'] = "Bu kısımda, MyBB'nin E-Posta sistemi için E-Posta işleyicisi türünü sunucu durumunuza göre seçebilirsiniz.<br />Bazı firmalar, PHP Mail işleyicisini spam saldırılarından korunmak için kapalı tuktuklarından dolayı PHP Mail işleyicisi çalışmayabilir. Bu durumda SMTP Mail işleyicisini tercih etmeniz ve kullanmanız tavsiye edilir.";
$l['setting_mail_handler_mail'] = "PHP Mail İşleyicisi";
$l['setting_mail_handler_smtp'] = "SMTP Mail İşleyicisi";
$l['setting_mail_parameters'] = "PHP Mail İçin Ek Parametreler?";
$l['setting_mail_parameters_desc'] = "Bu seçenek, PHP mail işleleyicisi seçildiğinde, php mail için ek parametreler girmenizi sağlar. PHP mail hakkında ayrıntı bilgi için <a href=\"http://php.net/function.mail\" target=\"_blank\">Buraya</a> tıklayın.";
$l['setting_smtp_host'] = "SMTP Host Adı";
$l['setting_smtp_host_desc'] = "E-Postaların SMTP server üzerinden gönderileceği hostun adını giriniz.<br />(<strong>Örnk:</strong> mail.siteadı.com, smtp.gmail.com veya mail.sunucuadı.com ya da sunucunun ıp adresi gibi)";
$l['setting_smtp_port'] = "SMTP Portu";
$l['setting_smtp_port_desc'] = "E-Postaların SMTP server üzerinden gönderileceği port bilgisini giriniz.(<strong>Örnk:</strong> 25, 465, 587)";
$l['setting_smtp_user'] = "SMTP Kullanıcı Adı";
$l['setting_smtp_user_desc'] = "SMTP server ile kimlik denetlemek için kullanılacak olan kullanıcı adını giriniz. (<strong>Örnk:</strong> isim@siteadı.com, isim@gmail.com gibi)";
$l['setting_smtp_pass'] = "SMTP Şifresi";
$l['setting_smtp_pass_desc'] = "SMTP server ile kimlik denetlemek için kullanılacak olan şifreyi giriniz. (kullanıcı adının şifresini giriyorsunuz)";
$l['setting_secure_smtp'] = "SMTP Şifreleme Modu";
$l['setting_secure_smtp_desc'] = "SMTP server ile bağlantı kurulabilmesi için şifreleme türünü seçiniz.";
$l['setting_secure_smtp_0'] = "Şifreleme yok";
$l['setting_secure_smtp_1'] = "SSL şifrelemesi kullan";
$l['setting_secure_smtp_2'] = "TLS şifrelemesi kullan";
$l['setting_mail_logging'] = "Sistem E-Posta Kayıtları";
$l['setting_mail_logging_desc'] = "Bu seçenek, gönderilen E-Posta ile Konuyu Arkadaşına Gönder aracının kullanılması ve gönderilen E-Postalardaki bağlantılar ile alıcıya oturum açma izni verilmesini sağlar.";
$l['setting_mail_logging_0'] = "E-Posta Kayıtçısını kapat";
$l['setting_mail_logging_1'] = "E-Postaları İçeriksiz kaydet";
$l['setting_mail_logging_2'] = "Tüm E-Postaları Günlüğe kaydet";
$l['setting_mail_message_id'] = "E-Posta Başlıklarına Gönderenin Kimliği Eklensin Mi?";
$l['setting_mail_message_id_desc'] = "Bu seçenek, forumdan gönderilen E-Postaların spam olarak işaretlenmesini engeller. Aynı zamanda bu özellik bazı host firmalarında devre dışı olabilir.";
// Ayar Grubu 25: "Contact Settings"
$l['setting_group_contactsettings'] = "İletişim Ayarları";
$l['setting_group_contactsettings_desc'] = "Bu ayar grubu, iletişim formu/sayfası [contact.php] için çeşitli ayarları yönetmenize olanak sağlar.";
// 25 Nolu Ayar Grubu Seçenekleri
$l['setting_contact'] = "İletişim Sayfası Aktif Edilsin Mi?";
$l['setting_contact_desc'] = "Bu kısımdan, İletişim formunu/sayfasını kullanıma/erişime tamamen kapatabilir yada açabilirsiniz.";
$l['setting_contact_guests'] = "İletişim Sayfası Ziyaretçilere Kapatılsın Mı?";
$l['setting_contact_guests_desc'] = "Bu kısımdan, iletişim formunu/sayfasını ziyaretçilerin kullanımına/erişimine tamamen kapatabilir yada açabilirsiniz.";
$l['setting_contact_badwords'] = "İletişim Sayfasında Kelime Filtreme Aktif Edilsin Mi?";
$l['setting_contact_badwords_desc'] = "Bu ayar, ''Kelime Filtreleme'' kısmında mevcut ya da ekleyeceğiniz filtrelerin, iletişim formu/sayfası için de geçerli olmasını sağlar.";
$l['setting_contact_maxsubjectlength'] = "Maksimum İletişim Başlığı Uzunluğu?";
$l['setting_contact_maxsubjectlength_desc'] = "Bu ayar, iletişim formu sayfasındaki iletişim başlığı için maksimum izin verilen karakter uzunluğunu belirlemenizi sağlar.<br />Başlık sınırını devre dışı bırakmak, (sınırsız yapmak) için sıfır, <strong>(0)</strong> değeri giriniz.";
$l['setting_contact_minmessagelength'] = "Minimum İletişim Mesajı Uzunluğu?";
$l['setting_contact_minmessagelength_desc'] = "Bu ayar, iletişim formu sayfasındaki iletişim mesajı için minimum mesaj içeriği sınırını belirlemenizi sağlar.<br />Mesaj içeriği sınırını devre dışı bırakmak için sıfır, <strong>(0)</strong> değeri giriniz.";
$l['setting_contact_maxmessagelength'] = "Maksimum İletişim Mesajı Uzunluğu?";
$l['setting_contact_maxmessagelength_desc'] = "Bu ayar, iletişim formu sayfasındaki iletişim mesajı için maksimum izin verilen mesaj içeriğinin karakter uzunluğunu belirlemenizi sağlar.<br />Mesaj içeriğinin karakter uzunluğu sınırını devre dışı bırakmak, (sınırsız yapmak) için sıfır, <strong>(0)</strong> değeri giriniz.";
// Ayar Grubu 26: "Purge Spammer"
$l['setting_group_purgespammer'] = "Spam Temizleme İşlemi Ayarları";
$l['setting_group_purgespammer_desc'] = "Bu ayar grubu, forumda spam tehditi oluşturan kullanıcı veya kullanıcılara yapılacak spam işlemlerini ve spam aracını kullanbilecek grupları belirlemenize olanak sağlar.";
// 26 Nolu Ayar Grubu Seçenekleri
$l['setting_purgespammergroups'] = "Spam İşlemi Aracını Kullanacak Gruplar?";
$l['setting_purgespammergroups_desc'] = "Bu kısımdan, seçiminiz dışında olan gruplardan herhangi bir grubun kullanıcısının, kullanıcı profilinde, konu ve yorumlarında yer alan ''spam işlemi uygula'' aracını/butonunu kullanabilecek, kullanıcı gruplarını seçiniz.";
$l['setting_purgespammerpostlimit'] = "Spam Takibi için Toplam Mesaj Sınırı?";
$l['setting_purgespammerpostlimit_desc'] = "Bu ayar, aşağıdaki beliryeceğiniz ya da belirlenen toplam mesaj sınırı ile forumdaki aktif kullanıcı ve spam için foruma gelen kullanıcıları ayırd etmek için kullanışlıdır.<br />Belirlenen toplam mesaj limitine bağlı olarak spam aracı, kullanıcıların aktif mi yoksa spam amaçlı mı olup olmadığını algılayıp, eğer toplam mesaj sınırı eşiğini geçtiği halde spam işlemi uygulanmamış ise, spamcı durumundan kurtulup aktif kullanıcı durumuna geçerek, spam takibinden de çıkmış olacaktır.<br />Bu sayede, kullanıcının profilinden, konu ve yorumlarındaki ''spam işlemi uygula'' aracı/butonuda otomatik olarak kalkmış olacaktır.<br />Bu ayarın, sıfır <strong>(0)</strong> olarak limitlendirilmesi devre dışı kalmasını sağlar ancak, devre dışı bırakırsanız forumu spam tehditi durumuna düşürmüz olursunuz.";
$l['setting_purgespammerbandelete'] = "Spam Kullanıcı-(lar) Yasaklansın Mı? / Silinsin Mi?";
$l['setting_purgespammerbandelete_desc'] = "Bu ayar, spam tehditi oluşturup spam işlemi uygulanacak kullanıcıları, süresiz yasaklamanıza ve/veya forum hesabının sistemden tamamen silinmesine olanak saklar.";
$l['setting_purgespammerbandelete_ban'] = "Yasakla (Süresiz)";
$l['setting_purgespammerbandelete_delete'] = "Sil (Full)";
$l['setting_purgespammerbangroup'] = "Yasaklı Kullanıcı Grubu ID No?";
$l['setting_purgespammerbangroup_desc'] = "Bu kısımda, eğer üsteki seçeneklerden ''Yasakla'' seçeneği seçilmiş ise, aşağıdaki metin kutusuna yasaklanan kullanıcıların aktarılacağı ''Yasaklı Kullanıcı Grubu''nun kimliğini, (ID numarasını) giriniz.<br />Varsayılan yasaklı kullanıcı grubu id'si 7'dir. Dilerseniz spam işlemi uygulanacak kullanıcılar için özel bir grup açıp, o grubun ID numarasınıda girebilirsiniz.";
$l['setting_purgespammerbanreason'] = "Yasak Sebebi?";
$l['setting_purgespammerbanreason_desc'] = "Bu kısımdan, yasaklanacak Kullanıcılara görünen yasak sebebeni belirleyebilirsiniz.";
$l['setting_purgespammerapikey'] = "Stop Forum Spam API Key";
$l['setting_purgespammerapikey_desc'] = "Forumun veritabanından spam kullanıcılar hakkında bilgi gönderilmesi için API Anahtarınızın olması gerekir.<br />Eğer, API anhtarınız yoksa <a href=\"http://stopforumspam.com/signup\" target=\"_blank\">Buradan</a> <img src=\"../images/icons/external_link.png\" alt=\"\" width=\"9\" height=\"9\" /> temin edebilirsiniz. Eğer, API anahtarınız varsa aşağıdaki metin kutusuna yapıştırın.";
// Ayar Grubu 27: "Stop Forum Spam"
$l['setting_group_stopforumspam'] = "Stop Forum Spam Ayarları";
$l['setting_group_stopforumspam_desc'] = "Bu ayar grubu, StopForumSpam.Com ile entegrasyon için kullanılan çeşitli ayarları yönetmenize olanak sağlar.";
// 27 Nolu Ayar Grubu Seçenekleri
$l['setting_enablestopforumspam_on_register'] = "StopForumSpam.Com Kayıtları Kontrol Etsin Mi?";
$l['setting_enablestopforumspam_on_register_desc'] = "Bu ayar, StopForumSpam.Com tarafından forumunuzdaki tüm yeni kayıtların kontrol edilmesini sağlar.";
$l['setting_stopforumspam_on_contact'] = "StopForumSpam İletişim için Ziyaretçi Gönderilerini Kontrol Etsin Mi?";
$l['setting_stopforumspam_on_contact_desc'] = "Bu ayar, eğer iletişim sayfasının kullanım izinleri ziyaretçilere açık ise, iletişim formu kullanılırken, ziyaretçinin ''E-Posta'' ve ''IP'' adresinin StopForumSpam tarafından kontrol edilmesini sağlar.";
$l['setting_stopforumspam_on_newreply'] = "StopForumSpam Ziyaretçi Yorumlarını Kontrol Etsin Mi?";
$l['setting_stopforumspam_on_newreply_desc'] = "Bu ayar, eğer yorum yazma izinleri Ziyaretçilere açık ise, ''yeni yorum'' yazarken, ziyaretçinin kullanacağı ''kullanıcı adı'' ve ''IP'' adresinin StopForumSpam tarafından kontrol edilmesini sağlar.";
$l['setting_stopforumspam_on_newthread'] = "StopForumSpam Ziyaretçi Konularını Kontrol Etsin Mi?";
$l['setting_stopforumspam_on_newthread_desc'] = "Bu ayar, eğer yeni konu açma izinleri Ziyaretçilere açık ise, ''yeni konu'' açarken, ziyaretçinin kullanacağı ''kullanıcı adı'' ve ''IP'' adresinin StopForumSpam tarafından kontrol edilmesini sağlar.";
$l['setting_stopforumspam_min_weighting_before_spam'] = "Minimum Stop Forum Spam Kullanıcı Kontrol Seviyesi?";
$l['setting_stopforumspam_min_weighting_before_spam_desc'] = "Bu kısımdan, bir kullanıcı veya bir ziyaretçinin spam olup olmadığına, StopForumSpam tarafından karar verilmesi için minimum güven/kontrol seviyesini 0 ila 100 arasında belirleyebilirsiniz.";
$l['setting_stopforumspam_check_usernames'] = "Kullanıcı Adları Kontrol Edilsin Mi?";
$l['setting_stopforumspam_check_usernames_desc'] = "Bu ayar, Kullanıcı veya ziyaretçi adlarının StopForumSpam veritabanındaki, spam bilgileri ile karşılaştırılıp kontrol edilmesini sağlar.";
$l['setting_stopforumspam_check_emails'] = "E-Posta Adresleri Edilsin Mi?";
$l['setting_stopforumspam_check_emails_desc'] = "Bu ayar, Kullanıcı veya ziyaretçilerin E-Posta adreslerinin StopForumSpam veritabanındaki, spam bilgileri ile karşılaştırılıp kontrol edilmesini sağlar.";
$l['setting_stopforumspam_check_ips'] = "IP Adresleri Edilsin Mi?";
$l['setting_stopforumspam_check_ips_desc'] = "Bu ayar, Kullanıcı veya ziyaretçilerin IP adreslerinin StopForumSpam veritabanındaki, spam bilgileri ile karşılaştırılıp kontrol edilmesini sağlar.";
$l['setting_stopforumspam_block_on_error'] = "StopForumSpam Hata ile Kaşılaşırsa Blok İşlemi Uygulasın Mı?";
$l['setting_stopforumspam_block_on_error_desc'] = "StopForumSpam tarafından API bilgisi alınırken bir hata varsa ya da bir hata ile karşılaşılırsa, kullanıcı-(lar) ''Bloke'' edilsin mi?";
$l['setting_stopforumspam_log_blocks'] = "StopForumSpam Blok Kayıtları Tutsun Mu?";
$l['setting_stopforumspam_log_blocks_desc'] = "StopForumSpam tarafından her ''Bloke'' edilen kullanıcı için kayıt tutulsun mu?";
// Ayar Grubu 28: "Contact Details"
$l['setting_group_contactdetails'] = "Kullanıcı Grupları Ek İletişim Bilgisi Ayarları";
$l['setting_group_contactdetails_desc'] = "Bu ayar grubu, tüm kullanıcı gruplarının profil bilgilerindeki özel/ek iletişim bilgileri seçeneklerinin çeşitli izinlerini yönetmenize olanak sağlar.";
// 28 Nolu Ayar Grubu Seçenekleri
$l['setting_allowicqfield'] = "ICQ Numarası için İzin Verilen Gruplar?";
$l['setting_allowicqfield_desc'] = "Bu kısımdan, profil bilgileri düzenlemede, ''ICQ Numarası'' alanının kullanımına izin vermek istediğiniz kullanıcı gruplarını seçiniz.";
$l['setting_allowaimfield'] = "AIM Ekran Adı için İzin Verilen Gruplar?";
$l['setting_allowaimfield_desc'] = "Bu kısımdan, profil bilgileri düzenlemede, ''AIM Ekran Adı'' alanının kullanımına izin vermek istediğiniz kullanıcı gruplarını seçiniz.";
$l['setting_allowyahoofield'] = "Yahoo ID için İzin Verilen Gruplar?";
$l['setting_allowyahoofield_desc'] = "Bu kısımdan, profil bilgileri düzenlemede, ''Yahoo ID'' alanının kullanımına izin vermek istediğiniz kullanıcı gruplarını seçiniz.";
$l['setting_allowskypefield'] = "Skype ID için İzin Verilen Gruplar?";
$l['setting_allowskypefield_desc'] = "Bu kısımdan, profil bilgileri düzenlemede, ''Skype ID'' alanının kullanımına izin vermek istediğiniz kullanıcı gruplarını seçiniz.";
$l['setting_allowgooglefield'] = "Google Talk ID için İzin Verilen Gruplar?";
$l['setting_allowgooglefield_desc'] = "Bu kısımdan, profil bilgileri düzenlemede, ''Google Talk ID'' alanının kullanımına izin vermek istediğiniz kullanıcı gruplarını seçiniz.";
// Ayar Grubu 29: "Statistics Page"
$l['setting_group_statspage'] = "Forum İstatistik Sayfası Ayarları";
$l['setting_group_statspage_desc'] = "Bu ayar grubu, forum istatistikleri sayfası, [stats.php] için çeşitli ayarları yönetmenize olanak sağlar.";
// 29 Nolu Ayar Grubu Seçenekleri
$l['setting_statsenabled'] = "Forum İstatistikleri Sayfası Aktif Edilsin Mi?";
$l['setting_statsenabled_desc'] = "Bu kısımdan, forum istatistikleri sayfasını kullanıma/erişime tamamen kapatabilir yada açabilirsiniz.";
$l['setting_statscachetime'] = "İstatistikler Sayfasının Önbelleğinin Yenilenme Süresi?";
$l['setting_statscachetime_desc'] = "Bu ayar, forum istatistikleri sayfasının önbelleğinin yenilenme süresini, (zaman aralığını) saat biriminden ayarlamanızı sağlar.<br />Önbelleğe almayı devre dışı bırakmak için sıfır, <strong>(0)</strong> değeri giriniz.";
$l['setting_group_forumteam'] = "Forum Yönetim Ekibi Ayarları";
$l['setting_group_forumteam_desc'] ="Bu bölüm üye listesi sayfasında bulunan forum yöneticileri (showteam.php) kısmının aktif olup olmayacağını ve çeşitli diğer ayarların yapılandırmanızı sağlar.";
$l['setting_enableshowteam'] = "Forum Yöneticileri Sayfası Etkinleştirilsin mi?";
$l['setting_enableshowteam_desc'] = "Forumunuzda yönetici ekibinin listesinin görüntülenmesini istemiyorsanız bu ayarı <strong>Hayır</strong> olarak seçiniz.";
$l['setting_showaddlgroups'] ="Ek Grupları Göster";
$l['setting_showaddlgroups_desc'] ="Forum yönetici ekip listesinin ek gruplarının gösterilip, gösterilmeyeceğini buradan ayarlabilirsiniz.";
$l['setting_showgroupleaders'] ="Grup Liderlerini Göster";
$l['setting_showgroupleaders_desc'] ="Forum yöneticileri listesinde, grup liderlerini göstermek istiyorsanız bu ayarı Evet olarak seçiniz.";
