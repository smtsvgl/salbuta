<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8 Türkçe Dil Dosyası Paketi
 * Türkçe Çeviri: Machine (Hüseyin KÖRBALTA)
 * Website: http://mybb.com.tr - http://mybbdepo.com
 * Kişisel blog: https://huseyinkorbalta.com
 * Son Güncelleme: 14.06.2019 - Saat: 19:19
 */

$l['forum_management'] = "Forumları Yönet";
$l['forum_management_desc'] = "Bu Kısım, Kategori, Forum ve Alt forumları yönetmenize olanak sağlar. Oluşturmuş olduğunuz her forum ve alt forumlar için forum izinlerini ve forum yöneticilerinide yönetebilirsiniz. Ayrıca her kategori, forum ve alt forumların görüntülenme sıralarınıda yine bu kısım üzerinden yönetebilirsiniz.";
$l['add_forum'] = "Yeni Forum Ekle";
$l['add_forum_desc'] = "Bu kısımdan, yeni bir kategori, forum ve alt forum oluşturabilirsiniz. Ayrıca oluşturmuş olduğunuz kategori veya forumların izinlerinide bu kısımdan yönetebilirsiniz.";
$l['copy_forum'] = "Forumu Kopyala";
$l['copy_forum_desc'] = "Bu Kısımdan, daha önce oluşturmuş olduğunuz foruma veya yeni oluşturmak istediğiniz foruma seçmiş olduğunuz forumun ayarları ve izinlerinin bir kopyasını aktarabilirsiniz.";
$l['forum_permissions'] = "Forum İzinleri";
$l['forum_permissions_desc'] = "Bu kısımdan, Kullanıcı veya belirlemiş olduğunuz özel gruplar için forum izinlerini yönetebilirsiniz.";
$l['view_forum'] = "Forumu Görüntüle";
$l['view_forum_desc'] = "Bu kısımdan, görüntülemekte olduğunuz foruma ait, alt forumları görüntüleyebilir, hızlı bir şekilde forum izinlerilerini ve forum yönetecilerini ekleyebilir ve yönetebilirsiniz.";
$l['add_child_forum'] = "Alt Forum Ekle";
$l['edit_forum_settings'] = "Forum Ayarlarını Düzenle";
$l['edit_forum_settings_desc'] = "Bu kısımdan, seçmiş olduğunuz forumun, forum ayarlarını ve izinlerini yönetebilirsiniz.";
$l['edit_forum'] = "Forumu Düzenle";
$l['edit_mod'] = "Moderatör Düzenle";
$l['edit_mod_desc'] = "Bu kısımdan, seçmiş olduğunuz moderatörün ayarları ve izinlerini yönetebilirsiniz.";
$l['forum_moderators'] = "Forum Moderatörleri";
$l['forum_permissions2'] = "Forum İzinleri";
$l['more_subforums'] = "{1} Alt forum daha Var.";

$l['manage_forums'] = "Kategoriler & Forumları Yönet";
$l['forum'] = "Forum";
$l['order'] = "Sıralama";

$l['subforums'] = "Alt Forumlar";
$l['moderators'] = "Moderatörler";
$l['permissions'] = "Forum İzinleri";
$l['delete_forum'] = "Forumu Sil";

$l['sub_forums'] = "Alt Forumlar";
$l['update_forum_orders'] = "Forum Sıralamasını Kaydet/Güncelle";
$l['update_forum_permissions'] = "Forum İzinlerini Kaydet";
$l['reset'] = "Yenile";
$l['in_forums'] = "\"{1}\" Bölümüne Ait Forumlar";
$l['forum_permissions_in'] = "\"{1}\" Bölümüne Ait Forum İzinleri";
$l['moderators_assigned_to'] = "\"{1}\" Bölümüne Atanan Moderatörler";
$l['edit_permissions'] = "İzinleri Düzenle";
$l['set_permissions'] = "İzin Ayaları";
$l['using_custom_perms'] = "Kullanılan Özel İzinler";
$l['using_default_perms'] = "Varsayılan Özel İzinler";
$l['clear_custom_perms'] = "Özel İzinleri İptal Et";
$l['set_custom_perms'] = "Özel İzin Ayarları";

$l['permissions_use_group_default'] = "Varsayılan Grup İzinleri Kullanılsın Mı?";
$l['permissions_group'] = "Kullanıcı Grupları";
$l['permissions_canview'] = "Görüntüleyebilir Mi?";
$l['permissions_canpostthreads'] = "Konu Açabilir Mi?";
$l['permissions_canpostreplys'] = "Yorum Yazabilir Mi?";
$l['permissions_canpostpolls'] = "Anket Açabilir Mi?";
$l['permissions_canuploadattachments'] = "Ek Dosya Yükleyebilir Mi?";
$l['permissions_all'] = "Tüm İzinleri Kullanabilir Mi?";

$l['overview_allowed_actions'] = "Serbest Bırakılan Forum İzinler";
$l['overview_disallowed_actions'] = "Engellenen Forum İzinleri";
$l['perm_drag_canview'] = "<img src=\"../images/admincp/vurgu.gif\" style=\"vertical-align: middle;\" alt=\"\" border=\"0\"> Forumu Gönrüntüleyebilir?";
$l['perm_drag_canpostthreads'] = "<img src=\"../images/admincp/vurgu.gif\" style=\"vertical-align: middle;\" alt=\"\" border=\"0\"> Konu Açabilir?";
$l['perm_drag_canpostreplys'] = "<img src=\"../images/admincp/vurgu.gif\" style=\"vertical-align: middle;\" alt=\"\" border=\"0\"> Yorum Yazabilir?";
$l['perm_drag_canpostpolls'] = "<img src=\"../images/admincp/vurgu.gif\" style=\"vertical-align: middle;\" alt=\"\" border=\"0\"> Anket Ekleyebilir?";

$l['moderator_permissions'] = "Moderatör İzinleri";
$l['forum_desc'] = "Moderatörün Sorumlu Olduğu Forumlar.";
$l['edit_mod_for'] = "\"{1}\" Nickli kullanıcının moderatör izinlerini düzenle";
$l['can_edit_posts'] = "Yorumları Düzenleyebilir Mi?";
$l['can_soft_delete_posts'] = "Yorumları Gizleyebilir/Geçici Silebilir Mi?";
$l['can_restore_posts'] = "Yorumları Onarabilir/Geri Getirebilir Mi?";
$l['can_delete_posts'] = "Yorumları Silebilir Mi?";
$l['can_soft_delete_threads'] = "Konuları Gizleyebilir/Geçici Silebilir Mi?";
$l['can_restore_threads'] = "Konuları Onarabilir/Geri Getirebilir Mi?";
$l['can_delete_threads'] = "Konuları Silebilir Mi?";
$l['can_view_ips'] = "IP Adreslerini Görüntüleyebilir Mi?";
$l['can_view_unapprove'] = "Onaysız Konu & Yorum İçeriklerini Görebilir Mi?";
$l['can_view_deleted'] = "Silinen Konu & Yorumları Görebilir Mi?";
$l['can_open_close_threads'] = "Konuları Açabilir/Kapatabilir Mi?";
$l['can_stick_unstick_threads'] = "Konuları Üstte Tutturabilir/Üstten Kaldırabilir Mi?";
$l['can_approve_unapprove_threads'] = "Konuları Onaylabilir/Onayları Kaldırabilir Mi?";
$l['can_approve_unapprove_posts'] = "Yorumları Onaylabilir/Onayları Kaldırabilir Mi?";
$l['can_approve_unapprove_attachments'] = "Ekli Dosyaları Onaylabilir/Onayları Kaldırabilir Mi?";
$l['can_manage_threads'] = "Konu & Yorumların [Taşıma, Kopyalama, Ayrıştırma ve Birleştirme] İşlemlerini Yönetebilir Mi?";
$l['can_manage_polls'] = "Anketleri Yönetebilir Mi?";
$l['can_post_closed_threads'] = "Kapalı Konulara Yorum Gönderebilir/Yazabilir Mi?";
$l['can_move_to_other_forums'] = "Sorumlu Olmadığı, Başka Bir Foruma Konu Taşıyabilir Mi?";
$l['can_use_custom_tools'] = "Özel Moderatör Araçlarını Kullanabilir Mi?";
$l['can_manage_announcements'] = "Forum Duyurularını Yönetebilir Mi?";
$l['can_manage_reported_posts'] = "Bu Forum için Rapor Edilen Mesaj Bildirimlerini Yönetebilir Mi?";
$l['can_view_mod_log'] = "Bu Forumun Moderatör Kayıtlarını Görüntüleyebilir Mi?";
$l['moderator_cp_permissions'] = "Moderatör KP İzinleri";
$l['moderator_cp_permissions_desc'] = "Bu kullanıcının Mod KP'ye erişebilmesi ve izinlerinin etkili olabilmesi için kullanıcı grubu iznine sahip olması gerekir. Ek kullanıcı grubu atayabilir ya da direkt bağlı olduğu grup izinlerini ayarlayabilirsiniz.";

$l['save_mod'] = "Moderatör İzinlerini Kaydet";

$l['no_forums'] = "Herhangi bir Forum bulunumadı.";
$l['no_moderators'] = "Herhangi bir Moderatör bulunumadı.";

$l['success_forum_disporder_updated'] = "Forum görüntüleme sıralaması başarılı olarak güncellendi.";
$l['success_forum_deleted'] = "Seçilen forum başarıyla silindi. İdeal olarak; <a href=\"/index.php?module=tools-recount_rebuild\">Sayım & Yapılandırma</a> araçlarını çalıştırmanız tavsiye edilir.";
$l['success_moderator_deleted'] = "Belirtmiş olduğunuz moderatör başarılı olarak silindi.<br />Ancak, kullanıcı grup izinleri değişmediği için hala maderasyon yetkilerine sahip olabileceğini unutmayın.";
$l['success_forum_permissions_updated'] = "Forum izinleri başarılı olarak güncellendi.";
$l['success_forum_updated'] = "Ayarlar başarılı olarak güncellendi.";
$l['success_moderator_updated'] = "İzinler başarılı olarak güncellendi.";
$l['success_custom_permission_cleared'] = "Belirtmiş olduğunuz forumun özel izinleri başarılı olarak iptal edildi.";

$l['error_invalid_forum'] = "Lütfen geçerli bir forum seçiniz.";
$l['error_invalid_moderator'] = "Lütfen silmek için geçerli bir moderatör seçiniz.";
$l['error_invalid_fid'] = "Seçmiş olduğunuz forum ID'sı geçersizdir.";
$l['error_forum_parent_child'] = "Bu foruma ait alt forumu, ana forum olarak ayarlayamazsınız.";
$l['error_forum_parent_itself'] = "Bu forum bir kategoriye bağlıdır ve ana forum olarak ayarlanamaz.";
$l['error_incorrect_moderator'] = "Lütfen geçerli bir moderatör seçiniz.";

$l['confirm_moderator_deletion'] = "Seçmiş olduğunuz moderatörü bu forumdan silmek istediğinize emin misiniz?";
$l['confirm_forum_deletion'] = "Bu forumu silmek istediğinizden emin misiniz?";
$l['confirm_clear_custom_permission'] = "Daha önce ayarlamış olduğunuz özel izinleri iptal edip, varsayılan izinlerin kullanılmasını istediğinizden emin misiniz?";

$l['forum_type'] = "Forum Türünü Seçiniz";
$l['forum_type_desc'] = "Bu kısımdan, yeni bir forum veya forum ve alt forumları içeren bir ana kategori oluşturabilirsiniz.";
$l['category'] = "Kategori";
$l['title'] = "Başlık";
$l['description'] = "Forum Açıklaması";
$l['save_forum'] = "Forumu kaydet";
$l['parent_forum'] = "Ana Forum";
$l['parent_forum_desc'] = "Oluşturmak istediğiniz forum eğer bir kategori içeren forum değilse, aşağıdaki açılır seçenek sekmesinden <strong>Hiçbiri</strong> seçeneğini seçiniz.<br /> Ana forum seçimi sadece kategori altındaki forum ve alt forumlar için belirtilebilir.";
$l['none'] = "Hiçbiri";
$l['display_order'] = "Listeleme Sırası";

$l['show_additional_options'] = "Ek Forum Seçeneklerini Göster";
$l['hide_additional_options'] = "Ek Forum Seçeneklerini Gizle";
$l['additional_forum_options'] = "Ek Forum Seçenekleri";
$l['forum_link'] = "Forum Bağlantısı:";
$l['forum_link_desc'] = "Bu kısımda, bu forum için bir URL adresi girebilirsiniz. Dilerseniz bu forumu başka bir foruma veya adrese yönlendirebilirsiniz. Ayrıca forum için geçerli olan forum izinlerinide ayarlayabilirsiniz.<br /><strong>Not:</strong> Eğer bu forumda konular varsa, yönlendirme işlemi gerçekleşmez. Önce forumdaki konuları başka bir foruma taşıyıp sonra yönlendirme işlemini yapınız.";
$l['forum_password'] = "Forum Şifresi:";
$l['forum_password_desc'] = "Bu kısımda, bu forum için bir şifre oluşturabilir ve istemediğiniz kullanıcıların bu foruma girişlerini şifreleme yöntemi ile engelleyebilirsiniz.<br /><strong>Not:</strong> Foruma şifre uyguladığınız zaman giriş yapabilmeleri için belirlediğiniz kullanıcı veya yöneticilere forum şifresini vermeyi unutmayınız.";
$l['access_options'] = "Erişim & Kullanım Seçenekleri:";
$l['forum_is_active'] = "Forum Gösterime Kapatılsın mı?";
$l['forum_is_active_desc'] = "Bu forumu tamamen, ''erişim ve gösterime kapatmak istiyorsanız'' eğer, sol üstteki kutucuğun <strong>''tik''</strong> işaretini kaldırın.";
$l['forum_is_open'] = "Forum Kullanıma Kapatılsın mı?";
$l['forum_is_open_desc'] = "Bu forumu sadece, ''yeni konu'' ve ''yeni yorum'' gönderimlerine ''kapatmak istiyorsanız'' eğer, sol üstteki kutucuğun <strong>''tik''</strong> işaretini kaldırın.";
$l['copy_to_new_forum'] = "Yeni Foruma Kopyala";
$l['source_forum'] = "Kaynak Forum";
$l['source_forum_desc'] = "Forum ayarlarının ve/veya izinlerinin kopyalanmasını istediğiniz forumu seçiniz.";
$l['destination_forum'] = "Hedef Forum";
$l['destination_forum_desc'] = "Forum ayarlarının ve/veya izinlerinin kopyalanacağı forumu seçiniz.";
$l['new_forum_settings'] = "Yeni Forum Ayarları";
$l['copy_settings_and_properties'] = "Forum ayarları ve özellikleri kopyalansın mı?";
$l['copy_settings_and_properties_desc'] = "Eğer belirtmiş olduğunuz <strong>Hedef Forum</strong> sisteminizde varsa uygulanır.";
$l['copy_user_group_permissions'] = "Kullanıcı grup izinleri kopyalansın mı?";
$l['copy_user_group_permissions_desc'] = "Kopyalamak istediğiniz forumun, kullanıcı grup ayarlarını bu foruma uygulamak istiyor musunuz?<br />Çoklu kullanıcı grubu seçimi için <strong>CTRL</strong> tuşunu kullanınız.";
$l['override_user_style'] = "Kullanıcıların seçmiş oldukları forum temasını geçersiz kıl?";
$l['style_options'] = "Forum Stili & Tema Seçenekleri:";
$l['forum_specific_style'] = "Bu foruma özgü tema stilini seçiniz:";
$l['use_default'] = "Varsayılan Tema Kullanılsın";
$l['dont_display_rules'] = "Forum kurallarını gizle?";
$l['display_rules_inline'] = "Forum kurallarını göster?";
$l['display_rules_inline_new'] = "Konu listeleme, yeni konu ve yeni cevap yazarken forum kuralları gösterilsin mi?";
$l['display_rules_link'] = "Forum kurallarını bağlantı olarak göster?";
$l['display_method'] = "Gösterim Seçenekleri:";
$l['rules'] = "Aşağıdaki metin kutusuna ''Forum Kuralları'' içeriğini giriniz:";
$l['forum_rules'] = "Forum Kuralları:";
$l['name'] = "Moderatörler";
$l['username'] = "Kullanıcı Adı";
$l['moderator_username_desc'] = "Moderatör/yönetici olarak, bu foruma eklemek istediğiniz kullanıcının adını giriniz.";
$l['add_user_as_moderator'] = "Moderatör olarak bir kullanıcı ekle";
$l['usergroup'] = "Kullanıcı Grubu Adı";
$l['add_usergroup_as_moderator'] = "Moderatör olarak bir kullanıcı grubu ekle";
$l['moderator_usergroup_desc'] = "Aşağıdaki seçenekler sekmesinden, moderatör/yönetici olarak, bu foruma eklemek istediğiniz kullanıcı grubunu seçiniz.";
$l['add_usergroup_moderator'] = "Bu Grubu Moderatör Olarak ekle";
$l['add_user_moderator'] = "Bu Kullanıcıyı Moderatör Olarak Ekle";

$l['default_view_options'] = "Varsayılan Gösterim Seçenekleri:";
$l['default_date_cut'] = "Tarihe Göre Listeleme:";
$l['default_sort_by'] = "Varsayılan Listeleme:";
$l['default_sort_order'] = "Gösterime göre Listeleme:";

$l['board_default'] = "Varsayılan Forum Ayarları";

$l['datelimit_1day'] = "Son Konular";
$l['datelimit_5days'] = "5 Günlük Konular";
$l['datelimit_10days'] = "10 Günlük Konular";
$l['datelimit_20days'] = "20 Günlük Konular";
$l['datelimit_50days'] = "50 Günlük Konular";
$l['datelimit_75days'] = "75 Günlük Konular";
$l['datelimit_100days'] = "100 Günlük Konular";
$l['datelimit_lastyear'] = "1 Yıllık Günlük Konular";
$l['datelimit_beginning'] = "Tüm Konuları Göster";

$l['sort_by_subject'] = "Konu Başlığına Göre";
$l['sort_by_lastpost'] = "Son Yoruma Göre";
$l['sort_by_starter'] = "Konuyu Başlatana Göre";
$l['sort_by_started'] = "Konu Açılış Tarihine Göre";
$l['sort_by_rating'] = "Oylamaya Göre";
$l['sort_by_replies'] = "Yorum Sayısına Göre";
$l['sort_by_views'] = "Okunma Sayısına Göre";

$l['sort_order_asc'] = "Artan";
$l['sort_order_desc'] = "Azalan";

$l['misc_options'] = "MyKod Etiketleri & Çeşitli İzin Seçenekleri:";
$l['allow_html'] = "Konu & Yorumlarda <strong>[HTML]</strong> Kod Kullanımına İzin Verilsin Mi?";
$l['allow_mycode'] = "Konu & Yorumlarda <strong>[MyKod]</strong> Etiketleri Kullanımına İzin Verilsin Mi?";
$l['allow_smilies'] = "Konu & Yorumlarda <strong>(İfade)</strong> Kullanımına İzin Verilsin Mi?";
$l['allow_img_code'] = "Konu & Yorumlarda <strong>[İMG]</strong> Etiketi Kullanımına İzin Verilsin Mi?";
$l['allow_video_code'] = "Konu & Yorumlarda <strong>[Video]</strong> Etiketi Kullanımına İzin Verilsin Mi?";
$l['allow_post_icons'] = "Konu & Yorumlarda <strong>(Başlık Sembolleri)</strong> Kullanımına İzin Verilsin Mi?";
$l['allow_thread_ratings'] = "Konularda <strong>(Oy)</strong> Kullanımına İzin Verilsin Mi?";
$l['show_forum_jump'] = "Forum Atlama, <strong>[Hızlı Menü]</strong> Aracı Gösterilsin Mi?";
$l['use_postcounts'] = "Bu Foruma Yazılan Yorumlar, Kullanıcıların Yorum Sayılarına İşlensin Mi? (Seçilmez ise, bu forumdaki yorum sayıları forum sayacına yansır/işler ancak, kullanıcıların yorum sayılarına yansımaz/işlemez).";
$l['use_threadcounts'] = "Bu Foruma Açılan Konular, Kullanıcıların Konu Sayılarına İşlensin Mi? (Seçilmez ise, bu forumdaki konu sayıları forum sayacına yansır/işler ancak, kullanıcıların konu sayılarına yansımaz/işlemez).";
$l['require_thread_prefix'] = "Bu Forumda Açılan Tüm Konular için ''Konu Ön Eki'' (varsa) Kullanımı Zorunlu Olsun Mu?";

$l['use_permissions'] = "Kullanılacak İzinler";
$l['use_permissions_desc'] = "Bu kullanıcı grubu için kullanılmasını istediğiniz özel izinleri seçiniz.";
$l['inherit_permissions'] = "Kullanıcı grubu izinleri yada ana forumda ayarlanmış izinleri kullan.";
$l['custom_permissions'] = "Aşağıdaki özel izinleri kullanın";
$l['custom_permissions_for'] = "için Özel izinler, Forum:";

$l['inherited_permission'] = "Standart";
$l['custom_permission'] = "Özel";

$l['save_permissions'] = "Forum İzinlerini Kaydet";

$l['error_missing_title'] = "Bir başlık girmeniz gerekiyor.";
$l['error_no_parent'] = "Bir ana forum seçmeniz gerekiyor.";
$l['error_not_empty'] = "Bu forumda Konular varken, forum kategorisi türüne dönüştürülemez.";
$l['error_forum_link_not_empty'] = "Bu forumda konular varken, başka bir foruma ya da web sayfasına yönlendiremezsiniz.";

$l['success_forum_added'] = "Forum başarılı olarak oluşturuldu.";
$l['success_moderator_added'] = "Belirtmiş olduğunuz moderatör, foruma başarılı olarak eklendi.";
$l['success_forum_permissions_saved'] = "Belirmiş olduğunuz forum izinleri başarılı olarak kaydedildi.";
$l['success_forum_copied'] = "Seçmiş olduğunuz forum başarılı olarak kopyalandı.";

$l['error_moderator_already_added'] = "Belirtmiş olduğunuz moderatör zaten o forumun sorumlusu.";
$l['error_moderator_not_found'] = "Belirtilen kullanıcı adı yada kullanıcı grubu bulunamadı";
$l['error_new_forum_needs_name'] = "Yeni forumunuz için bir isim girmeniz gerekiyor.";
$l['error_invalid_source_forum'] = "Belirtmiş olduğunuz kaynak forum geçersizdir.";
$l['error_invalid_destination_forum'] = "Belirtmiş olduğunuz hedef forum geçersizdir.";

$l['group_viewing'] = "Görüntüleme";
$l['group_posting_rating'] = "Konu/Oylama";
$l['group_editing'] = "Düzenleme";
$l['group_moderate'] = "Moderasyon";
$l['group_polls'] = "Anket";
$l['group_misc'] = "Diğer İzinler";

$l['viewing_field_canview'] = "Forumları görüntüleyebilir?";
$l['viewing_field_canviewthreads'] = "Forumdaki Konuları Görüntüleyebilir?";
$l['viewing_field_canonlyviewownthreads'] = "Sadece Kendi Konularını Görüntüleyebilir?";
$l['viewing_field_candlattachments'] = "Ekli Dosyaları İndirebilir?";

$l['posting_rating_field_canpostthreads'] = "Yeni Konu Açabilir?";
$l['posting_rating_field_canpostreplys'] = "Konulara Yorum Yazabilir?";
$l['posting_rating_field_canonlyreplyownthreads'] = "Sadece Kendi Konularına Cevap Yazabilir?";
$l['posting_rating_field_canpostattachments'] = "Ek Dosya Yükleyebilir?";
$l['posting_rating_field_canratethreads'] = "Konulara Oy Kullanabilir?";

$l['editing_field_caneditposts'] = "Kendi Yorumlarını Düzenleyebilir?";
$l['editing_field_candeleteposts'] = "Kendi Yorumlarını Silebilir?";
$l['editing_field_candeletethreads'] = "Kendi Konularını Silebilir?";
$l['editing_field_caneditattachments'] = "Kendi Ek Dosyalarını Düzenleyebilir?";
$l['editing_field_canviewdeletionnotice'] = "Silme İşlemi Bildirimlerini Görüntüleyebilir?";

$l['moderate_field_modposts'] = "Yeni Yorumlar Moderasyon İşlemi Gerektirsin?";
$l['moderate_field_modthreads'] = "Yeni Konular Moderasyon İşlemi Gerektirsin?";
$l['moderate_field_modattachments'] = "Yeni Ek Dosyalar Moderasyon İşlemi Gerektirsin?";
$l['moderate_field_mod_edit_posts'] = "Yorum Düzenlemeleri Moderasyon İşlemi Gerektirsin?";

$l['polls_field_canpostpolls'] = "Anket Ekleyebilir?";
$l['polls_field_canvotepolls'] = "Anketlere Oy Kullanabilir?";

$l['misc_field_cansearch'] = "Forumda Arama Yapabilir?";

// Yeni eklenen dil satırları [machine]
$l['confirm_proceed_deletion'] = "Forumun silinmesine devam etmek için \"Devam Et\" butonuna tıklayın.";
$l['automatically_redirecting'] = "Otomatik Olarak Yönlendiriliyorsunuz&hellip;";
