<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8 Türkçe Dil Dosyası Paketi
 * Türkçe Çeviri: Machine (Hüseyin KÖRBALTA)
 * Website: http://mybb.com.tr - http://mybbdepo.com
 * Kişisel blog: https://huseyinkorbalta.com
 * Son Güncelleme: 14.06.2019 - Saat: 18:51
 */

$l['attachment_types'] = "Ek Dosya Türleri";
$l['attachment_types_desc'] = "Bu Kısımdan Üyelerinizin Konu & Yorumlarda Eklemesini İstediğiniz Ek Dosya Türlerini Yönetebilirsiniz.";
$l['add_new_attachment_type'] = "Yeni Ek Dosya Türü Ekle";
$l['add_attachment_type'] = "Dosya Türü Ekle";
$l['add_attachment_type_desc'] = "Bu Kısımdan Yeni Bir Ek Dosya Türü Ekleyebilir veya Düzenleme Yapabilirsiniz. Ayrıca Dosya Türlerinize Küçük Resimler (Simge) Ekleyebilirsiniz.";
$l['edit_attachment_type'] = "Dosya Türünü Düzenle";
$l['edit_attachment_type_desc'] = "Dosya Türlerini Eklerken Uzantılarının <b>MIME Türü</b> Olması Gerektiği Gibi  Maksimum Boyutlarınıda Yönetebilirsiniz.";

$l['extension'] = "Dosya Uzantısı";
$l['maximum_size'] = "Maksimum Boyut";
$l['no_attachment_types'] = "Şu anda Forumunuzda Ekli Hiçbir Ek Dosya Türü Bulunamadı.";

$l['name'] = "Dosya Türü Adı";
$l['name_desc'] = "Aşağıdaki Metin Kutusuna MIME Type/Dosya Türünün Adını Giriniz.";
$l['file_extension'] = "Dosya Uzantısı";
$l['file_extension_desc'] = "Eklemek İstediğiniz Dosya Uzantısını Giriniz. (<b>Örnek:</b> txt, php, png) gibi.";
$l['mime_type'] = "MIME Türü";
$l['mime_type_desc'] = "Eklemek İstediğiniz MIME Type/Dosya Türünü Giriniz.<br /><b>Örnek:</b> txt için, text/plain<br />MIME Type Dosya Türleri Hakkında Ayrıntılı Bilgi için: <b><a href=\"http://wiki.mybb.com.tr/mime-type\" title=\"MyBB Wiki - MIME Type Dosya Türleri Hakkında\" target=\"_blank\">MyBB Wiki</a>&nbsp;<img src=\"../images/admincp/external_link.png\" alt=\"\" height=\"9\" width=\"9\"></b> Sayfasını Ziyaret Edebilirsiniz.";
$l['maximum_file_size'] = "Maksimum Dosya Boyutu (kilobyte)";
$l['maximum_file_size_desc'] = "Buradan Eklemek İstediğiniz Dosya Türü için Maksimum Dosya Boyutunu Belirleyebilirsiniz.<br /><b>Örnek:</b> 1 MB = 1024 KB";
$l['limit_intro'] = "<strong>Sunucu Tarafından İzin Verilen Maksimum Yükleme İzinleri:</strong><br /><strong>Not:</strong> Aşağıda barındığınız sunucu tarafından izin verilen yükleme limitlerini görebilirsiniz.<br />Aşağıda ki metin kutusuna bu limitlerden yüksek limit giremezsiniz. Girseniz bile sunucunun izin verdiği kadarı kullanılacaktır.<br />Limitleri artırmak için sunucu (hosting) sağlayıcınızla iletişim kurunuz.";
$l['limit_post_max_size'] = "Maksimum Gönderilebilir Konu Boyutu (post_max_size): <strong>{1}</strong>";
$l['limit_upload_max_filesize'] = "Maksimum Yüklenebilir Dosya Boyutu (upload_max_filesize): <strong>{1}</strong>";
$l['attachment_icon'] = "Dosya Simgesi";
$l['attachment_icon_desc'] = "Dosya Türünüz İçin Küçük Resim (simge) Eklemek İstiyorsanız, Lütfen Resim Yolunu Belirtiniz.<br /><b>Örnek:</b> images/attachtypes/txt.gif veya İmages/icon/txt.gif gibi.";
$l['save_attachment_type'] = "Dosya Türünü Kaydet";

$l['error_invalid_attachment_type'] = "Geçersiz Bir Dosya Uzantısı Girdiniz.";
$l['error_missing_mime_type'] = "Bu Dosya Uzantısı için Mıme Türü Belirtmediniz.";
$l['error_missing_extension'] = "Bu MIME Türü İçin Dosya Uzantısı Belirtmediniz.";

$l['success_attachment_type_created'] = "Dosya Türü Başarılı Olarak Oluşturuldu.";
$l['success_attachment_type_updated'] = "Dosya Türü Başarılı Olarak Güncellendi.";
$l['success_attachment_type_deleted'] = "Dosya Türü Başarılı Olarak Silindi.";

$l['confirm_attachment_type_deletion'] = "Bu Dosya Türünü Silmek İstediğinizden Emin Misiniz?";

$l['success_activated_attachment_type'] = 'Seçilen Dosya Türü Başarıyla Aktif Edildi.';
$l['success_deactivated_attachment_type'] = 'Seçilen Dosya Türü Başarıyla Devre Dışı Bırakıldı.';

$l['enabled'] = "Etkinleştir?";
$l['avatar_file'] = 'Avatar Dosyası';
$l['avatar_file_desc'] = 'Bu Ek Dosya Türünü Avatarlar için Kullanmak İstiyor Musunuz?';

$l['available_to_groups'] = 'İzin Verilen Gruplar';
$l['available_in_forums'] = 'Gösterilecek Forumlar';
