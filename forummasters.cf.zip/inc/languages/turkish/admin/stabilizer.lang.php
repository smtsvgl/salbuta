<?php
/**
 * Author: MD Team
 * Plugin: Premium Theme Language
 * Version: 1.0.2
 * Plugin Language File: turkish
 */

$l['md_plugin_name'] = 'Stabilizer | Premium Tema Eklentisi';
$l['md_plugin_desc'] = 'Stabilizer temasının özelliklerini çalıştıran ve temayı sorunsuz şekilde kullanmanıza olanak sağlayan eklenti.';

$l['md_plugin_settings_name'] = 'Stabilizer Tema Ayarları';
$l['md_plugin_settings_desc'] = 'Stabilizer temasının özelliklerini çalıştıran ve temayı sorunsuz şekilde kullanmanıza olanak sağlayan eklenti.';


$l['md_plugin_goal_title'] = 'Günlük Hedefiniz?';
$l['md_plugin_goal_desc'] = 'Günlük hedef için belirlediğiniz mesaj sayısını girmeniz yeterli.';

$l['md_plugin_trend_title'] = 'Trend Konu Sayısı';
$l['md_plugin_trend_desc'] = 'Sidebar da bulunan trendler eklentisi, kaç adet konu göstersin?';

$l['md_plugin_trendday_title'] = 'Trend Konu Süresi';
$l['md_plugin_trendday_desc'] = 'Gösterilecek konular son kaç gün içerisinde açılmış olsun?';

$l['md_plugin_categoryicon_title'] = 'Sabit Kategori ikonu';
$l['md_plugin_categoryicon_desc'] = 'Kategori başlıklarında bulunan ikonu değiştirmek için istediğiniz font awesome kodunu yazın.';

$l['md_plugin_isidebar_title'] = 'Sidebar';
$l['md_plugin_isidebar_desc'] = 'Sidebar aktif olsun mu?';

$l['md_plugin_isidebarp_title'] = 'Sidebar Pozisyonu';
$l['md_plugin_isidebarp_desc'] = 'Sidebar hangi tarafta olsun istersiniz?';

$l['md_plugin_isidebarf_title'] = 'Sidebar Takip';
$l['md_plugin_isidebarf_desc'] = 'Sidebar, sayfa boyunca ekranı takip etsin mi?';

$l['md_plugin_ficontype_title'] = 'Forum İkonları';
$l['md_plugin_ficontype_desc'] = 'Forum ikonları hangi türde olsun?';

$l['md_plugin_hide_title'] = 'Ziyaretçilere konu gizleme';
$l['md_plugin_hide_desc'] = 'Ziyaretçilere konu içeriği gizlensin mi?';

$l['md_plugin_hidem_title'] = 'Gizlenmiş konu mesaj';
$l['md_plugin_hidem_desc'] = 'Gizlenmiş konularda mesaj olarak ne kullanılacak?';
$l['md_plugin_hidem_message'] = '<div class="post-hide"><img src="stabilizer/svg/hide.svg" width="125"><p class="post-hide-head">DİKKAT!</p>Görüntülemeye çalıştığınız ileti, ziyaretçilere gizlenmiştir. İçeriği görüntülemek, cevap yazmak ve daha bir çok ayrıcalıktan yaralanabilmek için üye olmanız gerekmektedir.<div style="display:flex"><div style="overflow:hidden"><a href="member.php?action=login" class="post-hide-login"><span data-hover="GİRİŞ YAP">GİRİŞ YAP</span></a><span class="post-hide-sep">|</span></div><div style="overflow:hidden"><a href="member.php?action=register" class="post-hide-register"><span data-hover="KAYIT OL">KAYIT OL</span></a></div></div></div>';

$l['md_plugin_facebook_title'] = 'Facebook';
$l['md_plugin_facebook_desc'] = 'Facebook için sosyal medya linkinizi ekleyin.';

$l['md_plugin_twitter_title'] = 'Twitter';
$l['md_plugin_twitter_desc'] = 'Twitter için sosyal medya linkinizi ekleyin.';

$l['md_plugin_instagram_title'] = 'Instagram';
$l['md_plugin_instagram_desc'] = 'Instagram için sosyal medya linkinizi ekleyin.';

$l['md_plugin_twitch_title'] = 'Twitch';
$l['md_plugin_twitch_desc'] = 'Twitch için sosyal medya linkinizi ekleyin.';

$l['md_plugin_youtube_title'] = 'YouTube';
$l['md_plugin_youtube_desc'] = 'YouTube için sosyal medya linkinizi ekleyin.';

$l['md_plugin_discord_title'] = 'Discord';
$l['md_plugin_discord_desc'] = 'Discord için sosyal medya linkinizi ekleyin.';



$l['md_indexfblock_title_value'] = 'Duyuru başlık';

$l['md_indexfblock_view_t1'] = 'Duyuru #1 Aktif/Pasif';
$l['md_indexfblock_view_d1'] = 'Duyuru #1 aktifleştirilsin mi?';

$l['md_indexfblock_icon_t1'] = 'Duyuru #1 İkon';
$l['md_indexfblock_icon_d1'] = 'Kullanılacak ikonun URL adresini belirtin.';

$l['md_indexfblock_title_t1'] = 'Duyuru #1 Başlık';
$l['md_indexfblock_title_d1'] = 'Duyurunuz için bir başlık belirtin.';

$l['md_indexfblock_about_t1'] = 'Duyuru #1 İçerik';
$l['md_indexfblock_about_d1'] = 'Duyurunuz içeriği ile alakalı kısa bilgi girebilirsiniz.';

$l['md_indexfblock_link_t1'] = 'Duyuru #1 Link';
$l['md_indexfblock_link_d1'] = 'Yönlendirme için bir bağlantı eklentin.';


$l['md_indexfblock_view_t2'] = 'Duyuru #2 Aktif/Pasif';
$l['md_indexfblock_view_d2'] = 'Duyuru #2 aktifleştirilsin mi?';

$l['md_indexfblock_icon_t2'] = 'Duyuru #2 İkon';
$l['md_indexfblock_icon_d2'] = 'Kullanılacak ikonun URL adresini belirtin.';

$l['md_indexfblock_title_t2'] = 'Duyuru #2 Başlık';
$l['md_indexfblock_title_d2'] = 'Duyurunuz için bir başlık belirtin.';

$l['md_indexfblock_about_t2'] = 'Duyuru #2 İçerik';
$l['md_indexfblock_about_d2'] = 'Duyurunuz içeriği ile alakalı kısa bilgi girebilirsiniz.';

$l['md_indexfblock_link_t2'] = 'Duyuru #2 Link';
$l['md_indexfblock_link_d2'] = 'Yönlendirme için bir bağlantı eklentin.';


$l['md_indexfblock_view_t3'] = 'Duyuru #3 Aktif/Pasif';
$l['md_indexfblock_view_d3'] = 'Duyuru #3 aktifleştirilsin mi?';

$l['md_indexfblock_icon_t3'] = 'Duyuru #3 İkon';
$l['md_indexfblock_icon_d3'] = 'Kullanılacak ikonun URL adresini belirtin.';

$l['md_indexfblock_title_t3'] = 'Duyuru #3 Başlık';
$l['md_indexfblock_title_d3'] = 'Duyurunuz için bir başlık belirtin.';

$l['md_indexfblock_about_t3'] = 'Duyuru #3 İçerik';
$l['md_indexfblock_about_d3'] = 'Duyurunuz içeriği ile alakalı kısa bilgi girebilirsiniz.';

$l['md_indexfblock_link_t3'] = 'Duyuru #3 Link';
$l['md_indexfblock_link_d3'] = 'Yönlendirme için bir bağlantı eklentin.';


$l['md_indexfblock_view_t4'] = 'Duyuru #4 Aktif/Pasif';
$l['md_indexfblock_view_d4'] = 'Duyuru #4 aktifleştirilsin mi?';

$l['md_indexfblock_icon_t4'] = 'Duyuru #4 İkon';
$l['md_indexfblock_icon_d4'] = 'Kullanılacak ikonun URL adresini belirtin.';

$l['md_indexfblock_title_t4'] = 'Duyuru #4 Başlık';
$l['md_indexfblock_title_d4'] = 'Duyurunuz için bir başlık belirtin.';

$l['md_indexfblock_about_t4'] = 'Duyuru #4 İçerik';
$l['md_indexfblock_about_d4'] = 'Duyurunuz içeriği ile alakalı kısa bilgi girebilirsiniz.';

$l['md_indexfblock_link_t4'] = 'Duyuru #4 Link';
$l['md_indexfblock_link_d4'] = 'Yönlendirme için bir bağlantı eklentin.';

?>