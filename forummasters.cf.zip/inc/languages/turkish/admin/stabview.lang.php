<?php
$l['md_license_title'] = 'Lisanssız tema kullanım uyarısı!';
$l['md_license_h1'] = 'DİKKAT!';
$l['md_license_info'] = 'Lisansınız doğrulanamadı!';
$l['md_license_reasons'] = '<p>Bunun nedeni aşağıdakilerden herhangi biri olabilir;</p>
<ul>
<li>Aktif bir lisansınız mevcut değil</li>
<li>Sistemi lisanssız bir domain veya dizinde çalıştırıyor olabilirsiniz</li>
<li>IP adresi üzerinden erişim yapmaya çalışıyor olabilirsiniz</li>
<li>DNS kaynaklı anlık bir sorun yaşıyor olabilirsiniz</li>
<li>Copyright(yapımcı) bilgilerini silmiş olabilirsiniz</li>
</ul>';
$l['md_license_mistake'] = 'Bunların haricinde bir sorun olduğunu düşünüyorsanız, <a href="https://wa.me/908503464631">BURAYA</a> tıklayarak bize dönüş yapabilirsiniz.';
$l['md_license_adminstration'] = 'MyBBDizayn Yönetimi';

$l['sv_pn'] = 'Stabview';
$l['sv_pd'] = 'Stabview gelişmiş genel bakış eklentisi';

$l['sv_psettings_t'] = 'Stabview ayarları';
$l['sv_psettings_d'] = 'Stabview eklenti ayarları';

$l['sv_ps_tnum_t'] = 'Konu sayısı';
$l['sv_ps_tnum_d'] = 'Gösterilecek konu sayısı(reklam hariç).';

$l['sv_ps_dicon_t'] = 'Varsayılan ikon';
$l['sv_ps_dicon_d'] = 'Stabview için varsayılan başlık ikon kodu.';

$l['sv_ps_fids_t'] = 'Başlık isimleri ve idler';
$l['sv_ps_fids_d'] = 'Gösterilecek başlık isimleri ve her başlık için id ve ikon(| ile ayırın).';

$l['sv_ps_exc_t'] = 'İhraç forumlar';
$l['sv_ps_exc_d'] = 'İhraç tutulmasını istediğiniz forum id\'lerini virgül ile ayırarak belirtin.(pasif yapmak için boş bırakın).';

$l['sv_ps_ads_t'] = 'Reklam konuları';
$l['sv_ps_ads_d'] = 'Reklam konularının id\'leri, nokta ile ayırın.(pasif yapmak için boş bırakın).';
?>