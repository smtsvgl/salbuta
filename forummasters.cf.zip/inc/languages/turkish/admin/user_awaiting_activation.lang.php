<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Turkish Translation: MCTR Team - XpSerkan
 * Copyright © 2014 TR - MyBBGrup & MCTR Team, All Rights Reserved
 * Last Edit: 04.04.2017 / 22:57 - (XpSerkan)
 */

$l['awaiting_activation'] = "Aktivasyon Bekleyenler";
$l['awaiting_activation_desc'] = "Bu kısımdan aktivasyon bekleyen kullanıcıları yönetebilirsiniz. E-Posta aktivasyonu bekleyen herhangi bir kullanıcının hesabı bu kısımdan aktif edilirse, e-posta onayı işlemi yapmasına gerek olmadığını lütfen unutmayın.";

$l['manage_awaiting_activation'] = "Aktivasyon Bekleyenleri Yönet";

$l['no_users_awaiting_activation'] = "Şu anda aktivasyon bekleyen hiç kullanıcı yok.";

$l['username'] = "Kullanıcı Adı";
$l['registered'] = "Üyelik Tarihi";
$l['last_active'] = "Son Ziyareti";
$l['email'] = "E-Posta Adresi";
$l['ipaddress'] = "IP Adresi";
$l['type'] = "Aktivasyon Tipi";

$l['email_activation'] = "E-Posta Aktivasyonu Bekliyor";
$l['administrator_activation'] = "Yönetici Onayı Bekliyor";
$l['admin_activation_coppa'] = "(COPPA) Yönetici Onayı Bekliyor";

$l['activate_users'] = "Seçilen Kullanıcıları Aktif Et";
$l['delete_users'] = "Seçilen Kullanıcıları Sil";

$l['confirm_activate_users'] = "Seçilen kullanıcıları aktif etmek istediğinizden emin misiniz?";
$l['confirm_delete_users'] = "Seçilen kullanıcıları silmek istediğinizden emin misiniz?";

$l['no_users_selected'] = "Hiçbir Kullanıcı Seçmediniz.";

$l['success_users_deleted'] = "Seçilen Kullanıcılar Başarıyla Silindi.";
$l['success_users_activated'] = "Seçilen Kullanıcılar Başarıyla Aktif Edildi.";

$l['emailsubject_activateaccount'] = "Hesap Etkinleştirme: {1}";
$l['email_adminactivateaccount'] = "Merhaba {1},

Site yönetimi, {2} tarihinde forum hesabınızı etkinleştirdi.

Devam etmek için lütfen şu adresi ziyaret ediniz;

{3}

Kayıt sırasında kullandığınız kimlik bilgileriyle giriş yapabilirsiniz.

Teşekkürler,
{2} Yönetimi";

