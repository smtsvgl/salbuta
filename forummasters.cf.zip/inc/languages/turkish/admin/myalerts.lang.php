<?php
$l['myalerts'] = "Bildirimler Eklentisi";
$l['myalerts_pluginlibrary_missing'] = "Kurmaya çalıştığınız eklenti kurulamadı.Bu eklentiyi kurabilmeniz için güncel olan PluginLibrary eklentisini yüklemeniz gerekmektedir.Bu linke <a href=\"http://mods.mybb.com/view/pluginlibrary\">PluginLibrary</a> tıklayarak en son sürüm PluginLibrary temin edebilirsiniz.";

$l['setting_group_myalerts'] = "Bildirim Ayarları";
$l['setting_group_myalerts_desc'] = "Bildirimler eklentisinin ayarlarını yapılandırın...";
$l['setting_myalerts_perpage'] = "Gösterilecek Bildirim Sayısı";
$l['setting_myalerts_perpage_desc'] = "Bildirimler sayfasında kaç tane bildirim gösterilmesini istiyorsanız aşağıya rakamla bu değeri giriniz. Önerilen ayar olarak 10 seçilmiştir. <br /> Büyük ve aktif forumlarda ve sunucu durumunuza göre bu değeri düşürmeyi unutmayın!";
$l['setting_myalerts_dropdown_limit'] = "Popup Pencerede Kaç Tane Bildirim Gösterilsin?";
$l['setting_myalerts_dropdown_limit_desc'] = "Popup pencere olarak açılan sayfada kaç tane bildirim gösterilmesini istiyorsanız aşağıda ki kutuya rakamla istediğiniz değeri giriniz.Bu ayar sitenizin anasayfasında bulunan bildirimler butonuna tıklandığında açılan pencerede kaç tane bildirimin gösterilmesini ayarlar.<br />Çok fazla değer sitenizin geç açılmasına sebeb olacaktır.Önerilen ayar olarak 5 bildirim gösterilmesi tercih edilmiştir.";
$l['setting_myalerts_autorefresh'] = "Bildirimler Otomatik Yenilensin mi ? (Ajax)";
$l['setting_myalerts_autorefresh_desc'] = "Bildirimlerin otomatik olarak kaç saniye veya dakikada bir kontrol edilmesini istiyorsanız aşağıya saniye cinsinden süreyi giriniz. Arkaplanda sistem yeni bir bildirimin olup olmadığını belirlediğiniz süre sonunda kontrol edecektir. <br/>Düşük değerler girmek aktif forumlarda aşırı veritabanı sorgusu yaptıracağı için sitenizin yavaşlamasına sebeb olacaktır. Bu ayarı devre dışı bırakmak için aşağıda ki kutucağa <b>0</b> değerini giriniz.";
$l['setting_myalerts_avatar_size'] = "Avatar Boyutları ?";
$l['setting_myalerts_avatar_size_desc'] = "Avatarların genişlik ve yükseklik değerlerini bu ayar sayesinde ayarlayabilirsiniz. Yükseklik ve genişlik değerlerini girerken örnekte ki gibi değerler giriniz. <br /> <b>Örnek </b> 64|64 <br/> yükseklik|genişlik olarak ayarlanmaktadır.";

$l['myalerts_task_cleanup_ran'] = 'Read alerts over a week old were deleted successfully!';
$l['myalerts_task_cleanup_error'] = 'Something went wrong while cleaning up the alerts...';

$l['myalerts_task_title'] = 'Bildirimleri Temizleme Görevi';
$l['myalerts_task_description'] = 'Okunmamış,eski bildirimleri belirlediğiniz süre sonunda otomatik olarak silinecektir.Süreyi ayarlamak için sağ tarafta ki seçenekler kısmında görevi düzenle diyerek ayarlarınızı yapılandırın.';

$l['myalerts_alert_types'] = 'Alert Types';
$l['myalerts_can_manage_alert_types'] = 'Can manage alert types?';

$l['myalerts_alert_type_code'] = 'Code';
$l['myalerts_alert_type_enabled'] = 'Enabled?';
$l['myalerts_alert_type_can_be_user_disabled'] = 'Can be disabled by users?';
$l['myalerts_no_alert_types'] = 'No alert types found!';
$l['myalerts_update_alert_types'] = 'Update Alert Types';
$l['myalerts_alert_types_updated'] = 'Alert types updated!';

$l['myalerts_upgraded'] = 'MyAlerts has been upgraded. All old user alert settings have been lost - make sure you warn your users!';
