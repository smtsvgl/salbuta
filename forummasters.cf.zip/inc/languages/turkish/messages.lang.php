<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * MyBB 1.8 Türkçe Dil Dosyası Paketi
 * Türkçe Çeviri: Machine (Hüseyin KÖRBALTA)
 * Website: http://mybb.com.tr - http://mybbdepo.com
 * Kişisel blog: https://huseyinkorbalta.com
 * Son Güncelleme: 14.06.2019 - Saat: 18:05
 */

$l['click_no_wait'] = "Eğer daha fazla beklemek istemiyorsanız lütfen buraya tıklayın.";
$l['redirect_return_forum'] = "<br /><br />Alternatif olarak, <a href=\"{1}\">Foruma Geri Dön.</a>.";
$l['redirect_emailsent'] = "E-Posta mesajınız başarıyla gönderildi.";
$l['redirect_loggedin'] = "Başarılı bir şekilde giriş yaptınız.<br />Şimdi geldiğiniz yere geri yönlendiriliyorsunuz.";

$l['error_invalidpworusername'] = "Geçersiz kullanıcı adı veya şifre girdiniz. <br /><br />Eğer şifrenizi unuttuysanız, lütfen aşağıdaki link'ten yeni bir şifre alınız.<br/>Yeni bir şifre almak için <a rel=\"nofollow\" href=\"member.php?action=lostpw\">Buraya</a> tıklayın.";
$l['error_invalidpworusername1'] = "Geçersiz E-Posta veya şifre girdiniz. <br /><br />Eğer şifrenizi unuttuysanız, lütfen aşağıdaki link'ten yeni bir şifre alınız.<br/>Yeni bir şifre almak için <a rel=\"nofollow\" href=\"member.php?action=lostpw\">Buraya</a> tıklayın.";
$l['error_invalidpworusername2'] = "Geçersiz bir kullanıcı adı, şifre veya E-Posta adresi girdiniz. <br /><br />Eğer şifrenizi unuttuysanız, lütfen aşağıdaki link'ten yeni bir şifre alınız.<br/>Yeni bir şifre almak için <a rel=\"nofollow\" href=\"member.php?action=lostpw\">Buraya</a> tıklayın.";
$l['error_incompletefields'] = "Bir veya daha fazla alanı boş bıraktınız. Lütfen geri dönüp gerekli alanları doldurun.";
$l['error_alreadyuploaded'] = "<img src=\"images/icons/uyari.gif\" alt=\"Hata\" style=\"vertical-align: middle; height=\"14\" width=\"14\" /> Bu mesaj zaten aynı isimde bir ek dosya içeriyor. Lütfen dosyayı yeniden adlandırın yada farklı bir dosya yüklemeyi deneyin.<br />Ayrıca alternatif olarak, <strong>(Ek Dosyayı)</strong> güncelleyebilirsiniz.";
$l['error_alreadyuploaded_perm'] = "Bu konuda zaten aynı isimde ek dosya var. Lütfen ya ek dosya ismini değişin yada var olan dosya ile değişin.";
$l['error_nomessage'] = "Üzgünüz, geçerli bir mesaj girmediniz. Devam edebilmek için lütfen geri dönüp mesajı düzenleyin.";
$l['error_invalidemail'] = "Geçerli bir E-Posta adresi girmediniz.";
$l['error_nomember'] = "Belirttiğiniz üye, ya geçersiz yada mevcut değil.";
$l['error_maxposts'] = "Üzgünüz, fakat günlük mesaj yollama sınırını aştınız.<br /><br />Günlük en fazla: {1} tane mesaj gönderebilirsiniz.";
$l['error_nohostname'] = "Girdiğiniz IP adresine göre host adı bulunamadı.";
$l['error_invalidthread'] = "Belirtilen konu forumumuzda mevcut değil.";
$l['error_invalidpost'] = "Belirtilen yorum forumumuzda mevcut değil.";
$l['error_invalidattachment'] = "Belirtilen ek dosya forumumuzda mevcut değil.";
$l['error_invalidannouncement'] = "Belirtmiş olduğunuz duyuru bulunamadı.";
$l['error_invalidforum'] = "Geçersiz Forum";
$l['error_closedinvalidforum'] = "Kapalı bir foruma mesaj göndermeye çalışıyorsunuz veya bu bölüm bir kategori olabilir.";
$l['error_attachtype'] = "Yüklemek istediğiniz ek dosyanın, dosya türüne izin verilmiyor. Lütfen yüklemek için farklı bir dosya türü deneyin.<br /><strong>İzin Verilen Dosya Türleri:</strong> (.zip, .tar, .txt, .php, .pdf, .css, .png, .jpeg, .gif)";
$l['error_attachsize'] = "Yüklemek istediğiniz ek dosyanın boyutu, izin verilenden fazla büyük.<br /></strong>Maksimum Yüklenebilir Dosya Boyutu:</strong> {1} KB.";
$l['error_uploadempty'] = "Belirtilen dosya boş.";
$l['error_uploadsize'] = "Yüklemeye çalıştığınız dosyanın boyutu çok büyük.";
$l['error_uploadfailed'] = "Dosya yükleme işlemi başarısız oldu. Lütfen yüklemek için geçerli bir dosya seçip tekrar deneyin.";
$l['error_uploadfailed_detail'] = "Hata Detayları: ";
$l['error_uploadfailed_php1'] = "PHP Döngüsü: Yüklenen dosyanın php.ini içinde maksimum dosya boyutu upload sınırını aştı. Lütfen bu hatayı forum yöneticisine bildirin.";
$l['error_uploadfailed_php2'] = "Yüklemeye çalıştığınız dosyanın boyutu, maksimum izin verilen boyutu aştı.";
$l['error_uploadfailed_php3'] = "Yüklemeye çalıştığınız dosya kısmen yüklenemedi.";
$l['error_uploadfailed_php4'] = "Hiçbir Dosya Yüklenmedi.";
$l['error_uploadfailed_php6'] = "PHP Döngüsü: Geçici temporary klasörü eksik. Lütfen bu hatayı forum yöneticisine bildirin.";
$l['error_uploadfailed_php7'] = "PHP Döngüsü: Dosya diske yazılamadı.  Lütfen bu hatayı forum yöneticisine bildirin.";
$l['error_uploadfailed_phpx'] = "PHP Hata Kodu Döngüsü: {1}.  Lütfen bu hatayı forum yöneticisine bildirin.";
$l['error_uploadfailed_nothingtomove'] = "Geçersiz bir dosya belirtildi, bu sebepten dolayı yüklenen dosya hedefine taşınamadı.";
$l['error_uploadfailed_movefailed'] = "Dosya hedefine taşınırken bir hata oluştu.";
$l['error_uploadfailed_lost'] = "Ekli dosya bu sunucuda bulunamadı.";
$l['error_emailmismatch'] = "Girilen E-Posta adresleri uyuşmuyor. Lütfen geri dönüp tekrar deneyin.";
$l['error_nopassword'] = "Geçerli bir şifre girmediniz.";
$l['error_usernametaken'] = "Seçtiğiniz kullanıcı adı zaten kayıtlı. Daha önce kayıt yapdıysanız, lütfen <a rel=\"nofollow\" href=\"member.php?action=login\">Giriş</a> yapınız.";
$l['error_nousername'] = "Bir kullanıcı adı girmediniz.";
$l['error_invalidusername'] = "Geçersiz bir kullanıcı adı girdiniz.";
$l['error_invalidpassword'] = "Hatalı bir şifre girdiğiniz. Eğer şifrenizi unuttuysanız, <a rel=\"nofollow\" href=\"member.php?action=lostpw\">Buraya</a> tıklayın. Veya geri dönüp tekrar deneyin.";
$l['error_postflooding'] = "Üzgünüz, mesajınız gönderilemiyor. Sadece her {1} saniyede bir mesaj gönderebilirsiniz.";
$l['error_nopermission_guest_1'] = "<img src=\"images/icons/uyari.gif\" alt=\"Hata\" style=\"vertical-align: middle; height=\"14\" width=\"14\" /> Ya giriş yapmadınız, ya da bu sayfaya erişim izniniz yok. Veya bunun sebebi aşağıdaki nedenlerden dolayı olabilir:";
$l['error_nopermission_guest_2'] = "Ya giriş yapmadınız, ya da kayıtlı değilsiniz. Lütfen giriş yapabilmek için aşağıdaki giriş formunu kullanın.";
$l['error_nopermission_guest_3'] = "Yöneticilere ait özel bir bölüme veya izniniz olmayan bir kaynağamı girmeye çalışıyorsunuz? Forum kurallarından bu işlemi yapma yetkinizin olup olmadığını kontrol ediniz.";
$l['error_nopermission_guest_4'] = "Üyelik hesabınız yöneticiler tarafından iptal edilmiş veya hala aktivasyon maili bekliyor olabilirsiniz.";
$l['error_nopermission_guest_5'] = "Eğer doğrudan bu sayfaya eriştiyseniz, size izin verilen uygun formlar veya linkleri kullanabilirsiniz.";
$l['login'] = "Giriş Yap";
$l['need_reg'] = "Kayıt Ol";
$l['forgot_password'] = "Şifremi Unuttum?";
$l['error_nopermission_user_1'] = "Bu sayfaya erişim izniniz yok. Bunun sebebi aşağıdaki nedenlerden dolayı olabilir:";
$l['error_nopermission_user_ajax'] = "Bu sayfaya erişim izniniz yok.";
$l['error_nopermission_user_2'] = "Üyelik hesabınız yasaklanmış veya bu sayfaya erişim izniniz engellenmiş olabilir.";
$l['error_nopermission_user_3'] = "Yöneticilere ait özel bölüme veya izniniz olmayan bir kaynağamı girmeye çalışıyorsunuz? Forum kurallarından bu işlemi yapma yetkinizin olup olmadığını kontrol ediniz.";
$l['error_nopermission_user_4'] = "Hesabınız, hala aktivasyon maili veya yönetici onayı bekliyor olabilir.";
$l['error_nopermission_user_5'] = "Eğer doğrudan bu sayfaya eriştiyseniz, size izin verilen uygun formlar veya linkleri kullanabilirsiniz.";
$l['error_nopermission_user_resendactivation'] = "Aktivasyon Kodunu Tekrar Yolla";
$l['error_nopermission_user_username'] = "Şu anda Giriş Yapılan Kullanıcı Adı: '{1}'";
$l['logged_in_user'] = "Kullanıcı Giriş Zamanı";
$l['error_too_many_images'] = "Çok Fazla Resim Mevcut.";
$l['error_too_many_images2'] = "Üzgünüz, mesajınız çok sayıda resim içerdiğinden dolayı gönderilemiyor. Devam edebilmek için lütfen bazı resimleri siliniz.";
$l['error_too_many_images3'] = "<strong>Not:</strong> Mesaj başına izin verilen maksimum resim sayısı";
$l['error_attach_file'] = "Dosya Yükleme Hatası";
$l['please_correct_errors'] = "Lütfen devam etmeden önce aşağıdaki hataları düzeltin:";
$l['error_reachedattachquota'] = "Üzgünüz, ek dosya yükleyemezsiniz, çünkü ek dosya yükleme limitiniz izin verilen, ({1}) sınırına ulaştı.";
$l['error_maxattachpost'] = "Üzügünüz fakat, {1} dosyası konu başına izin verilen maksimum ek dosya ekleme limitine ulaştığı için eklenemiyor.";
$l['error_invaliduser'] = "Belirtilen kullanıcı geçersiz veya yok.";
$l['error_invalidaction'] = "Geçersiz Eylem";
$l['error_messagelength'] = "Üzgünüz, mesajınız çok uzun olduğu için gönderilemiyor. Lütfen mesajınızı kısaltıp tekrar göndermeyi deneyin.";
$l['error_message_too_short'] = "Üzgünüz, mesajınız çok kısa olduğu için gönderilemiyor.";
$l['failed_login_wait'] = "Başarız giriş sayısı limitini aştınız. Tekrar giriş yapmayı denemek için: ({1} Saat, {2} Dakika, {3} Saniye), beklemeniz gerekiyor.";
$l['failed_login_again'] = "<br />Geriye sadece <strong>{1}</strong> giriş yapma hakkınız kaldı.";
$l['error_max_emails_day'] = "24 Saat içinde sadece {1} mesaj gönderme hakkınız olduğu için konuyu arkadaşınıza gönderme veya E-Posta kullanım özelliklerini kullanamazsınız.";
$l['attachments_disabled'] = "Ek dosya ekleme sistemi, yönetici tarafından devre dışı bırakıldığı için kullanamazsınız.";

$l['emailsubject_lostpw'] = "Şifreni Sıfırla {1}";
$l['emailsubject_passwordreset'] = "Yeni Şifre {1}";
$l['emailsubject_subscription'] = "Yeni Yorum {1}";
$l['emailsubject_randompassword'] = "{1} Şifreniz";
$l['emailsubject_activateaccount'] = "{1} Hesap Aktivasyonu";
$l['emailsubject_forumsubscription'] = "{1} Bölümünde Yeni Konu";
$l['emailsubject_reportpost'] = "{1} Rapor Edilen Mesaj";
$l['emailsubject_reportprofile'] = "{1} Profili Rapor Edilen Kullanıcı";
$l['emailsubject_reportreputation'] = "{1} Rapor Edilen Rep Puanı";
$l['emailsubject_reachedpmquota'] = "Özel Mesaj kotanız şu anda {1} seviyesine ulaştı";
$l['emailsubject_changeemail'] = "{1} E-Posta Değişikliği";
$l['emailsubject_newpm'] = "{1} - {2} Yeni Özel Mesaj";
$l['emailsubject_newjoinrequest'] = "{1} Yeni Üyelik Kaydı";
$l['emailsubject_sendtofriend'] = "Bu konu ilgini çekebilir - {1}";
$l['emailsubject_changepassword'] = "{1} Şifre Değişikliği";
$l['emailbit_viewthread'] = "...(Devamını okumak için konuyu ziyaret edin)";

$l['email_lostpw'] = "Merhaba {1},

{2}, Üyelik hesabınız şifre sıfırlama aşamasında. Tamamlamak için aşağıdaki bağlantıya tıklayın.

{3}/member.php?action=resetpassword&uid={4}&code={5}

Eğer üsteki bağlantı çalışmıyorsa, lütfen aşağıdaki bağlantıyı deneyin.

{3}/member.php?action=resetpassword

Aşağıdaki bilgileri girmeniz gerekiyor:
Kullanıcı Adı: {1}
Aktivasyon Kodu: {5}


Teşekkürler,
{2} Yönetimi";
$l['email_lostpw1'] = "Merhaba {1},

{2}, Üyelik hesabınız şifre sıfırlama aşamasında. Tamamlamak için aşağıdaki bağlantıya tıklayın.

{3}/member.php?action=resetpassword&uid={4}&code={5}

Eğer üsteki bağlantı çalışmıyorsa, lütfen aşağıdaki bağlantıyı deneyin.

{3}/member.php?action=resetpassword

Aşağıdaki bilgileri girmeniz gerekiyor:
E-Posta adresiniz.
Aktivasyon Kodu: {5}

Teşekkürler,
{2} Yönetimi";
$l['email_lostpw2'] = "Merhaba {1},

{2}, Üyelik hesabınız şifre sıfırlama aşamasında. Tamamlamak için aşağıdaki bağlantıya tıklayın.

{3}/member.php?action=resetpassword&uid={4}&code={5}

Eğer üsteki bağlantı çalışmıyorsa, lütfen aşağıdaki bağlantıyı deneyin.

{3}/member.php?action=resetpassword

Aşağıdaki bilgileri girmeniz gerekiyor:
Kullanıcı Adı: {1} (veya E-Posta adresiniz)
Aktivasyon Kodu: {5}

Teşekkürler,
{2} Yönetimi";

$l['email_reportpost'] = "Merhaba {1}, {2} adlı kullanıcı bu konuyu rapor etti.

Rapor edilen konu:
{3}
{4}/{5}

Rapor Edilme Sebebi:
{6}

Bu rapor bildirimi forumdaki tüm yöneticilere gönderildi.

Lütfen, rapor edilen konuyu/mesajı en kısa sürede kontrol ediniz.";

$l['email_reportprofile'] = "Merhaba {1}, {2} adlı kullanıcı aşağıdaki kullanıcıyı rapor etti.:

{3}
{4}/{5}

Rapor Edilme Sebebi:
{6}

Bu rapor bildirimi forumdaki tüm yöneticilere gönderildi.

Lütfen, rapor edilen bu kullanıcının profilini en kısa sürede kontrol ediniz.";

$l['email_reportreputation'] = "Merhaba {1}, {2} adlı kullanıcı kurallara uygun olmayan bir rep puanı rapor etti.:

{3}
{4}/{5}

Rapor Edilme Sebebi:
{6}

Bu rapor bildirimi forumdaki tüm yöneticilere gönderildi.

Lütfen, rapor edilen bu rep puanını en kısa sürede kontrol ediniz.";

$l['email_report_comment_extra'] = "{1}: {2}";

$l['email_passwordreset'] = "Merhaba {1},

{2} - Sitesindeki şifreniz sıfırlandı.

Yeni Şifreniz: {3}

Foruma giriş yapabilmek için bu şifreyi kullanmanız gerekiyor.
şifrenizi foruma giriş yaptıktan sonra kullanıcı panelinizden değiştirebilirsiniz.

Teşekkürler,
{2} Yönetimi";
$l['email_randompassword'] = "Merhaba {1},

{2} Sitemize üye olup aramıza katıldığınız için teşekkür ederiz.

Aşağıdaki bilgileri kullanarak giriş yapabilirsiniz.

Kullanıcı Adı: {3}
Şifreniz: {4}

Giriş yaptıktan sonra güvenliğiniz için şifrenizi değiştirmelisiniz.
Şifrenizi kullanıcı panelinize girerek, sol taraftaki menüde bulunan, (Şifreni Değiştir), seçeneğine tıklayıp değiştirebilirsiniz.

Teşekkürler,
{2} - Yönetimi";

$l['email_randompassword1'] = "Merhaba {1},

{2} Sitemize üye olup aramıza katıldığınız için teşekkür ederiz.

Aşağıdaki bilgileri kullanarak giriş yapabilirsiniz.

E-Posta Adresiniz.
Şifreniz: {4}

Giriş yaptıktan sonra güvenliğiniz için şifrenizi değiştirmelisiniz.
Şifrenizi kullanıcı panelinize girerek, sol taraftaki menüde bulunan, (Şifreni Değiştir), seçeneğine tıklayıp değiştirebilirsiniz.

Teşekkürler,
{2} - Yönetimi";

$l['email_randompassword2'] = "Merhaba {1},

{2} Sitemize üye olup aramıza katıldığınız için teşekkür ederiz.

Aşağıdaki bilgileri kullanarak giriş yapabilirsiniz.

Kullanıcı Adı: {3} (veya E-Posta adresiniz)
Şifreniz: {4}

Giriş yaptıktan sonra güvenliğiniz için şifrenizi değiştirmelisiniz.
Şifrenizi kullanıcı panelinize girerek, sol taraftaki menüde bulunan, (Şifreni Değiştir), seçeneğine tıklayıp değiştirebilirsiniz.

Teşekkürler,
{2} Yönetimi";

$l['email_sendtofriend'] = "Merhaba {1},

{2}, Sitesindeki aşağıdaki bağlantıda yer alan konunun ilgini çekebileceğini düşünüyorum.

Bkz: {3}

Sayın {1}, Bu bildirimi almanızın nedeni aşağıda yazmaktadır.

------------------------------------------

{4}

------------------------------------------

Teşekkürler,
{2} - Yönetimi";

$l['email_forumsubscription'] = "Merhaba {1},

{2} adlı kullanıcı, {3} sitesindeki ''{4}'' bölümünde yeni bir konu başlattı. Bu sizin takip ettiğiniz (abone olduğunuz) kategori/forumdur.

Kategori/Forum Adı: {4}

Konu Başlığı: {5}

Mesajın Bir Kısmı Aşağıdadır:

-------------------------------------------

{6}

----------------------------------------------

Devamını okumak için lütfen, aşağıdaki bağlantıyı ziyaret ediniz.

Bkz: {7}/{8}

Ayrıca, bu forumda başka yeni konular açılmış olabilir fakat, siz forumu tekrar ziyaret edinceye kadar hiçbir bildirim almayabilirsiniz.


Teşekkürler,
{4} - Yönetimi

------------------------------------------

Abonelik/Takip İptal Bilgisi:

E-Posta bildirimi almak istemiyorsanız, aşağıdaki bağlantıyı ziyaret ederek bildirim almayı kapatabilirsiniz:

{7}/usercp2.php?action=removesubscription&type=forum&fid={9}&my_post_key={10}

------------------------------------------";

$l['email_activateaccount'] = "Merhaba {1},

{2}, Sitesindeki üyelik işleminiz tamamlama aşamasında. Tamamlamak için aşağıdaki bağlantıya tıklayın.

{3}/member.php?action=activate&uid={4}&code={5}

Eğer, üsteki link çalışmıyorsa lütfen aşağıdaki bağlantıyı deneyin.

{3}/member.php?action=activate


Açılan sayfada aşağıdaki bilgileri girmeniz gerekiyor:

Kullanıcı Adı: {1}
Aktivasyon Kodu: {5}


Teşekkürler,
{2} - Yönetimi";

$l['email_activateaccount1'] = "Merhaba {1},

{2}, Sitesindeki üyelik işleminiz tamamlama aşamasında. Tamamlamak için aşağıdaki bağlantıya tıklayın.

{3}/member.php?action=activate&uid={4}&code={5}

Eğer, üsteki link çalışmıyorsa lütfen aşağıdaki bağlantıyı deneyin.

{3}/member.php?action=activate

Açılan sayfada aşağıdaki bilgileri girmeniz gerekiyor:

E-Posta adresiniz.
Aktivasyon Kodu: {5}

Teşekkürler,
{2} - Yönetimi";

$l['email_activateaccount2'] = "Merhaba {1},

{2}, Sitesindeki üyelik işleminiz tamamlama aşamasında. Tamamlamak için aşağıdaki bağlantıyı ziyaret ediniz.

{3}/member.php?action=activate&uid={4}&code={5}

Eğer, üsteki bağlantı çalışmıyorsa lütfen aşağıdaki bağlantıyı deneyin.

{3}/member.php?action=activate

Açılan sayfada aşağıdaki bilgileri girmeniz gerekiyor:

Kullanıcı Adı: {1} (veya E-Posta adresiniz)
Aktivasyon Kodu: {5}

Teşekkürler,
{2} - Yönetimi";

$l['email_subscription'] = "Merhaba {1},

{2} adlı kullanıcı, {3} sitesindeki, takip ettiğiniz ''{4}'', başlıklı konuya yorum yazdı.

Yorumun bir kısmı aşağıdadır:
------------------------------------------
{5}
------------------------------------------

Devamını okumak için lütfen, aşağıdaki bağlantıyı ziyaret ediniz.

{6}/{7}

Ayrıca, bu konuya başka yeni yorumlar yazılmış olabilir fakat, siz konuyu tekrar ziyaret edinceye kadar hiçbir bildirim almayabilirsiniz.


Teşekkürler,
{3} - Yönetimi

------------------------------------------

Abonelik/Takip İptal Bilgisi:

Bu konu hakkında E-Posta bildirimi almak istemiyorsanız, aşağıdaki bağlantıyı ziyaret ederek bildirim almayı kapatabilirsiniz:

{6}/usercp2.php?action=removesubscription&tid={8}&my_post_key={9}

------------------------------------------";
$l['email_reachedpmquota'] = "Merhaba {1},

{2}, Sitesindeki ''Özel Mesaj'' kotanızın dolduğunu bildirmek için sistem tarafından otomatik olarak bir E-Posta aldınız.

Bir veya daha fazla kullanıcı size ''Özel Mesaj'' göndermeye çalıştı fakat, kotanız dolu olduğu için ''Özel Mesaj'' gönderemiyorlar.

Lütfen, gereksiz özel mesajlarınızı silerek kotanızın tekrar açılmasını sağlayınız. Ayrıca özel mesajları silme işlemi esnasında, çöp kutusunuda temizlemeyi unutmayınız.

Teşekkürler,
{2} - Yönetimi
{3}";
$l['email_changeemail'] = "Merhaba {1},

{2}, Sitesindeki E-Posta adresini değiştirme istediği talep edildi. (Değişiklik detayları aşağıdadır.)

Eski E-Posta Adresi: {3}
Yeni E-Posta Adresi: {4}

Eğer, {2} E-Posta adresi için bu değişikliklerin doğruluğunu onaylıyorsanız, aşağıdaki bağlantıya tıklayınız.

{5}/member.php?action=activate&uid={8}&code={6}

Eğer üsteki link çalışmıyorsa, lütfen aşağıdaki bağlantıyı deneyin.

{5}/member.php?action=activate

Açılan sayfada aşağıdaki bilgileri girmeniz gerekiyor:

Kullanıcı Adı: {7}
Aktivasyon Kodu: {6}

Eğer, E-Posta adresi değişikliğini onaylamazsanız eski E-Posta adresiniz değişmeyecektir.


Teşekkürler,
{2} - Yönetimi
{5}";

$l['email_changeemail_noactivation'] = "Merhaba {1},

{2}, Sitesindeki E-Posta adresini değiştirme istediği talep edildi. (Değişiklik detayları aşağıdadır.)

Eski E-Posta Adresi: {3}
Yeni E-Posta Adresi: {4}

Bu değişilik talebi otomatik olarak işlenmiştir.
Eğer bu değişiklik talebi sizin izniniz ve isteğiniz dışında olmuşsa lütfen, iletişim bölümünden forum yöneticisi ile irtibat kurunuz.

Teşekkürler,
{2} - Yönetimi
{5}";

$l['email_changepassword'] = "Merhaba {1},

Siz veya erişim bilgilerinizi bilen başka biri şifrenizi değiştirdiği için bu E-Posta bildirimini aldınız.

Kullanıcı Adı: {1}
E-Posta Adresi: {2}

Eğer bu şifre değişikliği sizin izniniz ve isteğiniz dışında olmuşsa lütfen, iletişim bölümünden forum yöneticisi ile irtibat kurunuz.

Teşekkürler,
{3} - Yönetimi
{4}";

$l['email_newpm'] = "Merhaba {1},

{3} Sitesinden Yeni Bir Özel Mesaj Aldınız.

Gönderen: {2}

Mesajın bir kısmı aşağıdadir.
------------------------------------------
{5}
------------------------------------------

Bu mesajın tamamını okumak için aşağıdaki bağlantıya ziyaret ediniz.

{4}/private.php

{3}, Sitesinden gelen mesajı okumadığınız takdirde, Yeni bir özel mesaj geldiğinde bildirim almayabilirsiniz.

Ayrıca aşağıdaki bağlantıdan kullanıcı hesabınıza girerek, ''Özel Mesaj'' bildirimini kapatabilirsiniz.

{4}/usercp.php?action=options


Teşekkürler,
{3} - Yönetimi
{4}";

$l['email_emailuser'] = "Merhaba {1},

{3} Sitesinden Yeni Bir Özel Mesaj Aldınız.

Gönderen: {2}

Mesajın bir kısmı aşağıdadir.
------------------------------------------
{5}
------------------------------------------

Teşekkürler,
{3} - Yönetimi
{4}


------------------------------------------

{3}, Sitesinden gelen mesajı okumadığınız takdirde, Yeni bir özel mesaj geldiğinde bildirim almayabilirsiniz.

Ayrıca aşağıdaki bağlantıdan kullanıcı hesabınıza girerek, ''Özel Mesaj'' bildirimini kapatabilirsiniz.

{4}/usercp.php?action=options

------------------------------------------";

$l['email_groupleader_joinrequest'] = "Merhaba {1},

{2} Sitesindeki, {4}, {3}, Grubuna katılmak istiyor. (Detaylar aşağıdadır).

Katılım Sebebi: {5}

Bu isteği kabul veya reddetmek için aşağıdaki bağlantıyı ziyaret ediniz.

{6}/managegroup.php?gid={7}

Teşekkürler,
{4} - Yönetimi";

$l['email_contact_subject'] = "İletişim: {1}";
$l['email_contact'] = "E-Posta: {1}
Forum Profili: {2}
IP Adresi: {3}
Mesaj:
{4}";

$l['pmsubject_subscription'] = "{1} - Yeni Yorum Yazıldı!";
$l['pm_subscription'] = "Merhaba {1},

{2}, Sitendeki takip ettiğiniz {3}, başlıklı konuya yeni bir yorum yazıldı.

Yorumun bir kısmı aşağıdadır:
------------------------------------------
{4}
------------------------------------------

Devamını okumak için lütfen, aşağıdaki bağlantıyı ziyaret ediniz.

[url]{5}/{6}[/url]

Ayrıca bu konuda başka yorumlar yazılmış olabilir fakat, siz konuyu ziyaret edinceye kadar yeni bir bildirim almazsınız.

------------------------------------------

Abonelik/Takip İptal Bilgisi:

Bu konu hakkında özel mesaj bildirim almak istemiyorsanız, aşağıda bağlantıyı ziyaret ederek bildirim almayı kapatabilirsiniz.

[url]{5}/usercp2.php?action=removesubscription&tid={7}&my_post_key={8}[/url]

------------------------------------------";

$l['email_broken_task_subject'] = "{1} - Tarihinde MyBB Görev Hatası Oluştu!";
$l['email_broken_task'] = "{1} sitenizde çalışan, ({2}) aracında zamanlanmış görev sistemi bir hatayla karşılaştı.

Eksik ve veya hataya neden olan görev dosyası: {3}

Sorununuzu çözene kadar bu görev aracı devre dışı bırakılmıştır.";