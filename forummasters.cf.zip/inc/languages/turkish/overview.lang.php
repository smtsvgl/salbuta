<?php
$l['overview_overview'] = "Forum Genel İstatistikleri";

$l['overview_newest_members'] = "Yeni Üyeler";
$l['overview_username'] = "Kullanıcı Adı";
$l['overview_posts'] = "Yorumları";

$l['overview_top_posters'] = "En Çok Yazan";

$l['overview_newest_threads'] = "Son Konular";
$l['overview_topic'] = "Konular";
$l['overview_author'] = "Yazan";
$l['overview_replies'] = "Yorumlar";

$l['overview_most_replies'] = "En Çok Yorumlanan Konular";

$l['overview_favourite_threads'] = "Favori Konular";
$l['overview_views'] = "Okunma";

$l['overview_newest_posts'] = "Son Yorumlar";
$l['overview_subject'] = "Yorumlar";

$l['overview_bestrep_members'] = "En Çok Rep Alanlar";
$l['overview_reputation'] = "Rep Puanı";

$l['overview_newest_polls'] = "En Yeni Anketler";
$l['overview_question'] = "Anketler";

$l['overview_next_events'] = "En Yeni Etkinlikler";
$l['overview_event'] = "Etkinlikler";
?>