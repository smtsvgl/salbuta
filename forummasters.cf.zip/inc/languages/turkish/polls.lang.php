<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Turkish Translation: MCTR Team - XpSerkan
 * Copyright © 2014 TR - MyBBGrup & MCTR Team, All Rights Reserved
 * Last Edit: 08.09.2015 / 04:29 - (XpSerkan)
 */

$l['nav_postpoll'] = "Yeni Anket Gönder";
$l['nav_editpoll'] = "Anket Düzenle";
$l['nav_pollresults'] = "Anket Sonuçları";

$l['edit_poll'] = "Anket Düzenle";
$l['delete_poll'] = "Anket Sil";
$l['delete_q'] = "Silinsin mi?";
$l['delete_note'] = "Bu anketi silmek için sol'daki onay kutucuğunu işaretleyip, sağ'daki sil butonuna tıklayın.";
$l['delete_note2'] = "<strong>Uyarı:</strong> Anket silindikten sonra yedeği alınmadığı için tekrar geri getirilemez.";
$l['question'] = "Anket Sorusu:";
$l['num_options'] = "Anket Seçenekleri:";
$l['max_options'] = "Maksimum Seçenek Sayısı:";
$l['poll_options'] = "Anket Seçenekleri:";
$l['update_options'] = "Seçenekleri Güncelle";
$l['poll_options_note'] = "Anket seçenekleri kısa ve öz olmalıdır.";
$l['options'] = "Diğer Seçenekler:";
$l['option_multiple'] = "<strong>Çoklu Seçim Ayarları:</strong> Kullanıcıların birden fazla oy kullanmaları için kutucuğu işretleyiniz.";
$l['option_multiple_maxoptions'] = "Kullanıcı başına maksimum seçenek oylama sayısı. (Sınırsız yapmak için <strong>0</strong> yazın):";
$l['option_public'] = "<strong>Genel Anket:</strong> Genel bir anket olup kullanıcılara, kimlerin hangi seçeneğe oy kullandığı göstermenizi sağlar.";
$l['option_closed'] = "<strong>Anketi Kapat:</strong> Bu seçenek anketi oylamaya kapatmanızı sağlar.";
$l['poll_timeout'] = "Anket Süresi:";
$l['timeout_note'] = "Bu kısımdan, anketin ne kadar süre açık kalacağını ayarlayabilisiniz.<br />(Süresiz yapmak için <strong>0</strong> yazın)";
$l['days_after'] = "Gün Sonra:";
$l['update_poll'] = "Anketi Güncelle";
$l['option'] = "Seçenek";
$l['votes'] = "Oylar:";
$l['post_new_poll'] = "Yeni Anket Gönder";
$l['days'] = "Gün";
$l['poll_results'] = "Anket Sonuçları";
$l['poll_total'] = "Katılımcı sayısı:";
$l['poll_votes'] = "Oylar";

$l['redirect_pollposted'] = "Anketiniz Konuya İlave Edilmiştir.<br />Şimdi Konuya Geri Yönlendiriliyorsunuz...";
$l['redirect_pollpostedmoderated'] = "Anketiniz Konuya İlave Edilmiştir. Fakat Konunuz Moderasyon İşlemi İçin Beklemeye Alınmıştır.<br />Şimdi Foruma Yönlendiriliyorsunuz...";
$l['redirect_pollupdated'] = "Anketiniz Gücellenmiştir.<br />Şimdi Konuya Geri Yönlendiriliyorsunuz...";
$l['redirect_votethanks'] = "Teşekkürler,Oyunuz Ankete İşlenmiştir.<br />Şimdi Konuya Geri Yönlendiriliyorsunuz...";
$l['redirect_unvoted'] = "Oyunuz Silinmiştir.<br />Şimdi Konuya Geri Yönlendiriliyorsunuz...";
$l['redirect_polldeleted'] = "Teşekkürler, Anketiniz Başarılı Olarak Konudan Silinmiştir.<br />Şimdi Konuya Geri Yönlendiriliyorsunuz...";

$l['error_polloptiontoolong'] = "Anket Seçenekleri İzin Verilen Limiti Aşıyor. Lütfen Geri Dönüp Seçenekleri İzin Verilen Limite Göre Yeniden Yapılandırınız.";
$l['error_polloptionsequence'] = "Girdiğiniz bir veya daha fazla enket seçeneği, kullanılmaması gereken şu diziyi içeriyor: <strong>||~|~||</strong>. Lütfen geri dönüp bu diziyi kaldırın..";
$l['error_noquestionoptions'] = "Anket İçin Ya Bir Soru Girmediniz Yada Anket Seçeneklerinin Sayısını Hatalı Girdiniz. Anket İçin İzin Verilen Seçenek Sayısı (2 ile 10 Arası) Olmalıdır.<br />Lütfen Geri Dönüp Anket'teki Hatalı Kısımları Düzenleyiniz.";
$l['error_pollalready'] = "Bu Konuda Zaten Bir Anket Mevcut!";
$l['error_nopolloptions'] = "Belirtmiş Olduğunuz Anket Seçenekleri Ya Geçersiz Yada Mevcut Değil.";
$l['error_maxpolloptions'] = "Üzgünüz, fakat birçok seçenek için oy kullandınız. Sadece, <strong>({1})</strong> seçenek oylayabilirsiniz.<br />Lütfen, geri dönüp tekrar deneyin.";
$l['error_alreadyvoted'] = "Bu anket için zaten oy kullanmışsınız.";
$l['error_notvoted'] = "Sizin bu ankette oyunuz yok.";
$l['error_invalidpoll'] = "Belirtmiş olduğunuz anket ya geçersiz yada mevcut değil.";
$l['error_pollclosed'] = "Kapalı bir ankete oy kullanamazsınız.";
$l['poll_time_limit'] = "Üzgünüz, Bu konuya Anket ekleyemezsiniz. Anket ekleme izinleri konuyu açtıktan sonra; {1} Saat içinde eklenebilecek şekilde ayarlanmış.";

$l['poll_deleted'] = "Silinen Anket";
$l['poll_edited'] = "Düzenlenen Anket";
