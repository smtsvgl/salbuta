<?php
/**
 * MyBB 1.8 Turkish Language Pack
 * Copyright 2014 MyBB Group, All Rights Reserved
 *
 * Turkish Translation: MCTR Team - XpSerkan
 * Copyright © 2014 TR - MyBBGrup & MCTR Team, All Rights Reserved
 * Last Edit: 01.08.2014 / 20:02 - (XpSerkan)
 */

// Help Section 1
$l['s1_name'] = "Kullanıcı Bakımı Ve Forum Kullanımı";
$l['s1_desc'] = "Forum Hesabı Kullanımı İçin Basit ve Temel Kılavuzlar.";

// Help Section 2
$l['s2_name'] = "Konu Ve Yorum Gönderimi";
$l['s2_desc'] = "Konu Gönderme, Cevap Yazma, Mykod'lar Ve Temel Olarak Forum Kullanım Kılavuzu.";

