<?php
$l['md_license_title'] = 'Unlicensed content alert!';
$l['md_license_h1'] = 'WARNING!';
$l['md_license_info'] = 'Your license can\'t be confirmeed!';
$l['md_license_reasons'] = '<p>This may be due to any of the following;</p>
<ul>
<li>Aktif bir lisansınız mevcut değil You do not have any active license for this content</li>
<li>Using plugin on unlicensed domain or path </li>
<li>IP adresi üzerinden erişim yapmaya çalışıyor olabilirsiniz Using IP adress instead of DNS adress</li>
<li>Instant problem with DNS</li>
<li>Removeing copyright(crafted) informations(s)</li>
</ul>';
$l['md_license_mistake'] = 'If you think there is a problem other than these, you can return to us by clicking <a href="https://wa.me/908503464631">HERE</a>.';
$l['md_license_adminstration'] = 'MyBBGraphic Administration';

$l['sv_loading'] = 'Loading..';
$l['sv_loadmore'] = 'Load more';
$l['sv_nodata'] = 'The thread you specified does not exist.';
$l['sv_nomore'] = 'No more content for loading';

$l['sv_latestthreads'] = 'Latest threads';
$l['sv_latestrthreads'] = 'Latest replied';
$l['sv_latesttrends'] = 'Trend threads';

$l['sv_subject'] = 'Subject';
$l['sv_subject_s'] = 'S.';

$l['sv_rv'] = 'Reply / Views';
$l['sv_rv_s'] = 'R. / V.';

$l['sv_lastpost'] = 'Last post';
$l['sv_lastpost_s'] = 'L.';

$l['sv_date'] = 'Date';
$l['sv_date_s'] = 'D.';

$l['sv_category'] = 'Cateogry';
$l['sv_category_s'] = 'C.';

$l['sv_author'] = 'Author';

$l['sv_ad'] = 'AD';
$l['sv_sgoogle'] = 'Seach on Google';
$l['sv_refresh'] = 'Refresh';

?>