<?php
$l['md_license_title'] = 'Unlicensed content alert!';
$l['md_license_h1'] = 'WARNING!';
$l['md_license_info'] = 'Your license can\'t be confirmeed!';
$l['md_license_reasons'] = '<p>This may be due to any of the following;</p>
<ul>
<li>Aktif bir lisansınız mevcut değil You do not have any active license for this content</li>
<li>Using plugin on unlicensed domain or path </li>
<li>IP adresi üzerinden erişim yapmaya çalışıyor olabilirsiniz Using IP adress instead of DNS adress</li>
<li>Instant problem with DNS</li>
<li>Removeing copyright(crafted) informations(s)</li>
</ul>';
$l['md_license_mistake'] = 'If you think there is a problem other than these, you can return to us by clicking <a href="https://wa.me/908503464631">HERE</a>.';
$l['md_license_adminstration'] = 'MyBBGraphic Administration';

$l['sv_pn'] = 'Stabview';
$l['sv_pd'] = 'Stabview advanced multitab overview';

$l['sv_psettings_t'] = 'Stabview settings';
$l['sv_psettings_d'] = 'Stabview plugin settings';

$l['sv_ps_tnum_t'] = 'Thread number';
$l['sv_ps_tnum_d'] = 'Showing thread number(without ad thread)';

$l['sv_ps_dicon_t'] = 'Default icon';
$l['sv_ps_dicon_d'] = 'Default icon for tabs';

$l['sv_ps_fids_t'] = 'Tab names and forum ids';
$l['sv_ps_fids_d'] = 'Showing tab names and id and icon for each tab.(seperate with |)';

$l['sv_ps_exc_t'] = 'Unwanted categories';
$l['sv_ps_exc_d'] = 'Specify forum ids that you do not want to appear, separated by commas. (leave empty to make passive).';

$l['sv_ps_ads_t'] = 'Ad threads';
$l['sv_ps_ads_d'] = 'IDs for ad threads, seperate with comma.(For deactive empty)';
?>