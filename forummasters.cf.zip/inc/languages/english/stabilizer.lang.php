<?php
/**
 * Author: MyBB Dizayn
 * Plugin: Premium Theme Language
 * Version: 1.0
 * Plugin Language File: turkish
 */
 
global $mybb;
$l['md_powered_by'] = 'Forum yazılımı : ';
$l['md_license_title'] = 'Lisanssız tema kullanım uyarısı!';
$l['md_license_h1'] = 'DİKKAT!';
$l['md_license_info'] = 'Lisansınız doğrulanamadı!';
$l['md_license_reasons'] = '<p>Bunun nedeni aşağıdakilerden herhangi biri olabilir;</p>
<ul>
<li>Aktif bir lisansınız mevcut değil</li>
<li>Sistemi lisanssız bir domain veya dizinde çalıştırıyor olabilirsiniz</li>
<li>IP adresi üzerinden erişim yapmaya çalışıyor olabilirsiniz</li>
<li>DNS kaynaklı anlık bir sorun yaşıyor olabilirsiniz</li>
<li>Copyright(yapımcı) bilgilerini silmiş olabilirsiniz</li>
</ul>';
$l['md_license_mistake'] = 'Bunların haricinde bir sorun olduğunu düşünüyorsanız, <a href="https://wa.me/908503464631">BURAYA</a> tıklayarak bize dönüş yapabilirsiniz.';
$l['md_license_adminstration'] = 'MyBBDizayn Yönetimi';
$l['md_trend_title'] = 'Trend konular';
$l['md_trend_nevermind'] = 'Forumda henüz trend konu yok.';
$l['md_trend_desc'] = 'Son '.$mybb->settings["stabilizer_trendday"].' günün trend konuları';
$l['md_trend_author'] = 'Konu sahibi :';
$l['md_trend_lastposter'] = 'Son yazan :';
$l['md_trend_views'] = 'Okunma';
$l['md_postgoal_head'] = 'Günlük hedefimiz';
$l['md_postgoal_title'] = 'Günlük mesaj hedefi';
$l['md_postgoal_reached'] = 'Erişildi';
$l['md_postgoal_nreached'] = 'Erişilmedi';
$l['md_goal_sitename'] = '<a href="#">www.mybbdizayn.com</a>';
$l['md_goal_situation'] = 'Durum</a>';
$l['md_goal_target'] = 'Mesaj</a>';
$l['md_postgoal_text'] = 'Burada sizlerin de desteği ile forumumuza günlük mesaj hedefi belirledik, adım adım büyümekteyiz, teşekkürler..';
$l['md_social'] = 'Sosyal ağlar';
$l['md_adzone'] = 'Reklam alanı';
$l['md_contactus'] = 'Bize ulaşın';
$l['md_wc_message'] = 'Hoşgeldin, Ziyaretçi!';
$l['md_wc_message_title'] = 'Merhaba, içerik sağlayıcı paylaşım adresimize eriştiğin için gerçekten çok mutluyuz. Fakat henüz ziyaretçi olarak forumu görüntülediğiniz için, forumun bir çok özelliklerinden faydalanamıyorsunuz. Kayıt olarak üyelerimize özel tüm özelliklerden faydalanmaya ne dersiniz? Hemen şimdi, sadece 2 dakikanızı ayırarak kayıt olabilirsiniz. Sizi de aramızda görmeyi çok istiyoruz..';
$l['md_buddy_all'] = 'Tümünü Görüntüle';
$l['md_buddy_message'] = 'Arkadaşın olmak istiyor!';






$l['md_pmalert_one_text'] = 'adlı kullanıcıdan yeni bir özel mesaj aldınız.';
$l['md_pmalert_one_subject'] = 'Mesaj başlığı : ';
$l['md_banalert_info'] = 'Anlaşılan bir şeyler yanlış gitti ve aradığınız sayfa yerine farklı bir web arayüzü ile karşılaştınız! Ama panik yapmayın, bunun bir sebebi var.. Bu mesajı görüyorsunuz, çünkü yönetim kararı ile <b> hesabınız yasaklanmıştır.</b> Eğer bunun bir hata olduğunu düşünüyorsanız, lütfen iletişim bölümünden destek ekibimize bir mesaj gönderin.';

$l['md_welcomeregalt'] = 'Zaten üye misin?';
$l['md_loginbtext'] = 'Hesaba giriş yap!';
$l['md_registerbtext'] = 'Kayıt ol!';
$l['md_loginwithsocial'] = 'Sosyal hesabınız ile giriş yapın!';
$l['md_day'] = 'Gündüz';
$l['md_night'] = 'Gece';

//GLOBAL
$l['php_code'] = '<div class="codeblock-title">PHP Kod :</div><div class="codeblock-buttons"><span class="codeblock-copy"><svg class="icon" xmlns="http://www.w3.org/2000/svg"><use xlink:href="stabilizer/svg/sprite.svg#copy-icon"></use></svg></span></div>';
$l['code'] = '<div class="codeblock-title">Kod :</div><div class="codeblock-buttons"><span class="codeblock-copy"><svg class="icon" xmlns="http://www.w3.org/2000/svg"><use xlink:href="stabilizer/svg/sprite.svg#copy-icon"></use></svg></span></div>';
$l['md_threads'] = 'Konular';
$l['md_posts'] = 'Mesajlar';
$l['md_views'] = 'Okunma';
$l['md_comments'] = 'Yorumlar';
$l['md_warning_level'] = 'Uyarı puan';
$l['md_reputation'] = 'Rep puanı';
$l['md_add_remove_friend'] = 'Arkadaş ekle';
$l['md_members_referred'] = 'Referanslar';

//INDEX
$l['md_gothread'] = 'Konuya git';
$l['md_sidebar_opened'] = 'Sidebar açıldı';
$l['md_sidebar_closed'] = 'Sidebar kapatıldı';
$l['md_nightmode_activated'] = 'Gece modu etkin';
$l['md_daymode_activated'] = 'Gündüz modu etkin';
$l['md_total_threads'] = 'Toplam konular';
$l['md_total_posts'] = 'Toplam mesajlar';
$l['md_total_members'] = 'Toplam üyeler';
$l['md_total_onlinerecord'] = 'Online rekorumuz';
$l['md_total_nmwelcome'] = 'Aramıza hoşgeldin!';
$l['md_buddyrequest_title'] = 'Arkadaş istekleri';
$l['md_buddyrequest_alttitle'] = 'Engelli listesi';
$l['md_buddyrequest_norequest'] = 'Yeni arkadaşlık isteğiniz yok';
$l['md_forumbit_newthread'] = 'Yeni konu gönder';
$l['md_forumbit_lastmessage'] = 'Son mesaja git';
$l['md_forumbit_todaymessages'] = 'Bugünkü mesajlar';
$l['md_forumbit_rss'] = 'RSS beslemesi';
$l['md_forumbit_neveryet'] = 'Henüz yok';
$l['md_forumbit_firstyou'] = 'İlk konuyu sen aç ';
$l['md_forumbit_never'] = 'İlk konuyu sen açmak ister misin?';


//HEADER-MENU
$l['md_index'] = 'Anasayfa';
$l['md_search_placeholder'] = 'Aklında ne var?';
$l['md_nextupdate'] = 'Sıradakı güncelleme ile gelecektir';

//HEADER-WELCOMEBLOCK
$l['md_hello'] = 'Merhaba!';
$l['md_change_profile'] = 'Bilgilerini düzenle';
$l['md_show_profile'] = 'Profilini gör';
$l['md_tsubs'] = 'Takip edilen konular';
$l['md_fsubs'] = 'Takip edilen forumlar';
$l['md_change_username'] = 'Kullanıcı adımı değiştir';
$l['md_change_password'] = 'Şifremi değiştir';
$l['md_change_email'] = 'E-posta adresimi değiştir';
$l['md_change_avatar'] = 'Avatarımı değiştir';
$l['md_change_sig'] = 'İmzamı değiştir';
$l['md_change_options'] = 'Seçenekleri düzenle';

//HEADER-PM
$l['md_pmnomessage'] = 'Yeni özel mesajınız bulunmamaktadır';

//FORUMDISPLAY
$l['md_thread_sticky'] = 'Sabit konu';
$l['md_thread_locked'] = 'Kilitli konu';

//SHOWTHREAD
$l['md_poll_desc'] = 'Lütfen aşağıdaki seçeneklerden birini işaretleyip, oyunuzu kullanın.';
$l['md_poll_desc_2'] = 'Oy kullandığınız için, şuan anketin son durumunu görüntülemektesiniz.';

//POSTBIT
$l['md_postbit_name'] = 'Ad';
$l['md_postbit_threads'] = 'Konular';
$l['md_postbit_posts'] = 'Mesajlar';
$l['md_postbit_warning_level'] = 'Uyarı puan';
$l['md_postbit_reputation'] = 'Rep puanı';
$l['md_postbit_status_online'] = 'Şuan Online!';
$l['md_postbit_status_offline'] = 'Şuan Offine!';
$l['md_postbit_status_away'] = 'Şuan İzinli!';
$l['md_postbit_add_remove_friend'] = 'Arkadaş ekle';
$l['md_postbit_showstatistics_title'] = 'Bilgileri gizle/göster';
$l['md_postbit_yourself'] = 'Kendine arkadaş bulmanı tavsiye ediyoruz :)';

//PROFILE
$l['md_send_pm'] = 'Mesaj gönder';
$l['md_profile_posts'] = 'Mesajlar';
$l['md_profile_threads'] = 'Konular';

//
$l['md_positive'] = 'Pozitif';
$l['md_negative'] = 'Negatif';
$l['md_neutral'] = 'Tarafsız';

//USERCP
$l['md_maxavatar_lang'] = 'Maksimum boyut ';
$l['md_maxsig_lang'] = 'Maksimum izin '.$mybb->settings['siglength'].' karakter';
$l['md_editsig_lang'] = 'Şifreni değiştirmek için tıkla!';
$l['md_editopt_lang'] = 'Ayarları değiştirmek için tıkla!';
$l['md_nightmode_usercp'] = 'Gece moduna geçilsin mi?';

//SHOP
$l['md_shop'] = 'Market Alanı';
$l['md_shop_thead'] = 'Karar veremiyor musunuz?';
$l['md_shop_thead_title'] = 'Talibi olduğunuz paket için kafanızda soru işaretimi var? Hemen bize bir mesaj yollayın, satış öncesi ekibimiz ile hızlıca dönüş yapalım.';
$l['md_shop_choose'] = 'Seçiminizi yapın';
$l['md_shop_info'] = 'Sorun mu var?';
$l['md_shop_menu'] = 'Market';
$l['md_shop_desc'] = 'Trendleri, eğlenceyi, ayrıcalığı, her yeni günü, herkes için heyecan dolu, taze bir başlangıca dönüştürüyoruz.';
$l['md_shop_tab1'] = 'Premium Üyelikler';
$l['md_shop_tab1_title'] = 'Premium üye olup avantajlardan yararlanabilirsiniz.';
$l['md_shop_tab2'] = 'Reklamlar';
$l['md_shop_tab2_title'] = 'Bu bölümde reklam için avantajlı seçenekler mevcut.';
$l['md_shop_tab3'] = 'Mesaj Kutuları';
$l['md_shop_tab3_title'] = 'Mesaj kutun yetersiz mi geliyor? Bir göz atmalısın. :)';
$l['md_shop_tab4'] = 'Nick Değişimi';
$l['md_shop_tab4_title'] = 'Kullanıcı adı değişimi için, buraya göz atabilirsiniz.';


//REGISTER
$l['md_subscription_method'] = 'Konu takip seçenekleri';
$l['md_account_details'] = 'Hesap Detayları';
$l['md_account_prefs'] = 'Hesap Seçenekleri';
$l['md_required_info'] = 'Zorunlu Bilgiler';
$l['md_additional_info'] = 'İsteğe Bağlı Bilgiler';
$l['md_register_security'] = 'Güvenlik';
$l['md_login_submitnote'] = 'Giriş yaparken, beni hatırla seçeneği ile foruma daha hızlı erişebileceğini unutma :)';

//NEWTHREAD
$l['md_threadsubject'] = 'Konu başlığı';
$l['md_selectfile'] = 'Dosyaları seç';
$l['md_view_attachments'] = 'Yüklediğim dosyaları göster';

$l['md_pm_sender'] = 'Gönderen : ';
$l['md_pm_send'] = 'Yeni mesaj';
$l['md_pm_draft'] = 'Taslaklar';


$l['xld_copyright'] = " <a href=\"https://mybb.com\" target=\"_blank\" rel=\"noopener\">Forum Software by MyBB</a>";
$l['xld_theme_name'] = "
<h6>Designed by <a2 style=\"color:rgb(255, 0, 235);\">❤</a2> MyBB Dizayn</h6>
<h6>Designed by <a2 style=\"color:rgb(102, 224, 71);\">❤</a2> MyBB Dizayn</h6>
<h6>Designed by <a2 style=\"color:rgb(102, 224, 71);\">❤</a2> MyBB Dizayn</h6>";
?>
